﻿$(document).ready(function () {
    $("body").on("keydown", ".Datepick", function (event) {
        if (event.keyCode != 9)
        event.preventDefault();
    });
    $('input[id$=ToDelete]').mouseover(function () {
        $(this).attr("Title","Delete Record");
    });

    $(function () {
        $(".Datepick").datepicker({ changeMonth: true, changeYear: true, yearRange: "-50:+20", dateFormat: 'dd/mm/yy' });
    });

    $('textarea').each(function () {
        $(this).popBox({ width: 500, height: 400, newlineString: '\n' });
    });

   $("#addRecordF").click(function () {
        var counter = $("#Facilities").children().length;
        if (counter > 30) {
            alert("Only 30 records allowed");
            return false;
        }
        var newTextBoxDiv = $(document.createElement('div'))
             .attr("id", 'FacilitiesRow' + counter);
        newTextBoxDiv.html('<input data-val="true" data-val-number="The field BranchYearID must be a number." data-val-required="The BranchYearID field is required." id="LABARB_A1F_' + counter + '__BranchYearID" name="LABARB_A1F[' + counter + '].BranchYearID" type="hidden" value="0" />' +
            '<input data-val="true" data-val-number="The field MainSlNo must be a number." data-val-required="The MainSlNo field is required." id="LABARB_A1F_' + counter + '__MainSlNo" name="LABARB_A1F[' + counter + '].MainSlNo" type="hidden" value="0" />' +
            '<input data-val="true" data-val-number="The field SlNo must be a number." data-val-required="The SlNo field is required." id="LABARB_A1F_' + counter + '__SlNo" name="LABARB_A1F[' + counter + '].SlNo" type="hidden" value="0" />' +
            '<div class="rowfac">' +
                '<div class="coldate"><input class="Datepick"  style="width: 85px;" data-val="true" data-val-date="The field Date of Sanction must be a date." id="LABARB_A1F_' + counter + '__SanctionDate" name="LABARB_A1F[' + counter + '].SanctionDate" type="text" value="" /> </div>' +
                '<div class="colfacility2"><input class="text-box single-line tableFac"   id="LABARB_A1F_' + counter + '__Facility" name="LABARB_A1F[' + counter + '].Facility" type="text" value="" /> </div>' +
                '<div class="amt"><input class="text-box single-line" style="width: 100px;"  data-val="true" data-val-number="The field Limit Rs Lac must be a number." id="LABARB_A1F_' + counter + '__SanctionedLimit" name="LABARB_A1F[' + counter + '].SanctionedLimit" type="text" value="" /> </div>' +
                '<div class="colfacility2"><textarea name="LABARB_A1F[' + counter + '].PrimeSecurity" class="tableFac" id="LABARB_A1F_' + counter + '__PrimeSecurity" style="height: 16px;" rows="2" cols="20" /></div>' +
                '<div class="colfacility2"><textarea name="LABARB_A1F[' + counter + '].CollateralSecurity" class="tableFac" id="LABARB_A1F_' + counter + '__CollateralSecurity" style="height: 16px;" rows="2" cols="20" /></div>' +
                '<div class="colfacility2"><input class="text-box single-line tableFac"  data-val="true" data-val-number="The field Margin % must be a number." id="LABARB_A1F_' + counter + '__SecurityMargin" name="LABARB_A1F[' + counter + '].SecurityMargin" type="text" value="" /></div>' +
                '<div class="colfacility2"><input class="text-box single-line tableFac"  data-val="true" data-val-number="The field Balance Outstanding At Current year End must be a number." id="LABARB_A1F_' + counter + '__BalanceAmountCurrent" name="LABARB_A1F[' + counter + '].BalanceAmountCurrent" type="text" value="" /></div>' +
                '<div class="colfacility2"><input class="text-box single-line tableFac"  data-val="true" data-val-number="The field Balance Outstanding At Previous year End must be a number." id="LABARB_A1F_' + counter + '__BalanceAmountPrevious" name="LABARB_A1F[' + counter + '].BalanceAmountPrevious" type="text" value="" /></div>' +
                //'<div class="colfacility2"><input id="LABARB_A1F_' + counter + '__FacilityRemarks"  class="text-box single-line tableFac" type="text" value="" name="LABARB_A1F[' + counter + '].FacilityRemarks"></div>' +
                //'<div class="colfacility2"><input id="LABARB_A1F_' + counter + '__FacilityValue"  class="text-box single-line tableFac" type="text" value="" name="LABARB_A1F[' + counter + '].FacilityValue" data-val-number="The field Value must be a number." data-val="true"></div>' +
                '<div class="Delete"><input id="LABARB_A1F_' + counter + '__ToDelete" type="checkbox" value="true" name="LABARB_A1F[' + counter + '].ToDelete" title="Delete Record"><input type="hidden" value="false" name="LABARB_A1F[' + counter + '].ToDelete"></div>' +
                 '<div class="last">' +
                '<span class="field-validation-valid" data-valmsg-for="LABARB_A1F[' + counter + '].SanctionDate" data-valmsg-replace="true"></span>' +
                   ' <span class="field-validation-valid" data-valmsg-for="LABARB_A1F[' + counter + '].Facility" data-valmsg-replace="true"></span>' +
                    '<span class="field-validation-valid" data-valmsg-for="LABARB_A1F[' + counter + '].SanctionedLimit" data-valmsg-replace="true"></span>' +
                    '<span class="field-validation-valid" data-valmsg-for="LABARB_A1F[' + counter + '].PrimeSecurity" data-valmsg-replace="true"></span>' +
                    '<span class="field-validation-valid" data-valmsg-for="LABARB_A1F[' + counter + '].CollateralSecurity" data-valmsg-replace="true"></span>' +
                    '<span class="field-validation-valid" data-valmsg-for="LABARB_A1F[' + counter + '].SecurityMargin" data-valmsg-replace="true"></span>' +
                    '<span class="field-validation-valid" data-valmsg-for="LABARB_A1F[' + counter + '].BalanceAmountCurrent" data-valmsg-replace="true"></span>' +
                    '<span class="field-validation-valid" data-valmsg-for="LABARB_A1F[' + counter + '].BalanceAmountPrevious" data-valmsg-replace="true"></span>' +
                    //'<span class="field-validation-valid" data-valmsg-replace="true" data-valmsg-for="LABARB_A1F[' + counter + '].FacilityRemarks"></span>' +
                    //'<span class="field-validation-valid" data-valmsg-replace="true" data-valmsg-for="LABARB_A1F[' + counter + '].FacilityValue"></span>'+
            '</div>');
        newTextBoxDiv.appendTo("#Facilities");
        counter++;
        $('textarea').each(function () {
            $(this).popBox({ width: 500, height: 400, newlineString: '\n' });
        });
        $(".Datepick").datepicker({
            changeMonth: true,
            changeYear: true,
            yearRange: "-50:+20",
            dateFormat: 'dd/mm/yy'
        });
        $('textarea').each(function () {
            $(this).popBox({ width: 500, height: 400, newlineString: '\n' });
        });
        //var fcid = 'FacilitiesRow' + counter;
        //$.validator.unobtrusive.parse(".rowfac > div > div > fieldset > form");
    });

   $("#addRecordPS").click(function () {
       var counter = $("#PS").children().length;
       if (counter > 30) {
           alert("Only 30 records allowed");
           return false;
       }
       var newTextBoxDiv = $(document.createElement('div'))
            .attr("id", 'PSRow' + counter);
       newTextBoxDiv.html('<input data-val="true" data-val-number="The field BranchYearID must be a number." data-val-required="The BranchYearID field is required." id="LABARB_A1PS_' + counter + '__BranchYearID" name="LABARB_A1PS[' + counter + '].BranchYearID" type="hidden" value="0" />' +
           '<input data-val="true" data-val-number="The field MainSlNo must be a number." data-val-required="The MainSlNo field is required." id="LABARB_A1PS_' + counter + '__MainSlNo" name="LABARB_A1PS[' + counter + '].MainSlNo" type="hidden" value="0" />' +
           '<input data-val="true" data-val-number="The field SlNo must be a number." data-val-required="The SlNo field is required." id="LABARB_A1PS_' + counter + '__SlNo" name="LABARB_A1PS[' + counter + '].SlNo" type="hidden" value="0" />' +
           '<div class="rowfac">' +
              '<div class="coldate"><input  class="Datepick " data-val="true" data-val-date="The field Date Verified must be a date." data-val-required="The Date Verified field is required." id="LABARB_A1PS_' + counter + '__DateOfVerification" name="LABARB_A1PS[' + counter + '].DateOfVerification" style="width: 85px;" value="" type="text">  </div>' +
                       '<div class="colPS"><textarea name="LABARB_A1PS[' + counter + '].NatureOfSecurity" class="tableFac" id="LABARB_A1PS_' + counter + '__NatureOfSecurity" style="height: 16px;" rows="2" cols="20" /></div>' +
                       '<div class="colPS"><input  class="tableFac" data-val="true" data-val-number="The field Value Rs Lac must be a number." id="LABARB_A1PS_' + counter + '__SecurityValue" name="LABARB_A1PS[' + counter + '].SecurityValue" value="" type="text">  </div>' +
                       '<div class="coldate"><input  class="Datepick " data-val="true" data-val-date="The field Date of Valuation must be a date." id="LABARB_A1PS_' + counter + '__DateOfValuation" name="LABARB_A1PS[' + counter + '].DateOfValuation" style="width: 85px;" value="" type="text">  </div>' +
                       '<div class="colPS"><input  class="tableFac" id="LABARB_A1PS_' + counter + '__ValuedBy" name="LABARB_A1PS[' + counter + '].ValuedBy" value="" type="text"> </div>' +
                       '<div class="colPS"><input  class="tableFac" data-val="true" data-val-number="The field Insured For Rs Lac must be a number." id="LABARB_A1PS_' + counter + '__InsuredFor" name="LABARB_A1PS[' + counter + '].InsuredFor" value="" type="text"> </div>' +
                       '<div class="coldate"><input  class="Datepick " data-val="true" data-val-date="The field Expiry Date must be a date." id="LABARB_A1PS_' + counter + '__ExpiryDate" name="LABARB_A1PS[' + counter + '].ExpiryDate" style="width: 85px;" value="" type="text"> </div>' +
                       '<div class="Delete"><input id="LABARB_A1PS_' + counter + '__ToDelete" name="LABARB_A1PS[' + counter + '].ToDelete" value="true" type="checkbox"><input name="LABARB_A1PS[' + counter + '].ToDelete" value="false" type="hidden"></div>' +
                       '<div class="last">' +
                           '<span class="field-validation-valid" data-valmsg-for="LABARB_A1PS[' + counter + '].DateOfVerification" data-valmsg-replace="true"></span>' +
                           '<span class="field-validation-valid" data-valmsg-for="LABARB_A1PS[' + counter + '].NatureOfSecurity" data-valmsg-replace="true"></span>' +
                           '<span class="field-validation-valid" data-valmsg-for="LABARB_A1PS[' + counter + '].SecurityValue" data-valmsg-replace="true"></span>' +
                           '<span class="field-validation-valid" data-valmsg-for="LABARB_A1PS[' + counter + '].DateOfValuation" data-valmsg-replace="true"></span>' +
                           '<span class="field-validation-valid" data-valmsg-for="LABARB_A1PS[' + counter + '].ValuedBy" data-valmsg-replace="true"></span>' +
                           '<span class="field-validation-valid" data-valmsg-for="LABARB_A1PS[' + counter + '].InsuredFor" data-valmsg-replace="true"></span>' +
                           '<span class="field-validation-valid" data-valmsg-for="LABARB_A1PS[' + counter + '].ExpiryDate" data-valmsg-replace="true"></span>' +
                      ' </div>');
       newTextBoxDiv.appendTo("#PS");
       $('textarea').each(function () {
           $(this).popBox({ width: 500, height: 400, newlineString: '\n' });
       });
       $(".Datepick").datepicker({
           changeMonth: true,
           changeYear: true,
           yearRange: "-50:+20",
           dateFormat: 'dd/mm/yy'
       });
       $('textarea').each(function () {
           $(this).popBox({ width: 500, height: 400, newlineString: '\n' });
       });
   });

   $("#addRecordCS").click(function () {
       var counter = $("#CS").children().length;
       if (counter > 30) {
           alert("Only 30 records allowed");
           return false;
       }
       var newTextBoxDiv = $(document.createElement('div'))
            .attr("id", 'CSRow' + counter);
       newTextBoxDiv.html('<input data-val="true" data-val-number="The field BranchYearID must be a number." data-val-required="The BranchYearID field is required." id="LABARB_A1CS_' + counter + '__BranchYearID" name="LABARB_A1CS[' + counter + '].BranchYearID" type="hidden" value="0" />' +
           '<input data-val="true" data-val-number="The field MainSlNo must be a number." data-val-required="The MainSlNo field is required." id="LABARB_A1CS_' + counter + '__MainSlNo" name="LABARB_A1CS[' + counter + '].MainSlNo" type="hidden" value="0" />' +
           '<input data-val="true" data-val-number="The field SlNo must be a number." data-val-required="The SlNo field is required." id="LABARB_A1CS_' + counter + '__SlNo" name="LABARB_A1CS[' + counter + '].SlNo" type="hidden" value="0" />' +
           '<div class="rowfac">' +
              '<div class="coldate"><input  class="Datepick " data-val="true" data-val-date="The field Date Verified must be a date." data-val-required="The Date Verified field is required." id="LABARB_A1CS_' + counter + '__DateOfVerification" name="LABARB_A1CS[' + counter + '].DateOfVerification" style="width: 85px;" value="" type="text">  </div>' +
                       '<div class="colPS"><textarea name="LABARB_A1CS[' + counter + '].NatureOfSecurity" class="tableFac" id="LABARB_A1CS_' + counter + '__NatureOfSecurity" style="height: 16px;" rows="2" cols="20" /></div>' +
                       '<div class="colPS"><input  class="tableFac" data-val="true" data-val-number="The field Value Rs Lac must be a number." id="LABARB_A1CS_' + counter + '__SecurityValue" name="LABARB_A1CS[' + counter + '].SecurityValue" value="" type="text">  </div>' +
                       '<div class="coldate"><input  class="Datepick " data-val="true" data-val-date="The field Date of Valuation must be a date." id="LABARB_A1CS_' + counter + '__DateOfValuation" name="LABARB_A1CS[' + counter + '].DateOfValuation" style="width: 85px;" value="" type="text">  </div>' +
                       '<div class="colPS"><input  class="tableFac" id="LABARB_A1CS_' + counter + '__ValuedBy" name="LABARB_A1CS[' + counter + '].ValuedBy" value="" type="text"> </div>' +
                       '<div class="colPS"><input  class="tableFac" data-val="true" data-val-number="The field Insured For Rs Lac must be a number." id="LABARB_A1CS_' + counter + '__InsuredFor" name="LABARB_A1CS[' + counter + '].InsuredFor" value="" type="text"> </div>' +
                       '<div class="coldate"><input  class="Datepick " data-val="true" data-val-date="The field Expiry Date must be a date." id="LABARB_A1CS_' + counter + '__ExpiryDate" name="LABARB_A1CS[' + counter + '].ExpiryDate" style="width: 85px;" value="" type="text"> </div>' +
                       '<div class="Delete"><input id="LABARB_A1CS_' + counter + '__ToDelete" name="LABARB_A1CS[' + counter + '].ToDelete" value="true" type="checkbox"><input name="LABARB_A1CS[' + counter + '].ToDelete" value="false" type="hidden"></div>' +
                       '<div class="last">' +
                           '<span class="field-validation-valid" data-valmsg-for="LABARB_A1CS[' + counter + '].DateOfVerification" data-valmsg-replace="true"></span>' +
                           '<span class="field-validation-valid" data-valmsg-for="LABARB_A1CS[' + counter + '].NatureOfSecurity" data-valmsg-replace="true"></span>' +
                           '<span class="field-validation-valid" data-valmsg-for="LABARB_A1CS[' + counter + '].SecurityValue" data-valmsg-replace="true"></span>' +
                           '<span class="field-validation-valid" data-valmsg-for="LABARB_A1CS[' + counter + '].DateOfValuation" data-valmsg-replace="true"></span>' +
                           '<span class="field-validation-valid" data-valmsg-for="LABARB_A1CS[' + counter + '].ValuedBy" data-valmsg-replace="true"></span>' +
                           '<span class="field-validation-valid" data-valmsg-for="LABARB_A1CS[' + counter + '].InsuredFor" data-valmsg-replace="true"></span>' +
                           '<span class="field-validation-valid" data-valmsg-for="LABARB_A1CS[' + counter + '].ExpiryDate" data-valmsg-replace="true"></span>' +
                      ' </div>');
       newTextBoxDiv.appendTo("#CS");
       $('textarea').each(function () {
           $(this).popBox({ width: 500, height: 400, newlineString: '\n' });
       });
       $(".Datepick").datepicker({
           changeMonth: true,
           changeYear: true,
           yearRange: "-50:+20",
           dateFormat: 'dd/mm/yy'
       });
       $('textarea').each(function () {
           $(this).popBox({ width: 500, height: 400, newlineString: '\n' });
       });
   });
   
   $("#addRecordCG").click(function () {
       var counter = $("#CG").children().length;
       if (counter > 30) {
           alert("Only 30 records allowed");
           return false;
       }
       var newTextBoxDiv = $(document.createElement('div'))
            .attr("id", 'CGRow' + counter);
       newTextBoxDiv.html('<input data-val="true" data-val-number="The field BranchYearID must be a number." data-val-required="The BranchYearID field is required." id="LABARB_A1CG_' + counter + '__BranchYearID" name="LABARB_A1CG[' + counter + '].BranchYearID" type="hidden" value="0" />' +
           '<input data-val="true" data-val-number="The field MainSlNo must be a number." data-val-required="The MainSlNo field is required." id="LABARB_A1CG_' + counter + '__MainSlNo" name="LABARB_A1CG[' + counter + '].MainSlNo" type="hidden" value="0" />' +
           '<input data-val="true" data-val-number="The field SlNo must be a number." data-val-required="The SlNo field is required." id="LABARB_A1CG_' + counter + '__SlNo" name="LABARB_A1CG[' + counter + '].SlNo" type="hidden" value="0" />' +
           '<div class="row">' +
            '<div class="colhead"> - </div>' +
                        '<div class="col"><input class="text-box single-line" id="LABARB_A1CG_' + counter + '__CentralGuaranteeRefNo" name="LABARB_A1CG[' + counter + '].CentralGuaranteeRefNo" value="" type="text"></div>' +
                        '<div class="col"><input class="Datepick" data-val="true" data-val-date="The field Date must be a date." data-val-required="The Date field is required." id="LABARB_A1CG_' + counter + '__CentralGuaranteeDate" name="LABARB_A1CG[' + counter + '].CentralGuaranteeDate" value="" type="text"></div>' +
                        '<div class="col"><input class="text-box single-line" data-val="true" data-val-number="The field Value RS LAC must be a number." id="LABARB_A1CG_' + counter + '__CentralGuaranteeValue" name="LABARB_A1CG[' + counter + '].CentralGuaranteeValue" value="" type="text"></div>' +
                        '<div class="last">' +
                            '<span class="field-validation-valid" data-valmsg-for="LABARB_A1CG[' + counter + '].CentralGuaranteeRefNo" data-valmsg-replace="true"></span>' +
                            '<span class="field-validation-valid" data-valmsg-for="LABARB_A1CG[' + counter + '].CentralGuaranteeDate" data-valmsg-replace="true"></span>' +
                            '<span class="field-validation-valid" data-valmsg-for="LABARB_A1CG[' + counter + '].CentralGuaranteeValue" data-valmsg-replace="true"></span>' +
                        '</div>');
       newTextBoxDiv.appendTo("#CG");
       $(".Datepick").datepicker({
           changeMonth: true,
           changeYear: true,
           yearRange: "-50:+20",
           dateFormat: 'dd/mm/yy'
       });
   });
  

   $("#addRecordSG").click(function () {
       var counter = $("#SG").children().length;
       if (counter > 30) {
           alert("Only 30 records allowed");
           return false;
       }
       var newTextBoxDiv = $(document.createElement('div'))
            .attr("id", 'SGRow' + counter);
       newTextBoxDiv.html('<input data-val="true" data-val-number="The field BranchYearID must be a number." data-val-required="The BranchYearID field is required." id="LABARB_A1SG_' + counter + '__BranchYearID" name="LABARB_A1SG[' + counter + '].BranchYearID" type="hidden" value="0" />' +
           '<input data-val="true" data-val-number="The field MainSlNo must be a number." data-val-required="The MainSlNo field is required." id="LABARB_A1SG_' + counter + '__MainSlNo" name="LABARB_A1SG[' + counter + '].MainSlNo" type="hidden" value="0" />' +
           '<input data-val="true" data-val-number="The field SlNo must be a number." data-val-required="The SlNo field is required." id="LABARB_A1SG_' + counter + '__SlNo" name="LABARB_A1SG[' + counter + '].SlNo" type="hidden" value="0" />' +
           '<div class="row">' +
            '<div class="colhead"> - </div>' +
                        '<div class="col"><input class="text-box single-line" id="LABARB_A1SG_' + counter + '__StateGuaranteeRefNo" name="LABARB_A1SG[' + counter + '].StateGuaranteeRefNo" value="" type="text"></div>' +
                        '<div class="col"><input class="Datepick" data-val="true" data-val-date="The field Date must be a date." data-val-required="The Date field is required." id="LABARB_A1SG_' + counter + '__StateGuaranteeDate" name="LABARB_A1SG[' + counter + '].StateGuaranteeDate" value="" type="text"></div>' +
                        '<div class="col"><input class="text-box single-line" data-val="true" data-val-number="The field Value RS LAC must be a number." id="LABARB_A1SG_' + counter + '__StateGuaranteeValue" name="LABARB_A1SG[' + counter + '].StateGuaranteeValue" value="" type="text"></div>' +
                        '<div class="last">' +
                            '<span class="field-validation-valid" data-valmsg-for="LABARB_A1SG[' + counter + '].StateGuaranteeRefNo" data-valmsg-replace="true"></span>' +
                            '<span class="field-validation-valid" data-valmsg-for="LABARB_A1SG[' + counter + '].StateGuaranteeDate" data-valmsg-replace="true"></span>' +
                            '<span class="field-validation-valid" data-valmsg-for="LABARB_A1SG[' + counter + '].StateGuaranteeValue" data-valmsg-replace="true"></span>' +
                        '</div>');
       newTextBoxDiv.appendTo("#SG");
       $(".Datepick").datepicker({
           changeMonth: true,
           changeYear: true,
           yearRange: "-50:+20",
           dateFormat: 'dd/mm/yy'
       });
   });

   $("#addRecordBG").click(function () {
       var counter = $("#BG").children().length;
       if (counter > 30) {
           alert("Only 30 records allowed");
           return false;
       }
       var newTextBoxDiv = $(document.createElement('div'))
            .attr("id", 'BGRow' + counter);
       newTextBoxDiv.html('<input data-val="true" data-val-number="The field BranchYearID must be a number." data-val-required="The BranchYearID field is required." id="LABARB_A1BG_' + counter + '__BranchYearID" name="LABARB_A1BG[' + counter + '].BranchYearID" type="hidden" value="0" />' +
           '<input data-val="true" data-val-number="The field MainSlNo must be a number." data-val-required="The MainSlNo field is required." id="LABARB_A1BG_' + counter + '__MainSlNo" name="LABARB_A1BG[' + counter + '].MainSlNo" type="hidden" value="0" />' +
           '<input data-val="true" data-val-number="The field SlNo must be a number." data-val-required="The SlNo field is required." id="LABARB_A1BG_' + counter + '__SlNo" name="LABARB_A1BG[' + counter + '].SlNo" type="hidden" value="0" />' +
           '<div class="row">' +
            '<div class="colhead"> - </div>' +
                        '<div class="col"><input class="text-box single-line" id="LABARB_A1BG_' + counter + '__BankGuaranteeRefNo" name="LABARB_A1BG[' + counter + '].BankGuaranteeRefNo" value="" type="text"></div>' +
                        '<div class="col"><input class="Datepick" data-val="true" data-val-date="The field Date must be a date." data-val-required="The Date field is required." id="LABARB_A1BG_' + counter + '__BankGuaranteeDate" name="LABARB_A1BG[' + counter + '].BankGuaranteeDate" value="" type="text"></div>' +
                        '<div class="col"><input class="text-box single-line" data-val="true" data-val-number="The field Value RS LAC must be a number." id="LABARB_A1BG_' + counter + '__BankGuaranteeValue" name="LABARB_A1BG[' + counter + '].BankGuaranteeValue" value="" type="text"></div>' +
                        '<div class="last">' +
                            '<span class="field-validation-valid" data-valmsg-for="LABARB_A1BG[' + counter + '].BankGuaranteeRefNo" data-valmsg-replace="true"></span>' +
                            '<span class="field-validation-valid" data-valmsg-for="LABARB_A1BG[' + counter + '].BankGuaranteeDate" data-valmsg-replace="true"></span>' +
                            '<span class="field-validation-valid" data-valmsg-for="LABARB_A1BG[' + counter + '].BankGuaranteeValue" data-valmsg-replace="true"></span>' +
                        '</div>');
       newTextBoxDiv.appendTo("#BG");
       $(".Datepick").datepicker({
           changeMonth: true,
           changeYear: true,
           yearRange: "-50:+20",
           dateFormat: 'dd/mm/yy'
       });
   });

   $("#addRecordOG").click(function () {
       var counter = $("#OG").children().length;
       if (counter > 30) {
           alert("Only 30 records allowed");
           return false;
       }
       var newTextBoxDiv = $(document.createElement('div'))
            .attr("id", 'OGRow' + counter);
       newTextBoxDiv.html('<input data-val="true" data-val-number="The field BranchYearID must be a number." data-val-required="The BranchYearID field is required." id="LABARB_A1OG_' + counter + '__BranchYearID" name="LABARB_A1OG[' + counter + '].BranchYearID" type="hidden" value="0" />' +
           '<input data-val="true" data-val-number="The field MainSlNo must be a number." data-val-required="The MainSlNo field is required." id="LABARB_A1OG_' + counter + '__MainSlNo" name="LABARB_A1OG[' + counter + '].MainSlNo" type="hidden" value="0" />' +
           '<input data-val="true" data-val-number="The field SlNo must be a number." data-val-required="The SlNo field is required." id="LABARB_A1OG_' + counter + '__SlNo" name="LABARB_A1OG[' + counter + '].SlNo" type="hidden" value="0" />' +
           '<div class="row">' +
            '<div class="colhead"> - </div>' +
                        '<div class="col"><input class="text-box single-line" id="LABARB_A1OG_' + counter + '__OtherGuaranteeRefNo" name="LABARB_A1OG[' + counter + '].OtherGuaranteeRefNo" value="" type="text"></div>' +
                        '<div class="col"><input class="Datepick" data-val="true" data-val-date="The field Date must be a date." data-val-required="The Date field is required." id="LABARB_A1OG_' + counter + '__OtherGuaranteeDate" name="LABARB_A1OG[' + counter + '].OtherGuaranteeDate" value="" type="text"></div>' +
                        '<div class="col"><input class="text-box single-line" data-val="true" data-val-number="The field Value RS LAC must be a number." id="LABARB_A1OG_' + counter + '__OtherGuaranteeValue" name="LABARB_A1OG[' + counter + '].OtherGuaranteeValue" value="" type="text"></div>' +
                        '<div class="last">' +
                            '<span class="field-validation-valid" data-valmsg-for="LABARB_A1OG[' + counter + '].OtherGuaranteeRefNo" data-valmsg-replace="true"></span>' +
                            '<span class="field-validation-valid" data-valmsg-for="LABARB_A1OG[' + counter + '].OtherGuaranteeDate" data-valmsg-replace="true"></span>' +
                            '<span class="field-validation-valid" data-valmsg-for="LABARB_A1OG[' + counter + '].OtherGuaranteeValue" data-valmsg-replace="true"></span>' +
                        '</div>');
       newTextBoxDiv.appendTo("#OG");
       $(".Datepick").datepicker({
           changeMonth: true,
           changeYear: true,
           yearRange: "-50:+20",
           dateFormat: 'dd/mm/yy'
       });
   });

    $("#addItem").click(function () {
        $.ajax({
            url: $(this).attr('href'),
            cache: false,
            success: function (html) { $("#editorRows").append(html); },
        });
        $(".Datepick").datepicker({ changeMonth: true, changeYear: true, yearRange: "-50:+20", dateFormat: 'dd/mm/yy' });
        var thisForm = $(this).closest("form");
        thisForm.removeData("validator");
        thisForm.removeData("unobtrusiveValidation");
        $.validator.unobtrusive.parse(thisForm);
        return false;
    });

    jQuery.fn.preventDoubleSubmission = function () {
        $(this).on('submit', function (e) {
            var $form = $(this);

            if ($form.data('submitted') === true) {
                return false;
                e.preventDefault();
            } else if ($form.valid()) {
                $("#divmsg").html("Saving Annexure...");
                $form.data('submitted', true);
            }
        });
        return this;
    };
    $('#form0').preventDoubleSubmission();
});


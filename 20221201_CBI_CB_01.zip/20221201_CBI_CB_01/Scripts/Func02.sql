IF EXISTS(SELECT NAME FROM sys.objects WHERE type = 'P' AND name = 'USP_TDS_SaveDeducteeDetail')
DROP PROCEDURE USP_TDS_SaveDeducteeDetail
GO
CREATE PROCEDURE USP_TDS_SaveDeducteeDetail 
	@BRANCHID INT,                  
	@DEDUCTEEID INT,                  
	@ISDEDUCTEEANEMPLOYEE BIT,                  
	@SALUTATION TINYINT,                  
	@NAME VARCHAR(75),                  
	@PAN VARCHAR(10),                  
	@PANREFERENCE VARCHAR(10),                  
	@ADDRESS1 VARCHAR(25),                  
	@ADDRESS2 VARCHAR(25),                  
	@ADDRESS3 VARCHAR(25),                  
	@ADDRESS4 VARCHAR(25),                  
	@ADDRESS5 VARCHAR(25),                  
	@STATEID INT,                  
	@PINCODE VARCHAR(6),                  
	@PHONENO VARCHAR(15),                  
	@EMAILADDRESS VARCHAR(75),                  
	@REFERENCENO VARCHAR(20) ,                
	@PANSTATUS VARCHAR(MAX),            
	@ISPANEXIXTS BIT=NULL,            
	@OUTSRNO INT=NULL OUTPUT,            
	@OUTNAME VARCHAR(75)=NULL OUTPUT,    
	@ENTRYBRANCHID INT=NULL,    
	@ENTRYDATE SMALLDATETIME=NULL,
	@EMPTYPE INT = NULL,  
	@ISSB BIT=NULL,
	@ISOBC BIT=NULL       
AS                  
	BEGIN         
		--IB        
		IF(@ISPANEXIXTS IS NULL)        
		BEGIN                 
			IF @ISDEDUCTEEANEMPLOYEE = 1 /* To check for Employee Name & PAN duplication */                  
			BEGIN                  
				IF EXISTS (SELECT D.DEDUCTEEID FROM DEDUCTEE D WITH(NOLOCK) INNER JOIN EMPLOYEE E WITH(NOLOCK) 
					ON D.DEDUCTEEID = E.DEDUCTEEID WHERE D.NAME = @NAME AND D.PAN = @PAN AND PAN NOT IN ('PANAPPLIED', 'PANNOTAVBL', 'PANINVALID') AND D.DEDUCTEEID <> @DEDUCTEEID  AND D.BRANCHID = @BRANCHID)                  
				BEGIN                  
					SET @DEDUCTEEID = -2;                  
				END                  
			END                    
			ELSE IF @ISDEDUCTEEANEMPLOYEE = 0 /* To check for NonEmployee Name & PAN duplication */                  
			BEGIN                  
				IF ((@ISOBC <> 1 AND @ISSB <> 1) AND EXISTS (SELECT D.DEDUCTEEID FROM DEDUCTEE D WITH(NOLOCK) INNER JOIN NONEMPLOYEE NE WITH(NOLOCK) 
					ON D.DEDUCTEEID = NE.DEDUCTEEID WHERE D.NAME = @NAME AND D.PAN = @PAN  AND PAN NOT IN ('PANAPPLIED', 'PANNOTAVBL', 'PANINVALID') AND D.DEDUCTEEID <> @DEDUCTEEID AND D.BRANCHID = @BRANCHID))                
				BEGIN              
					SET @DEDUCTEEID = -2;                  
				END                  
			END           
		END 

		IF(@ISSB=1 AND EXISTS(SELECT PAN FROM DEFAULTSETTINGS WITH(NOLOCK) WHERE PAN=@PAN))  
		BEGIN  
			SET @DEDUCTEEID=-4;  
		END                  

		--IB            
		IF(EXISTS(SELECT PAN FROM DEDUCTEE D WITH(NOLOCK) INNER JOIN NONEMPLOYEE NE WITH(NOLOCK) 
			ON D.DEDUCTEEID = NE.DEDUCTEEID  WHERE D.PAN=@PAN AND D.DEDUCTEEID <> @DEDUCTEEID AND @ISPANEXIXTS=1 AND PAN<>'PANAPPLIED' AND D.PAN<>'PANINVALID' AND D.PAN<>'PANNOTAVBL' AND D.BRANCHID = @BRANCHID))            
		BEGIN            
			SET @DEDUCTEEID = -3;               
			SELECT @OUTNAME = NAME, @OUTSRNO = NE.SERIALNO 
			FROM DEDUCTEE D WITH(NOLOCK) 
				INNER JOIN NONEMPLOYEE NE WITH(NOLOCK)             
					ON NE.DEDUCTEEID=D.DEDUCTEEID            
			WHERE PAN = @PAN AND D.BRANCHID = @BRANCHID           
		END                  

		IF @DEDUCTEEID <> -2  OR  @DEDUCTEEID<>-3               
		BEGIN                  
			IF (@DEDUCTEEID = -1) /* New Entry */                  
			BEGIN                  
				INSERT INTO DEDUCTEE(BRANCHID,SALUTATION,NAME,PAN,PANREFERENCE,ADDRESS1,ADDRESS2,ADDRESS3,ADDRESS4,ADDRESS5,                  
					STATEID,PINCODE,PHONENO,EMAILADDRESS,REFERENCENO,PANSTATUS,ENTRYBRANCHID,ENTRYDATE,EMPTYPE)                     
				VALUES    (@BRANCHID,@SALUTATION,@NAME,@PAN,@PANREFERENCE,@ADDRESS1,@ADDRESS2,@ADDRESS3,@ADDRESS4,@ADDRESS5,@STATEID,@PINCODE,                  
				@PHONENO,@EMAILADDRESS,@REFERENCENO,@PANSTATUS,@ENTRYBRANCHID,@ENTRYDATE, @EMPTYPE);                  

				SELECT @DEDUCTEEID = SCOPE_IDENTITY();                  
			END                  
			ELSE /* Existing Entry */                  
			BEGIN                  
				UPDATE DEDUCTEE 
				SET SALUTATION = @SALUTATION,NAME = @NAME,PAN = @PAN,PANREFERENCE = @PANREFERENCE,                  
					ADDRESS1 = @ADDRESS1,ADDRESS2 = @ADDRESS2,ADDRESS3 = @ADDRESS3,ADDRESS4 = @ADDRESS4,ADDRESS5 = @ADDRESS5,                  
					STATEID = @STATEID,PINCODE = @PINCODE,PHONENO = @PHONENO,EMAILADDRESS = @EMAILADDRESS ,                  
					REFERENCENO=@REFERENCENO,PANSTATUS = @PANSTATUS,EMPTYPE = @EMPTYPE                  
				WHERE BRANCHID = @BRANCHID AND DEDUCTEEID = @DEDUCTEEID; 		 						
			END	 
		END                                       		
		SELECT @DEDUCTEEID;                  
	END
GO

﻿//function to returns empty if the value is null 
function NonNullValue(value, type) {
    if (type == 'Field') {
        if (value == null)
            return "";
        else
            return value;
    }
    if (type == 'Date') {
        if (value == null) {
            return new Date();
        }
        else {
            return value;
        }
    }
    else if (type == 'ID') {
        if (value == null)
            return "-1";
        else
            return value;
    }
}

//function to clear the data in the fields .When type is FIELD it makes empty and type is ID it makes to -1
function ClearObjects(objectName, objectType) {
    if (objectType == 'Field') {
        objectName.value = "";
    }
    else if (objectType == 'ID') {
        objectName.value = -1;
    }
}
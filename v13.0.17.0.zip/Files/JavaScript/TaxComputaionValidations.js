﻿function CalaulateChapterVIADet(sectionID, objValue1, objValue2, hdn80DSelf, hdn80DParent, hdn80DD, hdn80DDB, hdn80U) {
    var condi1 = sectionID == "61" ? hdn80DSelf : (sectionID == "62" ? hdn80DParent : (sectionID == "7" ? hdn80DD : (sectionID == "8" ? hdn80DDB : hdn80U)));

    objValue2.value = objValue1.value;
    switch (sectionID) {
        case "4":
            if (Return(objValue2.value) > 100000)
                objValue2.value = 100000;
            break;
        case "61":
            if (condi1 == "1" && Return(objValue2.value) > 15000)
                objValue2.value = 15000;
            else if (condi1 == "0" && Return(objValue2.value) > 20000)
                objValue2.value = 20000;
            break;
        case "62":
            if (condi1 == "1" && Return(objValue2.value) > 15000)
                objValue2.value = 15000;
            else if (condi1 == "0" && Return(objValue2.value) > 20000)
                objValue2.value = 20000;
            break;
        case "7":
            if (condi1 == "1" && Return(objValue2.value) > 50000)
                objValue2.value = 50000;
            else if (condi1 == "0" && Return(objValue2.value) > 100000)
                objValue2.value = 100000;
            break;
        case "8":
            if (condi1 == "1" && Return(objValue2.value) > 40000)
                objValue2.value = 40000;
            else if (condi1 == "0" && Return(objValue2.value) > 60000)
                objValue2.value = 60000;
            break;
        case "11":
            if (Return(objValue2.value) > 24000)
                objValue2.value = 24000;
            break;
        case "12":
            if (Return(objValue2.value) > 300000)
                objValue2.value = 300000;
            break;
        case "13":
            if (Return(objValue2.value) > 300000)
                objValue2.value = 300000;
            break;
        case "14":
            if (condi1 == "1" && Return(objValue2.value) > 50000)
                objValue2.value = 50000;
            else if (condi1 == "0" && Return(objValue2.value) > 100000)
                objValue2.value = 100000;
            break;
        case "18":
            if (Return(objValue2.value) > 10000)
                objValue2.value = 10000;
            break;
        case "19":
            objValue2.value = Return(objValue1.value) / 2;
            if (Return(objValue2.value) > 25000)
                objValue2.value = 25000;
            break;
        case "22":
            if (Return(objValue2.value) > 100000)
                objValue2.value = 100000;
            break;
    }
    if (Return(objValue2.value) == 0)
        objValue2.value = "";
}

function SetValues(objValue1, objValue2, obj1, obj2, hdn80DD, hdn80DDB, hdn80U) {
    var limit = 0;
    if (objValue1 == 7) {
        limit = objValue2 == 1 ? 50000 : 100000;
        obj2.value = Return(obj1.value) <= limit ? Return(obj1.value) : limit;
        hdn80DD.value = objValue2 == "2" ? "0" : objValue2;
    }
    else if (objValue1 == 8) {
        limit = objValue2 == 1 ? 40000 : 60000;
        obj2.value = Return(obj1.value) <= limit ? Return(obj1.value) : limit;
        hdn80DDB.value = objValue2 == "2" ? "0" : objValue2;
    }
    else if (objValue1 == 14) {
        limit = objValue2 == 1 ? 50000 : 100000;
        obj2.value = Return(obj1.value) <= limit ? Return(obj1.value) : limit;
        hdn80U.value = objValue2 == "2" ? "0" : objValue2;
    }
    if (Return(obj2.value) == 0)
        obj2.value = "";
}
﻿     (function ($) {
         $.support.placeholder = ('placeholder' in document.createElement('input'));
     })(jQuery);


//fix for IE7 and IE8
$(function () {
    if (!$.support.placeholder) {
        $("[placeholder]").focus(function () {
            if ($(this).val() == $(this).attr("placeholder")) $(this).val("");
        }).blur(function () {
            if ($(this).val() == "") $(this).val($(this).attr("placeholder"));
        }).blur();

        $("[placeholder]").parents("form").submit(function () {
            $(this).find('[placeholder]').each(function() {
                if ($(this).val() == $(this).attr("placeholder")) {
                    $(this).val("");
                }
            });
        });
    }
});


$(function () {
    $('.amtfield').keyup(function () {
        if ($(this).val().indexOf('.') != -1) {
            if ($(this).val().split(".")[1].length > 2) {
                if (isNaN(parseFloat(this.value))) return;
                this.value = parseFloat(this.value).toFixed(2);
            }
        }
        return this;
    });
});

var value;
function ConvertStringToFloat(value) {
    //value = isNaN(parseFloat(value)) ? 0 : parseFloat(value);
    return parseFloat((new String(value) || '').replace(/,/g, '')) || 0;
}

var Section;
function GetNatureOfPaymentFromSection(Section)
{
    var split = Section.split('-');

    var NatureOfPayment = split[split.length - 1].substring(1);
    if (split[0] == "194E ") {
        NatureOfPayment = split[1].substring(1) + "-" + split[2];
    }
    return NatureOfPayment;
}

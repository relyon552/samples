﻿$(function () {
    debugger;
    $.validator.addMethod('date',
    function (value, element) {
        debugger;
        if (this.optional(element)) {
            return true;
        }
        var valid = true;
        try {
            $.datepicker.parseDate('dd/mm/yy', value);
        }
        catch (err) {
            valid = false;
        }
        return valid;
    });
    $(".Datepick").datepicker({ dateFormat: 'dd/mm/yy' });
});
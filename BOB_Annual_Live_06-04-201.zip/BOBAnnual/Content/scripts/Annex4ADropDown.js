﻿$(document).ready(function () {
   debugger;
    $('#CurrentDetail_CardCode').change(function () {

        CardCodeChange(this.value, false);
    });
    $('#CurrentDetail_BalanceOutstanding').change(function () {
        CalculateProvision();
        CalculateCurrentInterestAmount();
        CalculateProvisionAuditor();

    });
    $('#CurrentDetail_SecurityValue').change(function () {
        CalculateProvision();
        CalculateProvisionAuditor();
    });
    $('#CurrentDetail_ECGC').change(function () {
        CalculateProvision();
        CalculateProvisionAuditor();
    });
    //$('#CurrentDetail_BranchCurrentInterestReversalAmt').change(function () {
    //    CalculateProvision();
    //});

    $('#CurrentDetail_SecurityValueBranch').change(function () {
        debugger;
        CalculateProvision();

    });
    $('#CurrentDetail_SecurityValueAuditor').change(function () {
        debugger;
        CalculateProvisionAuditor();

    });


    $('#CurrentDetail_BranchAssetClassificationCode').change(function () {
        CalculateProvision();

    });
    //$('#CurrentDetail_AuditorPastInterestReversalAmt').change(function () {
    //    CalculateProvision();
    //});

    //$('#CurrentDetail_BranchPastInterestReversalAmt').change(function () {
    //    CalculateProvision();
    //});

    $('#CurrentDetail_AuditorCurrentInterestReversalAmt').change(function () {
        CalculateProvisionAuditor();
    });

    $('#CurrentDetail_BranchCurrentInterestReversalAmt').change(function () {
        CalculateProvision();
    });

    $('#CurrentDetail_AuditorAssetClassificationCode').change(function () {
        CalculateProvisionAuditor();

    });


    $(".edit").live("click", function (e) {
        debugger;
        e.preventDefault();
        if (!inEditMode) {
            inEditMode = true;
            $("#fixed-div :input").prop("disabled", false);
            $("#fixed-div :input[type=text], textarea").css({
                "background-color": "#fff"
            });

            var str = $(this).attr("id").split("_");
            id1 = str[1] + "_" + str[2];
            var id = "#CurrentDetail_";
            $(id + "BranchYearID").val(str[1]);
            $(id + "SlNo").val(str[2]);
            var CardCode = $("#spanCardCode_" + id1).text();
            $(id + "CardCode").val($.trim(CardCode));
            var CustomerID = $("#spanCustomerID_" + id1).text();
            $(id + "CustomerID").val($.trim(CustomerID));
            var PartyName = $("#spanPartyName_" + id1).text();
            $(id + "PartyName").val($.trim(PartyName));
            var AccNumber = $("#spanAccNumber_" + id1).text();
            $(id + "AccNumber").val($.trim(AccNumber));
            var TermCode = $("#spanTermCode_" + id1).text();
            $(id + "TermCode").val($.trim(TermCode));
            // catogary code changed as sector description

            var CategoryCode = $("#spanCategoryCode_" + id1).text();
            $(id + "CategoryCode").val($.trim(CategoryCode));

            //debugger;




            $('#CurrentDetail_CategoryCode').change(function () {
                // debugger;

                var CatogaryCode = $('#CurrentDetail_CategoryCode option:selected').val();
                if (CatogaryCode == "2.1" || CatogaryCode == "2.2" || CatogaryCode == "2.3" || CatogaryCode == "2.4") {
                    $("#IndustryCode").removeAttr('disabled');
                    $("#ServiceCode").val("");
                    $("#ServiceCode").hide();
                    $("#IndustryCode").show();
                }
                else if (CatogaryCode == "3.1" || CatogaryCode == "3.2" || CatogaryCode == "3.3" || CatogaryCode == "3.4") {
                    $("#IndustryCode").val("");
                    $("#IndustryCode").hide();
                    $("#ServiceCode").attr("disabled", false);
                    $("#ServiceCode").show();

                }
                else {
                    $("#IndustryCode").attr("disabled", true);
                    $("#ServiceCode").attr("disabled", true);
                    $("#IndustryCode").val('');
                    $("#ServiceCode").val('');
                }

            });

            var SecurityCode = $("#spanSecurityCode_" + id1).text();
            $(id + "SecurityCode").val($.trim(SecurityCode));
            var SecurityValue = $("#spanSecurityValue_" + id1).text();
            $(id + "SecurityValue").val($.trim(SecurityValue));
            var ECGC = $("#spanECGC_" + id1).text();
            $(id + "ECGC").val($.trim(ECGC));

            var spanSecurityValueBranch = $("#spanSecurityValueBranch_" + id1).text();
            $(id + "SecurityValueBranch").val($.trim(spanSecurityValueBranch));

            var spanSecurityValueAuditor = $("#spanSecurityValueAuditor_" + id1).text();
            $(id + "SecurityValueAuditor").val($.trim(spanSecurityValueAuditor));

            var BranchAssetClassificationCode = $("#spanBranchAssetClassificationCode_" + id1).text();
            BranchAssetClassificationCode = "B" + BranchAssetClassificationCode;
            $(id + "BranchAssetClassificationCode").val($.trim(BranchAssetClassificationCode));
            var AuditorAssetClassificationCode = $("#spanAuditorAssetClassificationCode_" + id1).text();
            $(id + "AuditorAssetClassificationCode").val($.trim(AuditorAssetClassificationCode));
            var DateOfNPA = $("#spanDateOfNPA_" + id1).text();
            $(id + "DateOfNPA").val($.trim(DateOfNPA));
            var BalanceOutstanding = $("#spanBalanceOutstanding_" + id1).text();
            $(id + "BalanceOutstanding").val($.trim(BalanceOutstanding));
            var BranchTotalProvisionAmt = $("#spanBranchTotalProvisionAmt_" + id1).text();
            $(id + "BranchTotalProvisionAmt").val($.trim(BranchTotalProvisionAmt));
            var AuditorTotalProvisionAmt = $("#spanAuditorTotalProvisionAmt_" + id1).text();
            $(id + "AuditorTotalProvisionAmt").val($.trim(AuditorTotalProvisionAmt));
            var BranchPastInterestReversalAmt = $("#spanBranchPastInterestReversalAmt_" + id1).text();
            $(id + "BranchPastInterestReversalAmt").val($.trim(BranchPastInterestReversalAmt));
            var AuditorPastInterestReversalAmt = $("#spanAuditorPastInterestReversalAmt_" + id1).text();
            $(id + "AuditorPastInterestReversalAmt").val($.trim(AuditorPastInterestReversalAmt));
            var BranchCurrentInterestReversalAmt = $("#spanBranchCurrentInterestReversalAmt_" + id1).text();
            $(id + "BranchCurrentInterestReversalAmt").val($.trim(BranchCurrentInterestReversalAmt));
            var AuditorCurrentInterestReversalAmt = $("#spanAuditorCurrentInterestReversalAmt_" + id1).text();
            $(id + "AuditorCurrentInterestReversalAmt").val($.trim(AuditorCurrentInterestReversalAmt));
            var IrregularitySBA = $("#spanIrregularitySBA_" + id1).text();
            $(id + "IrregularitySBA").val($.trim(IrregularitySBA));
            var IrregularityCSA = $("#spanIrregularityCSA_" + id1).text();
            $(id + "IrregularityCSA").val($.trim(IrregularityCSA));
            var ReplyOfBranch = $("#spanReplyOfBranch_" + id1).text();
            $(id + "ReplyOfBranch").val($.trim(ReplyOfBranch));

            // block total provision Amount for branch and auditor in edit mode

            $(id + "BranchTotalProvisionAmt").prop("readonly", true);
            $(id + "BranchTotalProvisionAmt").css({
                "background-color": "#FFFFD4"
            });
            $(id + "AuditorTotalProvisionAmt").prop("readonly", true);
            $(id + "AuditorTotalProvisionAmt").css({
                "background-color": "#FFFFD4"
            });
            UsrType = $('#UserType').val();
            if ((!IsAudit && IsEdit) && UsrType == 9) {
                // if ((!IsAudit && IsEdit) && Model.Master.UserType == 9) {
                

                $("#fixed-div :input[type=text], textarea").prop("readonly", true);
                $(id + "DateOfNPA").keydown(function (e) {
                    var charcode = e.keyCode || e.which;
                    if (charcode == 46)
                        return false;
                });
                $('option:not(:selected)').prop('disabled', true);
                $("#CurrentDetail_DateOfNPA").datepicker("destroy");
                $("#fixed-div :input[type=text], textarea, select").css({
                    "background-color": "#FFFFD4"
                });
                $("#popBoxInputCurrentDetail_ReplyOfBranch").prop("readonly", false);
                $(id + "ReplyOfBranch").prop("readonly", false);
                $(id + "ReplyOfBranch").css({
                    "background-color": "#FFF"
                });
                $("#popBoxInputCurrentDetail_ReplyOfBranch").css({
                    "background-color": "#FFF"
                });
            }
            if ($("#fixed-div :input").prop("disabled", false)) {
                $(".BtnDisabled").addClass("Btn");
                $(".BtnDisabled").removeClass("BtnDisabled");
            }
//$("#fixed-div :input").prop("readonly", true);
         //   $("#fixed-div :input,select").prop("disabled", true);
          // $('#btnSave').prop('disabled', false);
         //  $('#btnCancel').prop('disabled', false);

            if (CategoryCode == "2.1 " || CategoryCode == "2.2 " || CategoryCode == "2.3 " || CategoryCode == "2.4 ") {
                var IndustryCode = $("#spanIndustryCode_" + id1).text();
                $("#IndustryCode").removeAttr('disabled');
                $("#IndustryCode").val($.trim(IndustryCode));
                $("#ServiceCode").hide();
                $("#IndustryCode").show();
            }
            else if (CategoryCode == "3.1 " || CategoryCode == "3.2 " || CategoryCode == "3.3 " || CategoryCode == "3.4 ") {
                var ServiceCode = $("#spanIndustryCode_" + id1).text();
                $("#ServiceCode").removeAttr('disabled');
                $("#ServiceCode").val($.trim(ServiceCode));
                $("#IndustryCode").hide();
                $("#ServiceCode").show();

            }
            else {
                $("#IndustryCode").attr("disabled", true);
                $("#spanIndustryCode_" + id1).val("");
                $("#ServiceCode").val('');
            }

            CardCodeChange(CardCode, true);
        }
        else
            alert("Please Save or Cancel previous record!");
    });

    function CalculateCurrentInterestAmount() {
        var FYear = $('#FinancialYear').val();
        var queartlyRecord = "Q" + FYear.substring(4);
        var CardCode = $('#CurrentDetail_CardCode').val();
        var result = 0;
        if (CardCode == null || CardCode == '' || CardCode == 'PBE' || CardCode == 'PCE' || CardCode == 'PDE') {
            result = 0;
        }
        else {
            var amount = $('#CurrentDetail_BalanceOutstanding').val();
            amount = ConvertStringToFloat(amount);
            if (amount > 0) {
                if (queartlyRecord == 'Q1') {
                    result = ((amount * 18) * 0.25) / 100;
                }
                else if (queartlyRecord == 'Q2') {
                    result = ((amount * 18) * 0.50) / 100;
                }
                else if (queartlyRecord == 'Q3') {
                    result = ((amount * 18) * 0.75) / 100;
                }
                else if (queartlyRecord == 'Q4') {
                    result = (amount * 18) / 100;
                }
            }
        }
        result = Math.round(result);
        $('#CurrentDetail_CurrentInterestReversalCalculatedAmount').val(result);
    }
    var value;
    function ConvertStringToFloat(value) {
        value = isNaN(parseFloat(value)) ? 0 : parseFloat(value);
        return value;
    }
    // Swaping logic auditor to branch

    function CardCodeChange(DDSelectedvalue, FromEdit) {
        DDSelectedvalue = DDSelectedvalue.substring(0, 3);
        $("#CurrentDetail_BranchAssetClassificationCode > option").css({
            "color": "gray"
        });
        if (FromEdit == false) {
            $('#CurrentDetail_BranchAssetClassificationCode option:first-child').attr("selected", "selected");
        }
        RemoveReadOnly();
        ReadOnlyAndAssignValue("#CurrentDetail_ProvisionCalculatedAmount");
        ReadOnlyAndAssignValue("#CurrentDetail_CurrentInterestReversalCalculatedAmount");
        $('#CurrentDetail_BranchAssetClassificationCode').prop("disabled", false);
        $('#CurrentDetail_BranchAssetClassificationCode').css({
            "background-color": "#fff"
        });
        if (DDSelectedvalue == "PAA") {
            if (FromEdit == false) {
                $("#CurrentDetail_BranchAssetClassificationCode").val('');
                $("#CurrentDetail_AuditorAssetClassificationCode").val('');
            }
            $("#CurrentDetail_AuditorAssetClassificationCode > option[value='100']").removeAttr('disabled')
            $("#CurrentDetail_AuditorAssetClassificationCode > option[value='100']").css({
                "color": "black"
            });
            $("#CurrentDetail_BranchAssetClassificationCode > option[value='B201'],option[value=''] ,option[value='B202'] ,option[value='B310'],option[value='B320'],option[value='B330'],option[value='B400']").removeAttr('disabled');
            // $("#CurrentDetail_BranchAssetClassificationCode > option[value='B100']").removeAttr('disabled');
            $("#CurrentDetail_BranchAssetClassificationCode > option[value='B201'],option[value=''] ,option[value='B202'] ,option[value='B310'],option[value='B320'],option[value='B330'],option[value='B400']").css({
                "color": "black"
            });
            $("#CurrentDetail_AuditorAssetClassificationCode > option[value='201'],option[value=''] ,option[value='202'] ,option[value='310'],option[value='320'],option[value='330'],option[value='400']").attr('disabled', 'disabled');
            //ReadOnlyAndAssignValue("#CurrentDetail_AuditorTotalProvisionAmt");
            ReadOnlyAndAssignValue("#CurrentDetail_BranchTotalProvisionAmt");
            $("#CurrentDetail_AuditorAssetClassificationCode").css({
                "background-color": "#FFFFD4"
            });
            //$("#CurrentDetail_BranchAssetClassificationCode > option[value='B201'],option[value=''] ,option[value='B202'] ,option[value='B310'],option[value='B320'],option[value='B330'],option[value='B400']").attr('disabled', 'disabled');
            $("#CurrentDetail_BranchAssetClassificationCode > option[value='B100']").attr('disabled', 'disabled');

        }
        else if (DDSelectedvalue == "PBE") {
            if (FromEdit == false) {
                $("#CurrentDetail_AuditorAssetClassificationCode").val('');
            }
            $("#CurrentDetail_AuditorAssetClassificationCode > option[value='201'] ,option[value='202']").removeAttr('disabled');
            $("#CurrentDetail_AuditorAssetClassificationCode > option[value='201'] ,option[value='202']").css({
                "color": "black"
            });
            $("#CurrentDetail_AuditorAssetClassificationCode > option[value='100'] ,option[value=''],option[value='310'],option[value='320'],option[value='330'],option[value='400']").attr('disabled', 'disabled');

            $("#CurrentDetail_BranchAssetClassificationCode > option[value='B100']").removeAttr('disabled');
            $("#CurrentDetail_BranchAssetClassificationCode > option[value='B100'], option[value='B201'],option[value=''] ,option[value='B202'] ,option[value='B310'],option[value='B320'],option[value='B330'],option[value='B400']").css({
                "color": "black"
            });
            $("#CurrentDetail_BranchAssetClassificationCode > option[value='B201'],option[value='B202']").removeAttr('disabled');
            $("#CurrentDetail_BranchAssetClassificationCode > option[value='B100'], option[value=''],option[value='B310'],option[value='B320'],option[value='B330'],option[value='B400']").attr('disabled', 'disabled');
        }

        else if (DDSelectedvalue == "PBN") {

            if (FromEdit == false) {
                $("#CurrentDetail_AuditorAssetClassificationCode").val('');
            }
            $("#CurrentDetail_AuditorAssetClassificationCode > option[value='201'] ,option[value='202']").removeAttr('disabled');
            $("#CurrentDetail_AuditorAssetClassificationCode > option[value='201'] ,option[value='202']").css({
                "color": "black"
            });
            $("#CurrentDetail_AuditorAssetClassificationCode > option[value='100'] ,option[value=''],option[value='310'],option[value='320'],option[value='330'],option[value='400']").attr('disabled', 'disabled');
            $("#CurrentDetail_BranchAssetClassificationCode > option[value='B100'], option[value='B201'],option[value=''] ,option[value='B202'] ,option[value='B310'],option[value='B320'],option[value='B330'],option[value='B400']").css({
                "color": "black"
            });
            //$("#CurrentDetail_BranchAssetClassificationCode > option[value='B201'] ,option[value='B202']").removeAttr('disabled');
            //$("#CurrentDetail_BranchAssetClassificationCode > option[value='B201'] ,option[value='B202']").css({
            //    "color": "black"
            //});
            $("#CurrentDetail_BranchAssetClassificationCode > option[value='B100']").removeAttr('disabled');
            $("#CurrentDetail_BranchAssetClassificationCode > option[value='B201'], option[value='B202'], option[value=''],option[value='B310'],option[value='B320'],option[value='B330'],option[value='B400']").attr('disabled', 'disabled');
            //$("#CurrentDetail_AuditorAssetClassificationCode > option[value='100'], option[value='201'],option[value=''] ,option[value='202'] ,option[value='310'],option[value='320'],option[value='330'],option[value='400']").css({
            //    "color": "black"
            //});
        }
        else if (DDSelectedvalue == "PCE") {
            if (FromEdit == false) {
                $("#CurrentDetail_AuditorAssetClassificationCode").val('');
            }
            $("#CurrentDetail_AuditorAssetClassificationCode > option[value='310'] ,option[value='320'],option[value='330']").removeAttr('disabled');
            $("#CurrentDetail_AuditorAssetClassificationCode > option[value='310'] ,option[value='320'],option[value='330']").css({
                "color": "black"
            });
            $("#CurrentDetail_AuditorAssetClassificationCode > option[value='100'] ,option[value='201'],option[value='202'],option[value='400']").attr('disabled', 'disabled');
            $("#CurrentDetail_BranchAssetClassificationCode > option[value='B100'], option[value='B201'],option[value=''] ,option[value='B202'] ,option[value='B310'],option[value='B320'],option[value='B330'],option[value='B400']").css({
                "color": "black"
            });

            $("#CurrentDetail_BranchAssetClassificationCode > option[value='B201'],option[value='B202'],option[value='B310'],option[value='B320'],option[value='B330']").removeAttr('disabled')
            $("#CurrentDetail_BranchAssetClassificationCode > option[value='B100'], option[value=''],option[value='B400']").attr('disabled', 'disabled');
            //$("#CurrentDetail_BranchAssetClassificationCode > option[value='B310'] ,option[value='B320'],option[value='B330']").removeAttr('disabled');
            //$("#CurrentDetail_BranchAssetClassificationCode > option[value='B310'] ,option[value='B320'],option[value='B330']").css({
            //    "color": "black"
            //});
            //ReadOnlyAndAssignValue("#CurrentDetail_AuditorPastInterestReversalAmt");
            //ReadOnlyAndAssignValue("#CurrentDetail_AuditorCurrentInterestReversalAmt");
            //ReadOnlyAndAssignValue("#CurrentDetail_BranchPastInterestReversalAmt");
            //ReadOnlyAndAssignValue("#CurrentDetail_BranchCurrentInterestReversalAmt");

            //$("#CurrentDetail_AuditorAssetClassificationCode > option[value='100'], option[value='201'],option[value=''] ,option[value='202'] ,option[value='310'],option[value='320'],option[value='330'],option[value='400']").css({
            //    "color": "black"
            //});
        }
        else if (DDSelectedvalue == "PCN") {
            if (FromEdit == false) {
                $("#CurrentDetail_AuditorAssetClassificationCode").val('');
            }
            $("#CurrentDetail_AuditorAssetClassificationCode > option[value='310'] ,option[value='320'],option[value='330']").removeAttr('disabled');
            $("#CurrentDetail_AuditorAssetClassificationCode > option[value='310'] ,option[value='320'],option[value='330']").css({
                "color": "black"
            });
            $("#CurrentDetail_AuditorAssetClassificationCode > option[value='100'] ,option[value='201'],option[value='202'],option[value='400']").attr('disabled', 'disabled');
            $("#CurrentDetail_BranchAssetClassificationCode > option[value='B100'], option[value='B201'],option[value=''] ,option[value='B202'] ,option[value='B310'],option[value='B320'],option[value='B330'],option[value='B400']").css({
                "color": "black"
            });

            $("#CurrentDetail_BranchAssetClassificationCode > option[value='B100']").removeAttr('disabled')
            $("#CurrentDetail_BranchAssetClassificationCode > option[value='B201'], option[value='B202'], option[value=''],option[value='B310'],option[value='B320'],option[value='B330'],option[value='B400']").attr('disabled', 'disabled');
            //$("#CurrentDetail_BranchAssetClassificationCode > option[value='B310'] ,option[value='B320'],option[value='B330']").removeAttr('disabled');
            //$("#CurrentDetail_BranchAssetClassificationCode > option[value='B310'] ,option[value='B320'],option[value='B330']").css({
            //    "color": "black"
            //});
            //$("#CurrentDetail_BranchAssetClassificationCode > option[value='B100'] ,option[value=''],option[value='B201'],option[value='B202'],option[value='B400']").attr('disabled', 'disabled');
            //$("#CurrentDetail_AuditorAssetClassificationCode > option[value='100'], option[value='201'],option[value=''] ,option[value='202'] ,option[value='310'],option[value='320'],option[value='330'],option[value='400']").css({
            //    "color": "black"
            //});
        }
        else if (DDSelectedvalue == "PDE") {
            if (FromEdit == false) {
                $("#CurrentDetail_AuditorAssetClassificationCode").val('');
            }
            $("#CurrentDetail_AuditorAssetClassificationCode > option[value='400']").removeAttr('disabled');
            $("#CurrentDetail_AuditorAssetClassificationCode > option[value='400']").css({
                "color": "black"
            });
            //ReadOnlyAndAssignValue("#CurrentDetail_AuditorPastInterestReversalAmt");
            //ReadOnlyAndAssignValue("#CurrentDetail_AuditorCurrentInterestReversalAmt");
            //ReadOnlyAndAssignValue("#CurrentDetail_BranchPastInterestReversalAmt");
            //ReadOnlyAndAssignValue("#CurrentDetail_BranchCurrentInterestReversalAmt");
            $("#CurrentDetail_AuditorAssetClassificationCode > option[value='100'] ,option[value='201'],option[value='202'],option[value='310'],option[value='320'],option[value='330']").attr('disabled', 'disabled');
            $("#CurrentDetail_BranchAssetClassificationCode > option[value='B100'], option[value='B201'],option[value=''] ,option[value='B202'] ,option[value='B310'],option[value='B320'],option[value='B330'],option[value='B400']").css({
                "color": "black"
            });

            $("#CurrentDetail_BranchAssetClassificationCode > option[value='B201'],option[value='B202'],option[value='B310'],option[value='B320'],option[value='B330'],option[value='B400']").removeAttr('disabled')
            $("#CurrentDetail_BranchAssetClassificationCode > option[value='B100'], option[value='']").attr('disabled', 'disabled');
            //$("#CurrentDetail_AuditorAssetClassificationCode > option[value='100'], option[value='201'],option[value=''] ,option[value='202'] ,option[value='310'],option[value='320'],option[value='330'],option[value='400']").css({
            //    "color": "black"
            //});

        }
        else if (DDSelectedvalue == "PDN") {
            if (FromEdit == false) {
                $("#CurrentDetail_AuditorAssetClassificationCode").val('');
            }
            $("#CurrentDetail_AuditorAssetClassificationCode > option[value='400']").removeAttr('disabled');
            $("#CurrentDetail_AuditorAssetClassificationCode > option[value='400']").css({
                "color": "black"
            });
            $("#CurrentDetail_AuditorAssetClassificationCode > option[value='100'] ,option[value='201'],option[value='202'],option[value='310'],option[value='320'],option[value='330']").attr('disabled', 'disabled');
            $("#CurrentDetail_BranchAssetClassificationCode > option[value='B100'], option[value='B201'],option[value=''] ,option[value='B202'] ,option[value='B310'],option[value='B320'],option[value='B330'],option[value='B400']").css({
                "color": "black"
            });
            //$("#CurrentDetail_AuditorAssetClassificationCode > option[value='100'], option[value='201'],option[value=''] ,option[value='202'] ,option[value='310'],option[value='320'],option[value='330'],option[value='400']").css({
            //    "color": "black"
            //});
            $("#CurrentDetail_BranchAssetClassificationCode > option[value='B100']").removeAttr('disabled')
            $("#CurrentDetail_BranchAssetClassificationCode > option[value='B201'], option[value='B202'], option[value=''],option[value='B310'],option[value='B320'],option[value='B330'],option[value='B400']").attr('disabled', 'disabled');
        }
        if (DDSelectedvalue == "PDN" || DDSelectedvalue == "PDE" || DDSelectedvalue == "PAA") {
            //$('#CurrentDetail_AuditorAssetClassificationCode').prop("disabled", true);
            $('#CurrentDetail_BranchAssetClassificationCode').css({
                "background-color": "#FFFFD4"
            });
            $('#CurrentDetail_AuditorAssetClassificationCode').css({
                "background-color": "#FFFFD4"
            });
        }
        CalculateProvision();
        // CalculateProvisionAuditor();
        CalculateCurrentInterestAmount();

        return true;
    }
    //function CardCodeChange(DDSelectedvalue, FromEdit) {
    //    DDSelectedvalue = DDSelectedvalue.substring(0, 3);
    //    $("#CurrentDetail_AuditorAssetClassificationCode > option").css({
    //        "color": "gray"
    //    });
    //    if (FromEdit == false) {
    //        $('#CurrentDetail_AuditorAssetClassificationCode option:first-child').attr("selected", "selected");
    //    }
    //    RemoveReadOnly();
    //    ReadOnlyAndAssignValue("#CurrentDetail_ProvisionCalculatedAmount");
    //    ReadOnlyAndAssignValue("#CurrentDetail_CurrentInterestReversalCalculatedAmount");
    //    $('#CurrentDetail_AuditorAssetClassificationCode').prop("disabled", false);
    //    $('#CurrentDetail_AuditorAssetClassificationCode').css({
    //        "background-color": "#fff"
    //    });
    //    if (DDSelectedvalue == "PAA") {
    //        if (FromEdit == false) {
    //            $("#CurrentDetail_AuditorAssetClassificationCode").val(100);
    //        }
    //        $("#CurrentDetail_AuditorAssetClassificationCode > option[value='100']").removeAttr('disabled');
    //        $("#CurrentDetail_AuditorAssetClassificationCode > option[value='100']").css({
    //            "color": "black"
    //        });
    //        ReadOnlyAndAssignValue("#CurrentDetail_AuditorTotalProvisionAmt");
    //        ReadOnlyAndAssignValue("#CurrentDetail_BranchTotalProvisionAmt");
    //        $("#CurrentDetail_AuditorAssetClassificationCode > option[value='201'],option[value=''] ,option[value='202'] ,option[value='310'],option[value='320'],option[value='330'],option[value='400']").attr('disabled', 'disabled');
    //    }
    //    else if (DDSelectedvalue == "PBE") {
    //        $("#CurrentDetail_AuditorAssetClassificationCode > option[value='201'] ,option[value='202']").removeAttr('disabled');
    //        $("#CurrentDetail_AuditorAssetClassificationCode > option[value='201'] ,option[value='202']").css({
    //            "color": "black"
    //        });
    //        ReadOnlyAndAssignValue("#CurrentDetail_AuditorPastInterestReversalAmt");
    //        ReadOnlyAndAssignValue("#CurrentDetail_AuditorCurrentInterestReversalAmt");
    //        ReadOnlyAndAssignValue("#CurrentDetail_BranchPastInterestReversalAmt");
    //        ReadOnlyAndAssignValue("#CurrentDetail_BranchCurrentInterestReversalAmt");
    //        $("#CurrentDetail_AuditorAssetClassificationCode > option[value='100'] ,option[value=''],option[value='310'],option[value='320'],option[value='330'],option[value='400']").attr('disabled', 'disabled');
    //    }
    //    else if (DDSelectedvalue == "PBN") {
    //        $("#CurrentDetail_AuditorAssetClassificationCode > option[value='201'] ,option[value='202']").removeAttr('disabled');
    //        $("#CurrentDetail_AuditorAssetClassificationCode > option[value='201'] ,option[value='202']").css({
    //            "color": "black"
    //        });
    //        $("#CurrentDetail_AuditorAssetClassificationCode > option[value='100'] ,option[value=''],option[value='310'],option[value='320'],option[value='330'],option[value='400']").attr('disabled', 'disabled');
    //    }
    //    else if (DDSelectedvalue == "PCE") {
    //        $("#CurrentDetail_AuditorAssetClassificationCode > option[value='310'] ,option[value='320'],option[value='330']").removeAttr('disabled');
    //        $("#CurrentDetail_AuditorAssetClassificationCode > option[value='310'] ,option[value='320'],option[value='330']").css({
    //            "color": "black"
    //        });
    //        ReadOnlyAndAssignValue("#CurrentDetail_AuditorPastInterestReversalAmt");
    //        ReadOnlyAndAssignValue("#CurrentDetail_AuditorCurrentInterestReversalAmt");
    //        ReadOnlyAndAssignValue("#CurrentDetail_BranchPastInterestReversalAmt");
    //        ReadOnlyAndAssignValue("#CurrentDetail_BranchCurrentInterestReversalAmt");
    //        $("#CurrentDetail_AuditorAssetClassificationCode > option[value='100'] ,option[value='201'],option[value='202'],option[value='400']").attr('disabled', 'disabled');
    //    }
    //    else if (DDSelectedvalue == "PCN") {
    //        $("#CurrentDetail_AuditorAssetClassificationCode > option[value='310'] ,option[value='320'],option[value='330']").removeAttr('disabled');
    //        $("#CurrentDetail_AuditorAssetClassificationCode > option[value='310'] ,option[value='320'],option[value='330']").css({
    //            "color": "black"
    //        });
    //        $("#CurrentDetail_AuditorAssetClassificationCode > option[value='100'] ,option[value=''],option[value='201'],option[value='202'],option[value='400']").attr('disabled', 'disabled');
    //    }
    //    else if (DDSelectedvalue == "PDE") {
    //        if (FromEdit == false) {
    //            $("#CurrentDetail_AuditorAssetClassificationCode").val(400);
    //        }
    //        $("#CurrentDetail_AuditorAssetClassificationCode > option[value='400']").removeAttr('disabled');
    //        $("#CurrentDetail_AuditorAssetClassificationCode > option[value='400']").css({
    //            "color": "black"
    //        });
    //        ReadOnlyAndAssignValue("#CurrentDetail_AuditorPastInterestReversalAmt");
    //        ReadOnlyAndAssignValue("#CurrentDetail_AuditorCurrentInterestReversalAmt");
    //        ReadOnlyAndAssignValue("#CurrentDetail_BranchPastInterestReversalAmt");
    //        ReadOnlyAndAssignValue("#CurrentDetail_BranchCurrentInterestReversalAmt");
    //        $("#CurrentDetail_AuditorAssetClassificationCode > option[value='100'] ,option[value='201'],option[value='202'],option[value='310'],option[value='320'],option[value='330']").attr('disabled', 'disabled');

    //    }
    //    else if (DDSelectedvalue == "PDN") {
    //        if (FromEdit == false) {
    //            $("#CurrentDetail_AuditorAssetClassificationCode").val(400);
    //        }
    //        $("#CurrentDetail_AuditorAssetClassificationCode > option[value='400']").removeAttr('disabled');
    //        $("#CurrentDetail_AuditorAssetClassificationCode > option[value='400']").css({
    //            "color": "black"
    //        });
    //        $("#CurrentDetail_AuditorAssetClassificationCode > option[value='100'] ,option[value='201'],option[value='202'],option[value='310'],option[value='320'],option[value='330']").attr('disabled', 'disabled');
    //    }
    //    if (DDSelectedvalue == "PDN" || DDSelectedvalue == "PDE" || DDSelectedvalue == "PAA") {
    //        //$('#CurrentDetail_AuditorAssetClassificationCode').prop("disabled", true);
    //        $('#CurrentDetail_AuditorAssetClassificationCode').css({
    //            "background-color": "#FFFFD4"
    //        });
    //    }
    //    CalculateProvision();
    //    CalculateCurrentInterestAmount();
    //    return true;
    //}

    //function CalculateProvision() {
    //    var ProvisionResult = 0;
    //    var AssetCode = $('#CurrentDetail_AuditorAssetClassificationCode').val();
    //    if (AssetCode == null || AssetCode == '' || AssetCode == '100') {
    //    }
    //    else {
    //        //Get Values
    //        var BalOut = ConvertStringToFloat($('#CurrentDetail_BalanceOutstanding').val());
    //        var AudPstIntAmt = ConvertStringToFloat($('#CurrentDetail_AuditorPastInterestReversalAmt').val());
    //        var BrnchPstIntResAmt = ConvertStringToFloat($('#CurrentDetail_BranchPastInterestReversalAmt').val());
    //        var AudCurrntIntAmt = ConvertStringToFloat($('#CurrentDetail_AuditorCurrentInterestReversalAmt').val());
    //        var BrnchCurrntIntAmt = ConvertStringToFloat($('#CurrentDetail_BranchCurrentInterestReversalAmt').val());
    //        var ECGC = ConvertStringToFloat($('#CurrentDetail_ECGC').val());
    //        //Calculate
    //        var ProvisionResult = BalOut - AudPstIntAmt + BrnchPstIntResAmt - AudCurrntIntAmt + BrnchCurrntIntAmt;
    //        if (ProvisionResult > BalOut)
    //        {
    //            ProvisionResult = BalOut;
    //        }
    //        //Reduce ECGC
    //        if (AssetCode == '201' || AssetCode == '202' || AssetCode == '310' || AssetCode == '320' || AssetCode == '330') {
    //            ProvisionResult = ProvisionResult - ECGC;
    //        }
    //        //Apply percentage
    //        if (AssetCode == '201') {
    //            ProvisionResult = (ProvisionResult * 15) / 100;
    //        }
    //        else if (AssetCode == '202') {

    //            ProvisionResult = (ProvisionResult * 25) / 100;
    //        }
    //    }
    //    ProvisionResult = Math.round(ProvisionResult);
    //    $('#CurrentDetail_ProvisionCalculatedAmount').val(ProvisionResult);
    //}

    // New Caclculation for branch Totalprovision 

    //function CalculateProvision() {
    //    debugger;
    //    var ProvisionResult = 0;
    //    var AssetCode = $('#CurrentDetail_BranchAssetClassificationCode').val();
    //    var RealBalance = 0;
    //    var A = 0;
    //    var B = 0;
    //    var BalOut = ConvertStringToFloat($('#CurrentDetail_BalanceOutstanding').val());
    //    var BranchCurrentReversal = ConvertStringToFloat($('#CurrentDetail_BranchCurrentInterestReversalAmt').val());
    //    // var AuditorCurrentReversal = ConvertStringToFloat($('#CurrentDetail_AuditorCurrentInterestReversalAmt').val());
    //    // Get Real Balance
    //    RealBalance = BalOut - BranchCurrentReversal;
    //    if (AssetCode == 'B201') {
    //        ProvisionResult = RealBalance * 0.15;
    //    }
    //    if (AssetCode == 'B202') {
    //        ProvisionResult = RealBalance * 0.25;
    //    }
    //    //   var SecurityVal = ConvertStringToFloat($('#CurrentDetail_SecurityValue').val());
    //    var SecurityVal = ConvertStringToFloat($('#CurrentDetail_SecurityValueBranch').val());

    //    A = RealBalance - SecurityVal;
    //    var ECGC = ConvertStringToFloat($('#CurrentDetail_ECGC').val());
    //    B = A - ECGC;
    //    if (SecurityVal > RealBalance) {

    //        if (AssetCode == 'B310') {
    //            ProvisionResult = RealBalance * 0.25;
    //        }
    //        else if (AssetCode == 'B320') {
    //            ProvisionResult = RealBalance * 0.40;
    //        }
    //        else if (AssetCode == 'B330' || AssetCode == 'B400') {
    //            ProvisionResult = RealBalance;
    //        }
    //    }
    //    else {
    //        //if (AssetCode == 'B201') {
    //        //    ProvisionResult = (SecurityVal * 0.15) + B;
    //        //}
    //        if (AssetCode == 'B310') {
    //            //debugger;
    //            ProvisionResult = (SecurityVal * 0.25) + ((B > 0) ? B : 0);
    //        }
    //        else if (AssetCode == 'B320') {
    //            ProvisionResult = (SecurityVal * 0.40) + ((B > 0) ? B : 0);
    //        }
    //        else if (AssetCode == 'B330' || AssetCode == 'B400') {
    //            ProvisionResult = SecurityVal + ((B > 0) ? B : 0);
    //        }
    //    }

    //    ProvisionResult = Math.round(ProvisionResult);
    //    $('#CurrentDetail_BranchTotalProvisionAmt').val(ProvisionResult);
    //}

    function CalculateProvision() {
        debugger;
        var ProvisionResult = 0;
        var AssetCode = $('#CurrentDetail_BranchAssetClassificationCode').val();
        var RealBalance = 0;
        var A = 0;
        var B = 0;
        var BalOut = ConvertStringToFloat($('#CurrentDetail_BalanceOutstanding').val());
        var BranchCurrentReversal = ConvertStringToFloat($('#CurrentDetail_BranchCurrentInterestReversalAmt').val());
        // var AuditorCurrentReversal = ConvertStringToFloat($('#CurrentDetail_AuditorCurrentInterestReversalAmt').val());
        // Get Real Balance
        RealBalance = BalOut - BranchCurrentReversal;
        if (AssetCode == 'B201') {
            ProvisionResult = RealBalance * 0.15;
        }
        if (AssetCode == 'B202') {
            ProvisionResult = RealBalance * 0.25;
        }
        //  var SecurityVal = ConvertStringToFloat($('#CurrentDetail_SecurityValue').val());
        var SecurityVal = ConvertStringToFloat($('#CurrentDetail_SecurityValueBranch').val());

        A = RealBalance - SecurityVal;
        var ECGC = ConvertStringToFloat($('#CurrentDetail_ECGC').val());
        B = A - ECGC;
        if (SecurityVal > RealBalance) {

            if (AssetCode == 'B310') {
                ProvisionResult = RealBalance * 0.25;
            }
            else if (AssetCode == 'B320') {
                ProvisionResult = RealBalance * 0.40;
            }
            else if (AssetCode == 'B330' || AssetCode == 'B400') {
                ProvisionResult = RealBalance;
            }
        }
        else {
            //if (AssetCode == 'B201') {
            //    ProvisionResult = (SecurityVal * 0.15) + B;
            //}
            if (AssetCode == 'B310') {
                //debugger;
                ProvisionResult = (SecurityVal * 0.25) + ((B > 0) ? B : 0);
            }
            else if (AssetCode == 'B320') {
                ProvisionResult = (SecurityVal * 0.40) + ((B > 0) ? B : 0);
            }
            else if (AssetCode == 'B330' || AssetCode == 'B400') {
                ProvisionResult = SecurityVal + ((B > 0) ? B : 0);
            }
        }

        ProvisionResult = Math.round(ProvisionResult);
        $('#CurrentDetail_BranchTotalProvisionAmt').val(ProvisionResult);
    }


    // Provision Amount for Auditor 

    //function CalculateProvisionAuditor() {
    //    debugger;
    //    var ProvisionResultAuditor = 0;
    //    var AssetCodeAuditor = $('#CurrentDetail_AuditorAssetClassificationCode').val();
    //    var RealBalance = 0;
    //    var A = 0;
    //    var B = 0;
    //    var BalOut = ConvertStringToFloat($('#CurrentDetail_BalanceOutstanding').val());
    //    var AuditorCurrentReversal = ConvertStringToFloat($('#CurrentDetail_AuditorCurrentInterestReversalAmt').val());
    //    // Get Real Balance
    //    RealBalance = BalOut - AuditorCurrentReversal;

    //    if (AssetCodeAuditor == '201') {
    //        ProvisionResultAuditor = RealBalance * 0.15;
    //    }
    //    if (AssetCodeAuditor == '202') {
    //        ProvisionResultAuditor = RealBalance * 0.25;
    //    }
    //    //  var SecurityVal = ConvertStringToFloat($('#CurrentDetail_SecurityValue').val());
    //    var SecurityVal = ConvertStringToFloat($('#CurrentDetail_SecurityValueAuditor').val());

    //    A = RealBalance - SecurityVal;
    //    var ECGC = ConvertStringToFloat($('#CurrentDetail_ECGC').val());
    //    B = A - ECGC;
    //    if (SecurityVal > RealBalance) {

    //        if (AssetCodeAuditor == '310') {
    //            ProvisionResultAuditor = RealBalance * 0.25;
    //        }
    //        else if (AssetCodeAuditor == '320') {
    //            ProvisionResultAuditor = RealBalance * 0.40;
    //        }
    //        else if (AssetCodeAuditor == '330' || AssetCodeAuditor == '400') {
    //            ProvisionResultAuditor = RealBalance;
    //        }
    //    }
    //    else {
    //        //if (AssetCodeAuditor == '201') {
    //        //    ProvisionResultAuditor = (SecurityVal * 0.15) + B;
    //        //}
    //        if (AssetCodeAuditor == '310') {
    //            ProvisionResultAuditor = (SecurityVal * 0.25) + ((B > 0) ? B : 0);
    //        }
    //        else if (AssetCodeAuditor == '320') {
    //            ProvisionResultAuditor = (SecurityVal * 0.40) + ((B > 0) ? B : 0);
    //        }
    //        else if (AssetCodeAuditor == '330' || AssetCodeAuditor == '400') {
    //            ProvisionResultAuditor = SecurityVal + ((B > 0) ? B : 0);
    //        }
    //    }
    //    ProvisionResultAuditor = Math.round(ProvisionResultAuditor);
    //    $('#CurrentDetail_AuditorTotalProvisionAmt').val(ProvisionResultAuditor);
    //}




    function CalculateProvisionAuditor() {
        debugger;
        var ProvisionResultAuditor = 0;
        var AssetCodeAuditor = $('#CurrentDetail_AuditorAssetClassificationCode').val();
        var RealBalance = 0;
        var A = 0;
        var B = 0;
        var BalOut = ConvertStringToFloat($('#CurrentDetail_BalanceOutstanding').val());
        var AuditorCurrentReversal = ConvertStringToFloat($('#CurrentDetail_AuditorCurrentInterestReversalAmt').val());
        // Get Real Balance
        RealBalance = BalOut - AuditorCurrentReversal;

        if (AssetCodeAuditor == '201') {
            ProvisionResultAuditor = RealBalance * 0.15;
        }
        if (AssetCodeAuditor == '202') {
            ProvisionResultAuditor = RealBalance * 0.25;
        }
        var SecurityVal = ConvertStringToFloat($('#CurrentDetail_SecurityValueAuditor').val());

        A = RealBalance - SecurityVal;
        var ECGC = ConvertStringToFloat($('#CurrentDetail_ECGC').val());
        B = A - ECGC;
        if (SecurityVal > RealBalance) {

            if (AssetCodeAuditor == '310') {
                ProvisionResultAuditor = RealBalance * 0.25;
            }
            else if (AssetCodeAuditor == '320') {
                ProvisionResultAuditor = RealBalance * 0.40;
            }
            else if (AssetCodeAuditor == '330' || AssetCodeAuditor == '400') {
                ProvisionResultAuditor = RealBalance;
            }
        }
        else {
            //if (AssetCodeAuditor == '201') {
            //    ProvisionResultAuditor = (SecurityVal * 0.15) + B;
            //}
            if (AssetCodeAuditor == '310') {
                ProvisionResultAuditor = (SecurityVal * 0.25) + ((B > 0) ? B : 0);
            }
            else if (AssetCodeAuditor == '320') {
                ProvisionResultAuditor = (SecurityVal * 0.40) + ((B > 0) ? B : 0);
            }
            else if (AssetCodeAuditor == '330' || AssetCodeAuditor == '400') {
                ProvisionResultAuditor = SecurityVal + ((B > 0) ? B : 0);
            }
        }
        ProvisionResultAuditor = Math.round(ProvisionResultAuditor);
        $('#CurrentDetail_AuditorTotalProvisionAmt').val(ProvisionResultAuditor);
    }




    function ReadOnlyAndAssignValue(id) {
        $(id).val(0);
        $(id).attr('readonly', true);
        $(id).css({
            "background-color": "#FFFFD4"
        });
    }

    function RemoveReadOnly() {
        //$("#CurrentDetail_AuditorPastInterestReversalAmt").val("");
        $("#CurrentDetail_AuditorPastInterestReversalAmt").attr('readonly', false);
        $("#CurrentDetail_AuditorPastInterestReversalAmt").css({
            "background-color": "#FFF"
        });
        //$("#CurrentDetail_AuditorCurrentInterestReversalAmt").val("");
        $("#CurrentDetail_AuditorCurrentInterestReversalAmt").attr('readonly', false);
        $("#CurrentDetail_AuditorCurrentInterestReversalAmt").css({
            "background-color": "#FFF"
        });
        //$("#CurrentDetail_BranchPastInterestReversalAmt").val("");
        $("#CurrentDetail_BranchPastInterestReversalAmt").attr('readonly', false);
        $("#CurrentDetail_BranchPastInterestReversalAmt").css({
            "background-color": "#FFF"
        });
        //$("#CurrentDetail_BranchCurrentInterestReversalAmt").val("");
        $("#CurrentDetail_BranchCurrentInterestReversalAmt").attr('readonly', false);
        $("#CurrentDetail_BranchCurrentInterestReversalAmt").css({
            "background-color": "#FFF"
        });
        //$("#CurrentDetail_AuditorTotalProvisionAmt").val("");
        //$("#CurrentDetail_AuditorTotalProvisionAmt").attr('readonly', false);
        //$("#CurrentDetail_AuditorTotalProvisionAmt").css({
        //    "background-color": "#FFF"
        //});
        //$("#CurrentDetail_BranchTotalProvisionAmt").val("");
        //$("#CurrentDetail_BranchTotalProvisionAmt").attr('readonly', false);
        //$("#CurrentDetail_BranchTotalProvisionAmt").css({
        //    "background-color": "#FFF"
        //});
    }

});

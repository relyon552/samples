﻿$(document).ready(function () {
    
    IsAudit = (($('#IsAuditing').val() == "True") ? true : false);
    IsEdit = (($('#IsEditable').val() == "True") ? true : false);

    var somethingChanged = false;
    $("input[type='text']").change(function () {
        somethingChanged = true;
    });
    $("select").change(function () {
        somethingChanged = true;
    });
    $("textarea").live("change", function (e) {
        somethingChanged = true;
    });

    $('.submitNext').live("click", function (e) {
        //debugger;
        if (IsEdit && somethingChanged) {
            var flag = confirm('Do you want continue without saving ?');
            if (!flag) {
                e.preventDefault();
            }
        }
    });
    $('.submitPrevious').live("click", function (e) {

        if (IsEdit && somethingChanged) {
            var flag = confirm('Do you want continue without saving ?');
            if (!flag) {
                e.preventDefault();
            }
        }
    });
    $('.submitMain').live("click", function (e) {

        if (IsEdit && somethingChanged) {
            var flag = confirm('Do you want continue without saving ?');
            if (!flag) {
                e.preventDefault();
            }
        }
    });
});

IF EXISTS(SELECT NAME FROM sys.objects WHERE type = 'P' AND name = 'USP_TDS_GetDBList')
DROP PROCEDURE USP_TDS_GetDBList
GO
CREATE PROCEDURE USP_TDS_GetDBList  --USP_TDS_GetDBList 'SARALTDSTEST'
@dbName VARCHAR(50)  
AS  
BEGIN  
	SELECT name DBName
	FROM master..sysdatabases  
	WHERE name LIKE @dbName + '%'
	AND LEN(@dbName) + 4 = LEN(name)
END  
GO

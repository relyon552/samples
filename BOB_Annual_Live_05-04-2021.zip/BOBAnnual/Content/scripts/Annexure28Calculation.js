﻿$(document).ready(function () {
    $("input[type='text']").keyup(function () {
        if ($(this).attr('readonly')) {
            return;
        }
        var tr = $(this).closest('tr');
        var inputs = tr.find('td input');
        var index = inputs.index(this);
        var secLen = 3;
        var effIndex = index % secLen;
        var group = [];
        for (var i = 0; i < secLen; i++) {
            group.push(effIndex + i * secLen);
        }
        var total = 0;
        for (var i = 0; i < group.length; i++) {
            total += +inputs.eq(group[i]).val() || 0;
        }
        var iRow = tr.attr('id').split('-').pop();
        $("#details-total-row-" + iRow + " input[readonly]").eq(effIndex).val(total);
        total = 0;
        tr.parent().find(".details-row").each(function (iTr, tr) {
            total += +$(tr).find("input").eq(index).val() || 0;
        });
        var summRow = tr.parent().find("#data-summary-row");
        if (!summRow.length) { return; }
        var totalinputs = summRow.find("input[readonly]")
        totalinputs.eq(index).val(total);
        total = 0;
        for (var i = 0; i < group.length; i++) {
            total += +totalinputs.eq(group[i]).val() || 0;
        }
        $("#details-total-row-0 input[readonly]").eq(effIndex).val(total);
    });
});
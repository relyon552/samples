﻿$(document).ready(function () {
$("input[type='text']").keyup(function () {
    if ($(this).attr('readonly')) {
        return;
    }
    var inputs = $(this).closest('tr').find('td input');
    var index = inputs.index(this);
    var secLen = 3;
    var effIndex = index % secLen;
    var group = [];
    for (var i = 0; i < secLen; i++) {
        group.push(effIndex + i * secLen);
    }
    var sum = 0;
    for (var i = 0; i < group.length; i++) {
        sum += +inputs[group[i]].value || 0;
    }
    $("#totals input[readonly]").eq(effIndex).val(sum);
});
});
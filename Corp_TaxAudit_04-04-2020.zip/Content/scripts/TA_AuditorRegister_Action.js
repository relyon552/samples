﻿//$(document).ready(function () {

function OnBegin1() {
    $("#divmsg").html("Saving Record...");

}

function OnFailure(data) {
    alert(data);
}

function OnSuccess1(data) {
    debugger;
    
    // if (data.result) {
    if (data.result=="True") {
      //  $("#divmsg").html("Record saved successfully !");
        alert("Record saved successfully.");
        setTimeout(function () {
      //  var url= '@Url.Action("TA_AuditorRegister_Action", "Annexure")';
           location.reload();
        }, 500);

      //      location.href=url + "/" +116 + "?" + 434 ;

        
    }
    else if (data.result == "Uploaded") {
        alert("Invoice is already generated and Uploaded.So you cannot Save.");
        setTimeout(function () {
            //  var url= '@Url.Action("TA_AuditorRegister_Action", "Annexure")';
            location.reload();
        }, 500);
    }

    // else if (data.hasOwnProperty('result') && data.result === false) {
    else if (data.hasOwnProperty('result') && data.result=="False") {
        var $form1 = $('#form0');
        $form1.data('submitted', false);
        $("#divmsg").html('');
        //clear validation summary error
        $("#fixed-div").find("[data-valmsg-summary=true]")
           .find("ul").empty();
        if (data.hasOwnProperty('allErrors')) {
            var errorhtml = "<ul>";
            $.each(data.allErrors, function (i, val) {
                errorhtml = errorhtml + "<li><strong>" + val.ErrorMessage + "</strong></li>";
            });
            errorhtml = errorhtml + "</ul>";
            $("#servererror").html(errorhtml);
            setTimeout(CheckHeightChange, 150);
        }
        else {
            alert("There is some error in saving. Please try again");
        }
    }

    //else {
    //    var contains = (data.indexOf('Sign In') > -1);
    //    if (contains) {
    //        location.reload();
    //    }
    //}
}


function CheckHeightChange() {
    debugger;
    var heightOfFixedDiv = $("#fixed-div").height();
    var heightChanged = heightOfFixedDiv - 45;
    $("#gridview1").css({
        "width": "100%",
        //"margin-left": "-5px"
    });
    $("html, body").animate({ scrollTop: 0 }, "slow");
};




$(document).ready(function () {
    $.validator.methods.date = function (value, element) {
        return this.optional(element) || $.datepicker.parseDate('dd/mm/yy', value);
    }
    

    $("body").on("keydown", ".Datepick", function (event) {
        if (event.keyCode == 46) {
         //   $("#CurrentDetail_DateOfNPA").val("");
        }
        else if (event.keyCode != 9)
            event.preventDefault();
    });

    $(".Datepick").datepicker({
        changeMonth: true,
        changeYear: true,
         dateFormat: 'dd/mm/yy',
     //   dateFormat: 'yy-mm-dd',
        yearRange: "-50:+20"
    });// end of date picker

    //$('#btnSave').click(function (e) {
    //    debugger;
        
    //    var form1Elem = $('#form1');
    //    form1Elem.validate();
    //    if (!form1Elem.valid()) {
    //        e.preventDefault();
    //        return false;
    //    }
        
    //});

    jQuery.fn.preventDoubleSubmission = function () {
        debugger;
        $(this).on('submit', function (e) {
            var $form = $(this);
            if ($form.data('submitted') === true) {
                return false;
                e.preventDefault();
            } else if ($form.valid()) {
                $form.data('submitted', true);
            }
        });
        return this;
    };
    $('#form0').preventDoubleSubmission();

    $("#btnSave").live("click", function (e) {

        //var TypeOfAccount = $("#TypeOfAccount").val();
        //if (TypeOfAccount == 0)
        //{
        //    alert("Please Select Type of Account");
        //    return false;
        //}
        //var AuditWork = $("#AuditWork").val();
        //if (AuditWork == 0) {
        //    alert("Please Select Audit Work");
        //    return false;
        //}



        $("#servererror").html('');
      //  setTimeout(CheckHeightChange, 150);
    });
    //$("#LFARFeePercentage").change(function () {
    //    var basicFee = $("#BasicAuditFee").val();
    //    var percFeeForLFAR = $("#LFARFeePercentage").val();
    //    if (basicFee != "" && basicFee != undefined && percFeeForLFAR != null && percFeeForLFAR != undefined) {
    //        $("#FeeForLFAR").val((percFeeForLFAR / 100) * basicFee);
    //    }
    //    else {
    //        $("#FeeForLFAR").val(0);
    //    }
    //});




    //$("#TDSTaxPercentage").change(function () {
    //    var basicFee = $("#BasicAuditFee").val();
    //    var percFeeForTDS = $("#TDSTaxPercentage").val();
    //    if (basicFee != "" && basicFee != undefined && percFeeForTDS != null && percFeeForTDS != undefined) {
    //        $("#FeeForTDSTaxValue").val((percFeeForTDS / 100) * basicFee);
    //    }
    //    else {
    //        $("#FeeForTDSTaxValue").val(0);
    //    }
    //});

    //$("#GSTTaxPercentage").change(function () {
    //    var basicFee = $("#BasicAuditFee").val();
    //    var percFeeForGST = $("#GSTTaxPercentage").val();
    //    if (basicFee != "" && basicFee != undefined && percFeeForGST != null && percFeeForGST != undefined) {
    //        $("#FeeForGSTTaxValue").val((percFeeForGST / 100) * basicFee);
    //    }
    //    else {
    //        $("#FeeForGSTTaxValue").val(0);
    //    }
    //});

   
   



    //$("#TaxAuditFeePercentage").change(function () {
    //    debugger;
    //    var basicFee = $("#BasicAuditFee").val();
    //    var percFeeForTaxAudit = $("#TaxAuditFeePercentage").val();
    //    if (basicFee != "" && basicFee != undefined && percFeeForTaxAudit != null && percFeeForTaxAudit != undefined) {
    //        $("#FeeForTaxAudit").val((percFeeForTaxAudit / 100) * basicFee);
    //    }
    //    else {
    //        $("#FeeForTaxAudit").val(0);
    //    }
    //});
    //$("#ServiceTaxPercentage").change(function () {
    //    var totalFee = $("#txtTotalFee").val();

    //    var percFeeForServiceTax = $("#ServiceTaxPercentage").val();
    //    if (totalFee != "" && totalFee != undefined && percFeeForServiceTax != null && percFeeForServiceTax != undefined) {
    //        $("#ServiceTax").val((percFeeForServiceTax / 100) * totalFee);
    //    }
    //    else {
    //        $("#ServiceTax").val(0);
    //    }
    //});
    //$("#IncomeTaxPercentage").change(function () {
    //    var totalFee = $("#txtTotalFee").val();
    //    var percFeeForIncomeTax = $("#IncomeTaxPercentage").val();
    //    if (totalFee != "" && totalFee != undefined && percFeeForIncomeTax != null && percFeeForIncomeTax != undefined) {
    //        $("#IncomeTax").val((percFeeForIncomeTax / 100) * totalFee);
    //    }
    //    else {
    //        $("#IncomeTax").val(0);
    //    }
    //});

    //var total = $('#BasicAuditFee,#LFARFeePercentage,#TaxAuditFeePercentage'), basicAuditFee = $("#BasicAuditFee"),
    //    feeForLFAR = $("#FeeForLFAR"), feeForTaxAudit = $("#FeeForTaxAudit"), txtTotalFee = $("#txtTotalFee");

    //total.change(function () {
    //    var val1 = (isNaN(parseInt(basicAuditFee.val()))) ? 0 : parseInt(basicAuditFee.val());
    //    var val2 = (isNaN(parseInt(feeForLFAR.val()))) ? 0 : parseInt(feeForLFAR.val());
    //    var val3 = (isNaN(parseInt(feeForTaxAudit.val()))) ? 0 : parseInt(feeForTaxAudit.val());
    //    txtTotalFee.val(val1 + val2 + val3);
    //});

    //var netFee = $('#ServiceTaxPercentage'), totalFee = $("#txtTotalFee"), ServiceTax=$("#ServiceTax"), txtTotalFeeServiceTax = $("#txtTotalFeeServiceTax");

    //    netFee.change(function () {
    //        var val4 = (isNaN(parseInt(totalFee.val()))) ? 0 : parseInt(totalFee.val());
    //        var val5 = (isNaN(parseInt(ServiceTax.val()))) ? 0 : parseInt(ServiceTax.val());
    //        txtTotalFeeServiceTax.val(val4 + val5);
    //    });

    //    var netFeeVal = $("#txtTotalFee,#ServiceTaxPercentage,#IncomeTaxPercentage"), netFeeWithIncomeTax = $('#IncomeTaxPercentage'), txtTotalFeeServiceTax = $("#txtTotalFeeServiceTax"), IncomeTax = $("#IncomeTax"), txtNetFee = $("#txtNetFee");

    //    netFeeVal.change(function () {
    //        var val6 = (isNaN(parseInt(txtTotalFeeServiceTax.val()))) ? 0 : parseInt(txtTotalFeeServiceTax.val());
    //        var val7 = (isNaN(parseInt(IncomeTax.val()))) ? 0 : parseInt(IncomeTax.val());
    //        txtNetFee.val(val6 - val7);
    //    });


});//end of ready function

//function TotalFeeCalc() {
//    var txtBasicPay = document.getElementById('BasicAuditFee').value;
//    var txtTaxLFAR = document.getElementById('FeeForLFAR').value;
//    var txtTaxAudit = document.getElementById('FeeForTaxAudit').value;
//    var result = parseInt(txtBasicPay) + parseInt(txtTaxLFAR) + parseInt(txtTaxAudit);
//    if (!isNaN(result)) {
//        document.getElementById('txtTotalFee').value = result;
//    }
//}

//function TotalWithServiceTax() {
//    var txtTotalFee = document.getElementById('txtTotalFee').value;
//    var txtServiceTax = document.getElementById('ServiceTax').value;
//    var result = parseInt(txtTotalFee) + parseInt(txtServiceTax);
//    if (!isNaN(result)) {
//        document.getElementById('txtTotalFeeServiceTax').value = result;
//    }
//}

//function NetFee() {
//    var txtTotalFee = document.getElementById('txtTotalFeeServiceTax').value;
//    var txtIncomeTax = document.getElementById('IncomeTax').value;
//    var result = parseInt(txtTotalFee) - parseInt(txtIncomeTax);
//    if (!isNaN(result)) {
//        document.getElementById('txtNetFee').value = result;
//    }
//}
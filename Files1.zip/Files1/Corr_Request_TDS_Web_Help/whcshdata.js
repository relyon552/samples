SetCsh(0,"The_WidgetMax_Information_Screen",1,"The_WidgetMax_Information_Screen.htm");

addWindow("WebAppCSH",false,4,"70%","0%","30%","100%","BigCo Help",1,0,"toc|ndx|nls|gls","toc");
addWindow("WebAppFull",false,4,"0%","0%","100%","100%","BigCo Help",2,0,"toc|ndx|nls|gls","");



putCshData(gsProjPath,gaCsh,gaWindow,gaRmtProj);

function ValidatePhoneNumbers(ObjectName, ObjectCaption, MaxLength, Format, Required) {
    var regexp;
    var value = ObjectName.GetText();
    l = value.length;
    if (Required == true) {
        if (Format == "nnn-nnn-nnnn") {
            regexp = /^(\d{3}-\d{3}-\d{4})$/;
            if (regexp.test(value) == false) {
                alert("Enter " + ObjectCaption + " in " + Format)
                if (document.getElementsByName(ObjectName.name)) {
                    ObjectName.SetFocus();
                    ObjectName.SelectAll();
                }return false;
            }
        }
        if (Format == "(nnn)nnn-nnnn") {
            regexp = /^(\(\d{3}\)\d{3}-\d{4})$/;
            if (regexp.test(value) == false) {
                alert("Enter " + ObjectCaption + " in " + Format)
                if (document.getElementsByName(ObjectName.name)) {
                    ObjectName.Focus();
                    ObjectName.SelectAll();
                }return false;
            }
        }
        if (Format == "nnnnnnnnnn") {
            regexp = /^(\d{10})$/;
            if (regexp.test(value) == false) {
                alert("Enter " + ObjectCaption + " in " + Format)
                if (document.getElementsByName(ObjectName.name)) {
                    ObjectName.Focus();
                    ObjectName.Select();
                }return false;
            }
        }
    }
    if (l > MaxLength) {
        alert(ObjectCaption + " Should not exceed " + MaxLength + " Characters ");
        if (document.getElementsByName(ObjectName.name)) {
            ObjectName.Focus();
            ObjectName.Select();
        }return false;
    }
}
function ValidateDeductee(deducteeID, name, formType) {
    if (deducteeID.value == "-1") {
        alert("Specify valid " + (formType == null ? "Deductee Name." : (formType.value == "Form24" ? "Employee No." : "Deductee Name.")));
        name.focus();
        return false;
    }return true;
}
function ValidateRates(eduCessRate, surRate, taxDedRate, formType) {
    if (formType.value == "Form26" || formType.value == "Form27") {
        if (eval(taxDedRate.value) > 99.999) {
            alert("Total Tax Rate can't exceed 99.9999");
            itRate.focus();
            return false;
        }
    }
    else if (formType.value == "Form24") {
        if (eval(eduCessRate.value) > 99.999 || eval(surRate.value) > 99.999) {
            alert("Surcharge Rate or Edu Cess Rate can't exceed 99.9999");
            surRate.focus();
            return false;
        }
    }return true;
}
function ValidateNonDeductionReason(section, nonDedReason, finYear) {
    if ((section.value == "6" || section.value == "7" || section.value == "8" || (Return(finYear.value) < 2017 && section.value == "9") || section.value == "12" || section.value == "13" || section.value == "14" || section.value == "15" || (Return(finYear.value) < 2017 && section.value == "16") || section.value == "22") && nonDedReason.value == 2) {
        alert("For the selected Section , Non Deduction Reason \ncan't be 'NO DEDUCTION U/S 197A'");
        return false;
    }
    if (finYear.value != "2009") {
        if (section.value != "8" && nonDedReason.value == "4") {
            alert("For the selected section,Remarks for Deduction\ncan't be 'TRANSPORTER'");
            return false;
        }
    }return true;
}
function ValidateTaxAmountsForParticularSections(txtTaxDeducted, txtTaxDeductedRate, txtITRate, ddlSection, ddlNonDeductionReason, finYear) {
    if (Return(txtTaxDeducted.value) == 0 && Return(txtTaxDeductedRate.value) != 0) {
        alert("Since Tax Deducted Amount is zero,\nTax Deducted Rate should also be zero.");
        txtITRate.focus();
        return false;
    }
    else {
        var section = ddlSection.value;
        if (section == "3" || section == "4" || section == "5" || (Return(finYear.value) >= 2017 && section == "9") || section == "11" || section == "40") {
            if (ddlNonDeductionReason.value == "2") {
                if (Return(txtTaxDeducted.value) != 0) {
                    alert("'NO DEDUCTION U/S 197A' has been specified.\nSo Tax Amounts should be zero.");
                    if (!txtITRate.disabled) {
                        txtITRate.focus();
                    }return false;
                }
                else {
                    if (Return(txtTaxDeducted.value) == 0 && Return(txtTaxDeductedRate.value) != 0) {
                        alert("Since Tax Deducted Amount is zero,\nTax Deducted Rate should also be zero.");
                        txtITRate.focus();
                        return false;
                    }
                }
            }
        }
        else if (section == "16" && ddlNonDeductionReason.value == "6") {
            if (Return(txtTaxDeducted.value) != 0) {
                alert("'Software Vendor Transaction' has been specified.\nSo Tax Amounts should be zero.");
                txtITRate.focus();
                return false;
            }
        }
        else if (section == "17" && ddlNonDeductionReason.value == "6") {
            if (Return(txtTaxDeducted.value) != 0) {
                alert("'Software Vendor Transaction' has been specified.\nSo Tax Amounts should be zero.");
                txtITRate.focus();
                return false;
            }
        }
    }return true;
}
function ValidateThreshold(section, nonDedReason) {
    if (section.value == "12" && nonDedReason.value == "5") {
        alert("For the selected Section Selected Non-Deduction reason is Invalid");
        return false;
    }
    else
        return true;
}
function ValidateChallanDetails(hdnChallanID, txtTaxDeducted, txtChallanSlNo, ddlQuarter) {
    if (hdnChallanID.value == "-1" && ddlQuarter.selectedIndex != 0) {
        alert("Since Challan Details is not specified,\nChallan Quarter need not be specified.");
        ddlQuarter.focus();
        return false;
    }
    else { return true; }
}
function ValidateChallanDetailsSB(ddlChallanSrNo, txtTaxDeducted, ddlQuarter) {
    if (Return(txtTaxDeducted.value) == 0) {
        if (ddlChallanSrNo.selectedIndex > 0) {
            alert("Tax Deducted Amount is zero.\nSo Challan Details need not be specified.");
            txtChallanSlNo.focus();
            return false;
        }
        else if (ddlChallanSrNo.selectedIndex != 0 && ddlQuarter.selectedIndex != 0) {
            alert("Since Tax Deducted Amount is zero and Challan Details not specified,\nChallan Quarter need not be specified.");
            ddlQuarter.focus();
            return false;
        }
        else
            return true;
    }
    else {
        if (ddlChallanSrNo.value == "-1" && ddlQuarter.selectedIndex != 0) {
            alert("Since Challan Details is not specified,\nChallan Quarter need not be specified.");
            ddlQuarter.focus();
            return false;
        }
        else {
            return true;
        }
    }
}
function ValidateIfTransporter(hdnIsValidPAN, txtTaxDeducted, ddlNonDeductionReason, txtITRate, txtTaxDeductedRate) {
    if (hdnIsValidPAN.value == "" || hdnIsValidPAN.value == "1") {
        if (Return(txtTaxDeducted.value) > 0) {
            if (ddlNonDeductionReason.value == "4") {
                if (Return(txtTaxDeducted.value) != 0) {
                    alert("For 'Transporter with valid PAN (0%)',\nTax Deducted should be Nil.'");
                    txtITRate.focus();
                    return false;
                }
                else {
                    if (Return(txtTaxDeducted.value) == 0 && Return(txtTaxDeductedRate.value) != 0) {
                        alert("Since Tax Deducted Amount is zero,\nTax Deducted Rate should also be zero.");
                        txtITRate.focus();
                        return false;
                    }
                }
            }
        }
        else {
            if (Return(txtTaxDeductedRate.value) != 0) {
                alert('Since Tax Deducted Amount is zero,\nTax Deducted Rate should also be zero.');
                txtITRate.focus();
                return false;
            }
        }
    }
    else {
        if (Return(txtTaxDeducted.value) == 0) {
            alert("Since Deductee is a Transporter and has a invalid PAN,\nTax Deduceted can't be Nil.");
            txtITRate.focus();
            return false;
        }
    }return true;
}
function ValidateIfPANNotAvailable(isSB, hdnIsValidPAN, hdnFormType, txtTaxDeductedRate, ddlNonDeductionReason, txtTaxDeducted, txtITRate, txtIncomeTaxAmount) {
    if (hdnIsValidPAN.value != "1") {
        if (hdnFormType.value != "Form24") {
            if (Return(txtTaxDeductedRate.value) < 20) {
                if (!isSB) {
                    var res = confirm('Since Deductee is having invalid PAN structure,\nTDS has to be deducted at the rate of 20%.\nDo you want to continue?');
                    if (res) {
                        if (ddlNonDeductionReason.value == "3") {
                            if (Return(txtTaxDeducted.value) == 0) {
                                alert("For 'PAN Not available - Higher Rate (20%)',\nTax Deducted can't be Nil.'");
                                txtITRate.focus();
                                return false;
                            }
                        }
                    }
                    else {
                        return false;
                    }
                }
                else {
                    alert("Since Deductee is having invalid PAN structure,\nTDS has to be deducted at the rate of 20%");
                    return false;
                }
            }
            else {
                if (Return(txtTaxDeducted.value) == 0 && Return(txtTaxDeductedRate.value) != 0) {
                    alert('Since Tax Dedcuted Amount is zero,\nTax Deducted Rate should also be zero.');
                    txtITRate.focus();
                    return false;
                }
            }
        }
        else {
            if (ddlNonDeductionReason.value == "3") {
                if (hdnFormType.value == "Form24") {
                    if (Return(txtTaxDeducted.value) == 0) {
                        alert("For 'PAN Not available - Higher Rate (20%)',\nTax Deducted can't be Nil.'");
                        txtIncomeTaxAmount.focus();
                        return false;
                    }                   
                }
                else {
                    if (Return(txtTaxDeducted.value) == 0 &&
                            Return(txtTaxDeductedRate.value) == 0) {
                        alert("For 'PAN Not available - Higher Rate (20%)',\nTax Deducted can't be Nil.'");
                        if (hdnFormType.value != "Form24") {
                            txtITRate.focus();
                            return false;
                        }
                    }
                    else if (Return(txtTaxDeducted.value) == 0 && Return(txtTaxDeductedRate.value) != 0) {
                        alert("For 'PAN Not available - Higher Rate (20%)',\nTax Deducted can't be Nil.'");
                        txtITRate.focus();
                        return false;
                    }
                    else if (Return(txtTaxDeducted.value) != 0 && Return(txtTaxDeductedRate.value) == 0) {
                        alert("For 'PAN Not available - Higher Rate (20%)',\nTax Deducted Rate can't be Nil.'");
                        txtITRate.focus();
                        return false;
                    }
                }
            }return true;
        }
    }return true;
}
function ValidateIfPANAndTransporter(isTransporter, isValidPAN, totalTaxRate, totalTaxDeducted, nonDedReason, hdnFormType, itRate) {
    dedMsg = hdnFormType.value == "Form27E" ? "Collected" : "Deducted";
    deduceeMsg = hdnFormType.value == "Form27E" ? "Collectee" : "Deductee";
    if (Return(totalTaxDeducted.value) == 0 && Return(totalTaxRate.value) == 0) {
        if (isTransporter.value == "True" && isValidPAN.value == "" && nonDedReason.value == "0") {
            alert("Specify 'Transporter with valid PAN (0%)'\nas Remarks for Deduction.");
            nonDedReason.focus();
            return false;
        }
    }
    else if (Return(totalTaxDeducted.value) == 0 && Return(totalTaxRate.value) != 0) {
        alert('Since Tax ' + dedMsg + ' Amount is zero,\nTax ' + dedMsg + 'Rate should also be zero.');
        itRate.focus();
        return false;
    }return true;
}

function CalculateTaxDeductedForForm24(amountOfPayment, creditedDate, incomeTaxAmount, surchargeRate, surchargeAmount, eduCessRate, eduCessAmount, taxDeducted, hdnRoundOff, chkEdit, hdnSetColor, deductedDate) {
    var temp;
    if (!chkEdit.checked) {
        temp = eval(Return(incomeTaxAmount.value)) * (eval(Return(eduCessRate.value)) / 100);
        if (hdnRoundOff.value == "HigherRupee") {
            temp = Math.ceil(temp)
        }
        else {
            temp = temp.toFixed(2);
        }
        eduCessAmount.value = Return(temp);
        temp = eval(Return(incomeTaxAmount.value)) * (eval(Return(surchargeRate.value)) / 100);
        if (hdnRoundOff.value == "HigherRupee") {
            temp = Math.ceil(temp)
        }
        else {
            temp = temp.toFixed(2);
        }
        surchargeAmount.value = Return(temp);   
    }
    temp = eval(Return(incomeTaxAmount.value)) + eval(Return(eduCessAmount.value)) + eval(Return(surchargeAmount.value));
    if (hdnRoundOff.value == "HigherRupee") {
        temp = Math.ceil(temp)
    }
    else { temp = temp.toFixed(2); }
    taxDeducted.value = Return(temp);
    if (Return(taxDeducted.value) != 0) {
        taxDeducted.style.backgroundColor = "#E5E5E5";
        hdnSetColor.value = "#E5E5E5";
    }
    else {
        deductedDate.value = "";
        deductedDate.style.backgroundColor = "White";
        hdnSetColor.value = "White";
    }
}
function CalculateTaxDeducted(amountOfPayment, creditedDate, incomeTaxRate, incomeTaxAmount, surchargeRate, surchargeAmount, eduCessRate, eduCessAmount, taxDeductedRate, taxDeducted,deductedDate, hdnRoundOff, chkEdit, hdnSetColor) {
    var tempValue;
    if (!chkEdit.checked) {
        tempValue = eval(Return(incomeTaxRate.value)) * eval(Return(amountOfPayment.value)) / 100;
        if (hdnRoundOff.value == "HigherRupee1") { tempValue = Math.ceil(tempValue)}
        else { tempValue = tempValue.toFixed(2); }
        incomeTaxAmount.value = Return(tempValue);
        tempValue = eval(Return(surchargeRate.value)) * eval(Return(incomeTaxAmount.value)) / 100;
        if (hdnRoundOff.value == "HigherRupee1") {tempValue = Math.ceil(tempValue)}
        else {tempValue = tempValue.toFixed(2);}
        surchargeAmount.value = Return(tempValue);
        tempValue = eval(Return(eduCessRate.value)) * (eval(Return(incomeTaxAmount.value)) + eval(Return(surchargeAmount.value))) / 100;
        if (hdnRoundOff.value == "HigherRupee1") {tempValue = Math.ceil(tempValue)}
        else {tempValue = tempValue.toFixed(2);}
        eduCessAmount.value = Return(tempValue);
    }
    tempValue = eval(Return(incomeTaxAmount.value)) + eval(Return(surchargeAmount.value)) + eval(Return(eduCessAmount.value));
    if (hdnRoundOff.value == "HigherRupee1") {tempValue = Math.ceil(tempValue)}
    else {tempValue = tempValue.toFixed(2);}
    taxDeducted.value = Return(tempValue);
    var taxRate = ((eval(Return(surchargeRate.value)) / 100) * eval(Return(incomeTaxRate.value))) + eval(Return(incomeTaxRate.value));
    taxRate = ((eval(Return(eduCessRate.value)) / 100) * eval(Return(taxRate))) + eval(Return(taxRate));
    taxRate = taxRate.toFixed(4);
    taxDeductedRate.value = Return(taxRate);
    if (Return(taxDeducted.value) != 0) {
        deductedDate.style.backgroundColor = "#E5E5E5";
        hdnSetColor.value = "#E5E5E5";
    }
    else {
        deductedDate.value = "";
        deductedDate.style.backgroundColor = "White";
        hdnSetColor.value = "White";
    }
}
function CalculateTDSAmount(makeTDSFromFirstPayment, paymentMade, prevPaymentMade, tdsMade, dedAmt, included, thresholdLimit, taxRate, conTaxRate, conLimit, mode, taxDedRate, taxDeducted,
                             netPayable, sectionID, InvalidPAN, IsThresholdCrossed, IsConTaxRateCrossed, nonDedReason, hdnIsDeductionsIncluded, excludingST, serviceTax, incomeTax,
                             itRate, chkEdit, deductedDate, currentDate, hasMultiplePayment) {
    paymentMade = paymentMade.value;
    prevPaymentMade = prevPaymentMade.value;
    tdsMade = tdsMade.value;
    hdnDedAmt = dedAmt.value;
    included = included.value;
    thresholdLimit = thresholdLimit.value;
    taxRate = taxRate.value;
    conTaxRate = conTaxRate.value;
    conLimit = conLimit.value;
    dedAmt = dedAmt.value;
    mode = mode.value;
    var fullPayment = Return(paymentMade) + Return(prevPaymentMade);
    sectionID = sectionID.value;
    InvalidPAN = InvalidPAN.value;
    IsThresholdCrossed = IsThresholdCrossed.value;
    IsConTaxRateCrossed = IsConTaxRateCrossed.value;
    var totalST = Return(excludingST.value) + Return(serviceTax.value);
    nonDedReason.value = "0";
    hdnIsDeductionsIncluded.value = Return(prevPaymentMade) > 0 ? "1" : "0"
    hasMultiplePayment = hasMultiplePayment.value;
    if (hasMultiplePayment == "1")
        IsConTaxRateCrossed = "0";
    if (InvalidPAN == "1") {
        nonDedReason.value = "3";
        if (Return(taxRate) < 20) {taxRate = 20;}
        if (Return(conTaxRate) < 20 && Return(conTaxRate) > 0) {conTaxRate = 20;}
    }
    if (InvalidPAN == "1" && Return(conTaxRate) == 0) {
        taxDeducted.value = "0";
        taxDedRate.value = Return(conTaxRate);
        incomeTax.value = "0";
        itRate.value = Return(conTaxRate);
    }
    else {
        var tdsPayment = Return(sectionID) != 8 ? (Return(fullPayment) + Return(tdsMade) + Return(included)) : (Return(totalST) > 30000 ? totalST : (Return(fullPayment) + Return(tdsMade) + Return(included)));
        var conTDSPayment = Return(sectionID) != 8 ? ((Return(fullPayment) + Return(tdsMade) + Return(included)) <= Return(conLimit) ? Return(fullPayment + Return(tdsMade) + Return(included)) : Return(conLimit))
										   : (Return(IsConTaxRateCrossed) == 0 ? (Return(totalST) > 30000 ? totalST : (Return(fullPayment) + Return(tdsMade) + Return(included))) : 0);
        var extraTDSPayment = Return(tdsPayment) - Return(conLimit);
        if (extraTDSPayment < 0) {
            extraTDSPayment = 0;
        }
        var extraTDS = mode == "-1" ? Return(Return(extraTDSPayment) * Return(taxRate) / 100).toFixed(2) : Math.ceil(eval(Return(extraTDSPayment) * Return(taxRate) / 100));
        var conTDS = Return(conTaxRate) != -1 ? (mode == "-1" ? Return(Return(conTDSPayment) * Return(conTaxRate) / 100).toFixed(2) : Math.ceil(eval(Return(conTDSPayment) * Return(conTaxRate) / 100))) : 0;
        var totaltds = Return(conTDS) + Return(extraTDS);
        var dedToMake = Return(sectionID) != 8 ? (mode == "-1" ? Return(Return(totaltds - Return(dedAmt))).toFixed(2) : Math.ceil(eval(Return(totaltds - Return(dedAmt))))) : (Return(totalST) > 30000 ? totaltds : (mode == "-1" ? Return(Return(totaltds - Return(dedAmt))).toFixed(2) : Math.ceil(eval(Return(totaltds - Return(dedAmt))))));
        if (dedToMake < 0) dedToMake = 0;
        if (makeTDSFromFirstPayment.value == "0") {
            if (Return(sectionID.value) != 8) {
                if (Return(thresholdLimit) > 0) {
                    if (IsThresholdCrossed == "1") {
                        if (IsConTaxRateCrossed == "0") {
                            taxDeducted.value = dedToMake;
                            taxDedRate.value = Return(conTaxRate);
                            incomeTax.value = dedToMake;
                            itRate.value = Return(conTaxRate);
                            if (nonDedReason.value == "0")
                                nonDedReason.value = "1";
                        }
                        else {
                            taxDeducted.value = dedToMake;
                            taxDedRate.value = Return(taxRate);
                            incomeTax.value = dedToMake;
                            itRate.value = Return(taxRate);
                            chkEdit.checked = true;
                        }
                    }
                    else {
                        if (nonDedReason.value == "0")
                            nonDedReason.value = "5";
                    }
                }
                else {
                    if (IsConTaxRateCrossed == "0") {
                        taxDeducted.value = dedToMake;
                        taxDedRate.value = Return(conTaxRate);
                        incomeTax.value = dedToMake;
                        itRate.value = Return(conTaxRate);
                        if (nonDedReason.value == "0")
                            nonDedReason.value = "1";
                    }
                    else {
                        taxDeducted.value = dedToMake;
                        taxDedRate.value = Return(taxRate);
                        incomeTax.value = dedToMake;
                        itRate.value = Return(taxRate);
                        chkEdit.checked = true;
                    }
                }
            }
            else {
                if (Return(prevPaymentMade) == 0 && IsThresholdCrossed == "1") {
                    if (IsConTaxRateCrossed == "0") {
                        taxDeducted.value = mode == "-1" ? Return(Return(paymentMade) * Return(conTaxRate) / 100).toFixed(2) : Math.ceil(eval(Return(fullPayment) * Return(conTaxRate) / 100));
                        taxDedRate.value = Return(conTaxRate);
                        incomeTax.value = mode == "-1" ? Return(Return(paymentMade) * Return(conTaxRate) / 100).toFixed(2) : Math.ceil(eval(Return(fullPayment) * Return(conTaxRate) / 100));
                        itRate.value = Return(conTaxRate);
                        if (nonDedReason.value == "0")
                            nonDedReason.value = "1";
                    }
                    else {
                        taxDeducted.value = mode == "-1" ? Return(Return(fullPayment) * Return(taxRate) / 100).toFixed(2) : Math.ceil(eval(Return(fullPayment) * Return(taxRate) / 100));
                        taxDedRate.value = Return(taxRate);
                        incomeTax.value = mode == "-1" ? Return(Return(fullPayment) * Return(taxRate) / 100).toFixed(2) : Math.ceil(eval(Return(fullPayment) * Return(taxRate) / 100));
                        itRate.value = Return(taxRate);
                    }
                }
                else {
                    if (Return(prevPaymentMade) == 0 && Return(paymentMade) > 30000) {
                        if (IsConTaxRateCrossed == "0") {
                            taxDeducted.value = mode == "-1" ? Return(Return(fullPayment) * Return(conTaxRate) / 100).toFixed(2) : Math.ceil(eval(Return(fullPayment) * Return(conTaxRate) / 100));
                            taxDedRate.value = Return(conTaxRate);
                            incomeTax.value = mode == "-1" ? Return(Return(fullPayment) * Return(conTaxRate) / 100).toFixed(2) : Math.ceil(eval(Return(fullPayment) * Return(conTaxRate) / 100));
                            itRate.value = Return(conTaxRate);
                        }
                        else {
                            taxDeducted.value = mode == "-1" ? Return(Return(fullPayment) * Return(taxRate) / 100).toFixed(2) : Math.ceil(eval(Return(fullPayment) * Return(taxRate) / 100));
                            taxDedRate.value = Return(taxRate);
                            incomeTax.value = mode == "-1" ? Return(Return(fullPayment) * Return(taxRate) / 100).toFixed(2) : Math.ceil(eval(Return(fullPayment) * Return(taxRate) / 100));
                            itRate.value = Return(taxRate);
                        }
                    }
                    else if (IsThresholdCrossed == "1") {
                        if (IsConTaxRateCrossed == "0") {
                            taxDeducted.value = dedToMake;
                            taxDedRate.value = Return(conTaxRate);
                            incomeTax.value = dedToMake;
                            itRate.value = Return(conTaxRate);
                        }
                        else {
                            taxDeducted.value = dedToMake;
                            taxDedRate.value = Return(taxRate);
                            incomeTax.value = dedToMake;
                            itRate.value = Return(taxRate);
                            hdnIsDeductionsIncluded.value = "1";
                        }
                    }
                    else {
                        if (nonDedReason.value == "0")
                            nonDedReason.value = "5";
                    }
                }
            }
        }
        else {
            if (IsConTaxRateCrossed == "0") {
                taxDeducted.value = mode == "-1" ? Return(Return(paymentMade) * Return(conTaxRate) / 100).toFixed(2) : Math.ceil(eval(Return(paymentMade) * Return(conTaxRate) / 100));
                taxDedRate.value = Return(conTaxRate);
                incomeTax.value = mode == "-1" ? Return(Return(paymentMade) * Return(conTaxRate) / 100).toFixed(2) : Math.ceil(eval(Return(paymentMade) * Return(conTaxRate) / 100));
                itRate.value = Return(conTaxRate);
                if (nonDedReason.value == "0")
                    nonDedReason.value = "1";
            }
            else {
                taxDeducted.value = mode == "-1" ? Return(Return(paymentMade) * Return(taxRate) / 100).toFixed(2) : Math.ceil(eval(Return(paymentMade) * Return(taxRate) / 100));
                taxDedRate.value = Return(taxRate);
                incomeTax.value = mode == "-1" ? Return(Return(paymentMade) * Return(taxRate) / 100).toFixed(2) : Math.ceil(eval(Return(paymentMade) * Return(taxRate) / 100));
                itRate.value = Return(taxRate);

            }
        }
    }
    if (Return(paymentMade) < Return(taxDeducted.value)) {
        var finalRate = taxDedRate.value;
        taxDeducted.value = mode == "-1" ? Return(paymentMade) : Math.ceil(eval(paymentMade));
        incomeTax.value = mode == "-1" ? Return(paymentMade) : Math.ceil(eval(paymentMade));
        hdnIsDeductionsIncluded.value = "0";
    }
    if (Return(taxDeducted.value) > 0) {
        deductedDate.value = currentDate.value;
        deductedDate.style.backgroundColor = "#E5E5E5";
    }
    else {
        deductedDate.value = "";
        deductedDate.style.backgroundColor = "white";
    }
    var number = Return(totalST) - Return(taxDeducted.value);
    netPayable.value = mode == "-1" ? number.toFixed(2) : Math.ceil(eval(number));
}
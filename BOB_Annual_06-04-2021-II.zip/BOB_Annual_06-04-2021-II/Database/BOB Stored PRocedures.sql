USE [BOB2021]
GO
/****** Object:  StoredProcedure [dbo].[USP_Annual_DeleteAnnexureData]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[USP_Annual_DeleteAnnexureData]
@AnnexureID TINYINT
AS
BEGIN
DECLARE @Query VARCHAR(1024),
		@NoOfRows int

SET @NoOfRows=0

SET FMTONLY OFF;
SET NOCOUNT OFF;

SET @Query = CASE @AnnexureId
                  WHEN 123 THEN 'DELETE FROM AR_Annexure_i'
				  WHEN 124 THEN 'DELETE FROM AR_Annexure_ii'
				  WHEN 125 THEN 'DELETE FROM AR_Annexure_iii'
				  WHEN 126 THEN 'DELETE FROM AR_Annexure_iv'
				  WHEN 109 THEN 'DELETE FROM AR_AnnexureXXXIXA'
				  WHEN 110 THEN 'DELETE FROM AR_AnnexureXXXIXB'
				  WHEN 111 THEN 'DELETE FROM AR_AnnexureXXXIXC'
				  WHEN 101 THEN 'DELETE FROM AR_AnnexureXXXV'
				  WHEN 108 THEN 'DELETE FROM AR_AnnexureXXXVIIIC'
				  WHEN 98 THEN 'DELETE FROM AR_AnnexureXXXIVB'
				  WHEN 95 THEN 'DELETE FROM AR_AnnexureXXXII'
				  WHEN 58 THEN 'DELETE FROM AR_AnnexureX'
				  WHEN 59 THEN 'DELETE FROM AR_AnnexureXIII'
				  WHEN 75 THEN 'DELETE FROM AR_AnnexureXXV
                                DELETE FROM AR_AnnexureXXV_1
                                DELETE FROM AR_AnnexureXXV_2'
				  WHEN 76 THEN 'DELETE FROM AR_AnnexureXXVA
                                DELETE FROM AR_AnnexureXXVA_1
                                DELETE FROM AR_AnnexureXXVA_2'
				  WHEN 77 THEN 'DELETE FROM AR_AnnexureXXVB
                                DELETE FROM AR_AnnexureXXVB_1
                                DELETE FROM AR_AnnexureXXVB_2'
				  WHEN 78 THEN 'DELETE FROM AR_AnnexureXXVC
                                DELETE FROM AR_AnnexureXXVC_1
                                DELETE FROM AR_AnnexureXXVC_2'
				  WHEN 79 THEN 'DELETE FROM AR_AnnexureXXVD
                                DELETE FROM AR_AnnexureXXVD_1
                                DELETE FROM AR_AnnexureXXVD_2'
				  WHEN 80 THEN 'DELETE FROM AR_AnnexureXXVE
                                DELETE FROM AR_AnnexureXXVE_1
                                DELETE FROM AR_AnnexureXXVE_2'
				WHEN 116 THEN 'DELETE FROM AR_AnnexureXXVF
                                DELETE FROM AR_AnnexureXXVF_1
                                DELETE FROM AR_AnnexureXXVF_2'
				  WHEN 81 THEN 'DELETE FROM AR_AnnexureXXVI
                                DELETE FROM AR_AnnexureXXVI_1
                                DELETE FROM AR_AnnexureXXVI_2'
				  WHEN 82 THEN 'DELETE FROM AR_AnnexureXXVIA
                                DELETE FROM AR_AnnexureXXVIA_1
                                DELETE FROM AR_AnnexureXXVIA_2'	
				WHEN 83 THEN 'DELETE FROM AR_AnnexureXXVIB
                                DELETE FROM AR_AnnexureXXVIB_1
                                DELETE FROM AR_AnnexureXXVIB_2'	
				WHEN 84 THEN 'DELETE FROM AR_AnnexureXXVIC
                                DELETE FROM AR_AnnexureXXVIC_1
                                DELETE FROM AR_AnnexureXXVIC_2'	
				WHEN 85 THEN 'DELETE FROM AR_AnnexureXXVID
                                DELETE FROM AR_AnnexureXXVID_1
                                DELETE FROM AR_AnnexureXXVID_2'	
				WHEN 86 THEN 'DELETE FROM AR_AnnexureXXVIE
                                DELETE FROM AR_AnnexureXXVIE_1
                                DELETE FROM AR_AnnexureXXVIE_2'
				WHEN 117 THEN 'DELETE FROM AR_AnnexureXXVIF
                                DELETE FROM AR_AnnexureXXVIF_1
                                DELETE FROM AR_AnnexureXXVIF_2'
				WHEN 127 THEN 'DELETE FROM AR_AnnexureXXVIG
                                DELETE FROM AR_AnnexureXXVIG_1
                                DELETE FROM AR_AnnexureXXVIG_2'
				WHEN 128 THEN 'DELETE FROM AR_AnnexureXXVIH
                                DELETE FROM AR_AnnexureXXVIH_1
                                DELETE FROM AR_AnnexureXXVIH_2'
				WHEN 129 THEN 'DELETE FROM AR_AnnexureXXVI_I
                                DELETE FROM AR_AnnexureXXVI_I_1
                                DELETE FROM AR_AnnexureXXVI_I_2'	
				WHEN 96 THEN 'DELETE FROM AR_AnnexureXXXIV WHERE HeadID >= 555 AND HeadID <= 558'
				WHEN 97 THEN 'DELETE FROM AR_AnnexureXXXIV WHERE HeadID >= 550 AND HeadID <= 552'	
				WHEN 93 THEN 'DELETE FROM AR_Annexure30'
				WHEN 70 THEN 'DELETE FROM AR_Annexure30'							
				  ELSE ''
             END
EXEC(@Query)
SELECT @NoOfRows=@@ROWCOUNT
END















GO
/****** Object:  StoredProcedure [dbo].[USP_AR_AnnexureXVI_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_AnnexureXVI_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t2.RowCode,t2.RecordHead,
				   status = (CASE WHEN t1.Status = 1 THEN 'Yes' WHEN t1.Status = 2 THEN 'No' ELSE 'Not Applicable' END)
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_AnnexureXVI AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) AND (t2.RowCode != '')
			ORDER BY t.BranchCode,t2.HeadID

	--IF(@RoleTypeId = 1)
	--	BEGIN
	--	--Super Admin
	--		SELECT t.BranchCode,t.BranchName,t.Region,t2.RowCode,t2.RecordHead,
	--			   status = (CASE WHEN t1.Status = 1 THEN 'Yes' WHEN t1.Status = 2 THEN 'No' ELSE 'Not Applicable' END)
	--		FROM   vw_BranchDetailsWithRegion AS t
	--		JOIN   AR_AnnexureXVI AS t1 ON t.BranchYearID = t1.BranchYearID
	--		JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
	--		WHERE  ((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0)) AND
	--			   ((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 AND 
	--			   (t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) AND (t2.RowCode != '')
	--		ORDER BY t2.HeadID
	--	END
	
	--ELSE
	
	--	BEGIN
	--	--Regional Or Zonal office
	--		SELECT t.BranchCode,t.BranchName,t.Region,t2.RowCode,t2.RecordHead,
	--			   status = (CASE WHEN t1.Status = 1 THEN 'Yes' WHEN t1.Status = 2 THEN 'No' ELSE 'Not Applicable' END)
	--		FROM   vw_BranchDetailsWithRegion AS t
	--		JOIN   AR_AnnexureXVI AS t1 ON t.BranchYearID=t1.BranchYearID
	--		JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
	--		JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
	--		JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
	--		WHERE  ((@BranchRegionalId > 0 AND t4.BranchRegionalID = @BranchRegionalId) OR (t4.BranchZonalID = @BranchZonalId))
	--				AND
	--			   ((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
	--				AND
	--			   ((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 AND 
	--			   (t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2))  AND (t2.RowCode != '')
	--		ORDER BY t2.HeadID
	--	END
END





GO
/****** Object:  StoredProcedure [dbo].[USP_AR_AnnexureXVIA_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_AnnexureXVIA_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t2.RowCode,t2.RecordHead,
				   status = (CASE WHEN t1.Status = 1 THEN 'Yes' WHEN t1.Status = 2 THEN 'No' ELSE 'Not Applicable' END)
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_AnnexureXVIA AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) AND (t2.RowCode != '')
			ORDER BY t.BranchCode,t2.HeadID

	--IF(@RoleTypeId = 1)
	--	BEGIN
	--	--Super Admin
	--		SELECT t.BranchCode,t.BranchName,t.Region,t2.RowCode,t2.RecordHead,
	--			   status = (CASE WHEN t1.Status = 1 THEN 'Yes' WHEN t1.Status = 2 THEN 'No' ELSE 'Not Applicable' END)
	--		FROM   vw_BranchDetailsWithRegion AS t
	--		JOIN   AR_AnnexureXVIA AS t1 ON t.BranchYearID = t1.BranchYearID
	--		JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
	--		WHERE  ((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0)) AND
	--			   ((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 AND 
	--			   (t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) AND (t2.RowCode != '')
	--		ORDER BY t2.HeadID
	--	END
	
	--ELSE
	
	--	BEGIN
	--	--Regional Or Zonal office
	--		SELECT t.BranchCode,t.BranchName,t.Region,t2.RowCode,t2.RecordHead,
	--			   status = (CASE WHEN t1.Status = 1 THEN 'Yes' WHEN t1.Status = 2 THEN 'No' ELSE 'Not Applicable' END)
	--		FROM   vw_BranchDetailsWithRegion AS t
	--		JOIN   AR_AnnexureXVIA AS t1 ON t.BranchYearID=t1.BranchYearID
	--		JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
	--		JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
	--		JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
	--		WHERE  ((@BranchRegionalId > 0 AND t4.BranchRegionalID = @BranchRegionalId) OR (t4.BranchZonalID = @BranchZonalId))
	--				AND
	--			   ((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
	--				AND
	--			   ((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 AND 
	--			   (t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2))  AND (t2.RowCode != '')
	--		ORDER BY t2.HeadID
	--	END
END





GO
/****** Object:  StoredProcedure [dbo].[USP_AR_AuditAndUploadedBranchesList]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



create PROCEDURE [dbo].[USP_AR_AuditAndUploadedBranchesList]
@finYear SMALLINT,@isAudited BIT,@BranchRegionalId INT,@BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS INT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS INT;
SET @localBranchZonalId=@BranchZonalId;

SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName
FROM vw_BranchDetailsWithRegion AS t
JOIN ReportDetails AS rd ON t.BranchYearID = rd.BranchYearID
JOIN BranchMaster AS bm ON t.BranchID=bm.BranchID
JOIN UserProfile AS u ON t.ManagerUserID=u.UserID
WHERE u.IsApplicableForAnnual=1 AND t.FinYear=@finYear AND t.IsClosed_Annual =1 AND rd.ReportLocation IS NOT NULL AND
((@isAudited=1 AND (t.IsManagerAuditing=0 OR t.IsManagerAuditing IS NULL)) OR (@isAudited=0 AND t.IsManagerAuditing=1)) AND
(bm.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
AND 
(bm.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
AND t.BranchYearID !=1

END

-- exec [USP_AR_AuditAndUploadedBranchesList] 2020,0,0,0

GO
/****** Object:  StoredProcedure [dbo].[USP_AR_AuditCompletedBranches]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[USP_AR_AuditCompletedBranches]
@filterbranchcode VARCHAR(10)
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localFilterbranchcode AS VARCHAR(10);
SET @localFilterbranchcode=@filterbranchcode;

SELECT rd.ReportID, br.BranchYearID, rd.ReportType, rd.Description, rd.ReportLocation, rd.UserID, rd.CreationDate, bm.BranchCode,
       bm.BranchName, bm.BranchTypeID 
FROM BranchMaster AS bm
								JOIN BranchYearDetails AS br ON bm.BranchID=br.BranchID
								LEFT JOIN ReportDetails AS rd ON br.BranchYearID=rd.BranchYearID
								WHERE br.IsClosed_Annual = 1 AND (bm.BranchCode=@localFilterbranchcode OR 
								isnull(@localFilterbranchcode,'')='')
			ORDER BY br.BranchYearID
END


-- exec [USP_AR_AuditCompletedBranches] ''

GO
/****** Object:  StoredProcedure [dbo].[USP_AR_AuditCompletedBranchesList]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [dbo].[USP_AR_AuditCompletedBranchesList]
@finYear SMALLINT,@isAudited BIT,@BranchRegionalId INT,@BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS INT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS INT;
SET @localBranchZonalId=@BranchZonalId;

SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName
FROM vw_BranchDetailsWithRegion AS t
JOIN BranchMaster AS bm ON t.BranchID=bm.BranchID
JOIN UserProfile AS u ON t.ManagerUserID=u.UserID
WHERE u.IsApplicableForAnnual=1 AND t.FinYear=@finYear AND t.IsClosed_Annual =1 AND
((@isAudited=1 AND (t.IsManagerAuditing=0 OR t.IsManagerAuditing IS NULL)) OR (@isAudited=0 AND t.IsManagerAuditing=1)) AND
(bm.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
AND 
(bm.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
AND t.BranchYearID !=1

END

-- exec [USP_AR_AuditCompletedBranchesList] 2020,0,0,0

GO
/****** Object:  StoredProcedure [dbo].[USP_AR_AuditCompletedButNotUploadedBranchesList]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



create PROCEDURE [dbo].[USP_AR_AuditCompletedButNotUploadedBranchesList]
@finYear SMALLINT,@isAudited BIT,@BranchRegionalId INT,@BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS INT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS INT;
SET @localBranchZonalId=@BranchZonalId;

SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName
FROM vw_BranchDetailsWithRegion AS t
JOIN BranchMaster AS bm ON t.BranchID=bm.BranchID
JOIN UserProfile AS u ON t.ManagerUserID=u.UserID
WHERE u.IsApplicableForAnnual=1 AND t.FinYear=@finYear AND t.IsClosed_Annual =1 AND
((@isAudited=1 AND (t.IsManagerAuditing=0 OR t.IsManagerAuditing IS NULL)) OR (@isAudited=0 AND t.IsManagerAuditing=1)) AND
(bm.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
AND 
(bm.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
AND t.BranchYearID !=1 AND NOT EXISTS (SELECT rd.BranchYearid FROM ReportDetails rd WHERE rd.BranchYearID=t.BranchYearID)

END

-- exec [USP_AR_AuditCompletedButNotUploadedBranchesList] 2020,1,0,0


GO
/****** Object:  StoredProcedure [dbo].[USP_AR_AuditYetToStartBranchesList]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



create PROCEDURE [dbo].[USP_AR_AuditYetToStartBranchesList]
@finYear SMALLINT,@isAudited BIT,@BranchRegionalId INT,@BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS INT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS INT;
SET @localBranchZonalId=@BranchZonalId;

SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName
FROM vw_BranchDetailsWithRegion AS t
JOIN BranchMaster AS bm ON t.BranchID=bm.BranchID
JOIN UserProfile AS u ON t.ManagerUserID=u.UserID
WHERE u.IsApplicableForAnnual=1 AND t.FinYear=@finYear AND (t.AuditStartDate_Annual IS NULL) AND ISNULL(t.IsClosed_Annual,0) = 0 AND
((@isAudited=1 AND (t.IsManagerAuditing=0 OR t.IsManagerAuditing IS NULL)) OR (@isAudited=0 AND t.IsManagerAuditing=1)) AND
(bm.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
AND 
(bm.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
AND t.BranchYearID !=1

END

-- exec [USP_AR_AuditYetToStartBranchesList] 2020,1,0,0

GO
/****** Object:  StoredProcedure [dbo].[USP_AR_Certificate8_PartB_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_Certificate8_PartB_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t1.SlNo,t1.NameOfBorrower,
			CASE 
				When t1.AssetClassification = 1  then 'STANDARD'
				When t1.AssetClassification = 2  then 'SUB-STANDARD'
				When t1.AssetClassification = 3  then 'DOUBTFULL'
				Else ''
			END as AssetClassification,
			CASE 
				When t1.Segment = 1  then 'CDR'
				When t1.Segment = 2  then 'SME'
				When t1.Segment = 3  then 'Others'
				Else ''
			END as Segment
			,t1.AmountOutstanding,t1.AmountOfInterest,t1.IrregularitySBA,t1.ReplyOfBranch
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_Certificate8_PartB AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID
END


GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateI_A_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateI_A_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,
			t1.DateOfRecovery,t1.[AmtOfRecovery ],t1.[DateOfSharing ],t1.AmountRemitted		
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateI_A AS t1 ON t.BranchYearID=t1.BranchYearID

			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID
END







GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateI_B_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateI_B_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,
			t1.DateOfRecovery,t1.[AmtOfRecovery ],t1.[DateOfSharing ],t1.AmountRemitted		
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateI_B AS t1 ON t.BranchYearID=t1.BranchYearID

			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID
END







GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateI_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateI_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,
			t1.SLGS,t1.SISSI,t1.GovtSmall,t1.Total,t1.IrregularitySBA			
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateI AS t1 ON t.BranchYearID=t1.BranchYearID

			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID
END







GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateIV_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateIV_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t2.RowCode, t2.RecordHead,t1.CurrentYear,t1.PreviousYear
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateIV AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)
					AND
					(t2.HeadID between 812 and 818)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END


GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateIV_I_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateIV_I_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t2.RowCode, t2.RecordHead,t1.CurrentYear,t1.PreviousYear
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateIV AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)
					AND
					(t2.HeadID between 819 and 828)
					OR
					t2.HeadID = 989) 
			ORDER BY t1.BranchYearID,t1.HeadID
END



GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateIV_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateIV_RegionalConsolidation]
@AnnexureId INT,@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT (SELECT RecordHead FROM AnnexureRecordHeadMaster WHERE HeadID=t1.HeadID) AS Head,SUM(t1.CurrentYear) AS CurrentYear,SUM(t1.PreviousYear) AS PreviousYear
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateIV AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)
					AND t2.AnnexureID=@AnnexureId)
					--(t2.HeadID between 812 and 818))  AND
					 
			GROUP BY t1.HeadID
			ORDER BY t1.HeadID

END

-- exec [USP_AR_CertificateIV_RegionalConsolidation] 176,0,2,8,5,0



GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateIX_A_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateIX_A_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t2.RecordHead,
			t1.NoOfAccounts,t1.AmountDisbursed,t1.AmountSubvention
			
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateIX_A AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END




GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateIX_A_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[USP_AR_CertificateIX_A_RegionalConsolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS
BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT 'Loans up to Rs.3 lakh' AS LoanSize,SUM(t1.NoOfAccounts) AS NoOfAccounts,SUM(t1.AmountDisbursed) AS AmountDisbursed,SUM(t1.AmountSubvention) AS AmountSubvention
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateIX_A AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId =0) 
					AND 
					(t4.BranchZonalID =@localBranchZonalId OR @localBranchZonalId =0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2))
			
END



-- exec [USP_AR_CertificateIX_A_RegionalConsolidation] 0,2,8,5,0


GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateIX_B_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateIX_B_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t2.RecordHead,
			t1.GenNoOfAccounts,t1.GenAmountDisbursed,t1.GenAmountSubvention,t1.SCNoOfAccounts,t1.SCAmountDisbursed,t1.SCAmountSubvention,
			t1.STNoOfAccounts,t1.STAmountDisbursed,t1.STAmountSubvention
			
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateIX_B AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END




GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateIX_B_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[USP_AR_CertificateIX_B_RegionalConsolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS
BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT 'Loans up to Rs.3 lakh' AS LoanSize,SUM(t1.GenNoOfAccounts) AS GenNoOfAccounts,SUM(t1.GenAmountDisbursed) AS GenAmountDisbursed,SUM(t1.GenAmountSubvention) AS GenAmountSubvention,
                   SUM(t1.SCNoOfAccounts) AS SCNoOfAccounts,SUM(t1.SCAmountDisbursed) AS SCAmountDisbursed,SUM(t1.SCAmountSubvention) AS SCAmountSubvention,
                   SUM(t1.STNoOfAccounts) AS STNoOfAccounts,SUM(t1.STAmountDisbursed) AS STAmountDisbursed,SUM(t1.STAmountSubvention) AS STAmountSubvention
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateIX_B AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId =0) 
					AND 
					(t4.BranchZonalID =@localBranchZonalId OR @localBranchZonalId =0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2))
			
END



-- exec [USP_AR_CertificateIX_B_RegionalConsolidation] 0,2,8,5,0


GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateVII_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[USP_AR_CertificateVII_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t2.RowCode,t2.RecordHead,t1.Amount
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateVII AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END









GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateVII_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


create PROCEDURE [dbo].[USP_AR_CertificateVII_RegionalConsolidation]
@AnnexureId INT,@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT (SELECT RecordHead FROM AnnexureRecordHeadMaster WHERE HeadID=t1.HeadID) AS Head,SUM(t1.Amount) AS Amount
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateVII AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)
					AND t2.AnnexureID=@AnnexureId)
			GROUP BY t1.HeadID
			ORDER BY t1.HeadID
END


-- exec USP_AR_CertificateVII_RegionalConsolidation 132,0,2,8,5,0






GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateVIII_A_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateVIII_A_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t2.RecordHead,t1.Standard_NoOfBorrowers,t1.Standard_AmountOutstanding,t1.Standard_Sacrifice,t1.SubStandard_NoOfBorrowers,t1.SubStandard_AmountOutstanding,t1.SubStandard_Sacrifice,t1.Doubtful_NoOfBorrowers,t1.Doubtful_AmountOutstanding,t1.Doubtful_Sacrifice,t1.Total_NoOfBorrowers,t1.Total_AmountOutstanding,t1.Total_Sacrifice
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateVIII_A AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END






GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateVIII_B_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateVIII_B_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t2.RecordHead,t1.Standard_NoOfBorrowers,t1.Standard_AmountOutstanding,t1.Standard_Sacrifice,t1.SubStandard_NoOfBorrowers,t1.SubStandard_AmountOutstanding,t1.SubStandard_Sacrifice,t1.Doubtful_NoOfBorrowers,t1.Doubtful_AmountOutstanding,t1.Doubtful_Sacrifice,t1.Total_NoOfBorrowers,t1.Total_AmountOutstanding,t1.Total_Sacrifice
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateVIII_B AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END







GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateVIII_C_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateVIII_C_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t2.RecordHead,t1.Standard_NoOfBorrowers,t1.Standard_AmountOutstanding,t1.Standard_Sacrifice,t1.SubStandard_NoOfBorrowers,t1.SubStandard_AmountOutstanding,t1.SubStandard_Sacrifice,t1.Doubtful_NoOfBorrowers,t1.Doubtful_AmountOutstanding,t1.Doubtful_Sacrifice,t1.Total_NoOfBorrowers,t1.Total_AmountOutstanding,t1.Total_Sacrifice
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateVIII_C AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END







GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateVIIIA_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateVIIIA_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t2.RecordHeadID,
			CASE
				When t2.RecordHeadID between 1 and 5 then 'Under CDR Mechanism'
				When t2.RecordHeadID between 6 and 10 then 'Under SME Debt Restructuring Mechanism'
				When t2.RecordHeadID between 11 and 15 then 'Others'
				Else 'Total'
			End As Type, 
			t2.RecordHead,
			t1.RA_Number,t1.RA_Amount,t1.RA_Provision,
			t1.FR_Number,t1.FR_Amount,t1.FR_Provision,
			t1.UR_Number,t1.UR_Amount,t1.UR_Provision,
			t1.RS_Number,t1.RS_Amount,t1.RS_Provision,
			t1.DR_Number,t1.DR_Amount,t1.DR_Provision,
			t1.WR_Number,t1.WR_Amount,t1.WR_Provision,
			t1.RA1_Number,t1.RA1_Amount,t1.RA1_Provision
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateVIIIA AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END



GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateVIIIA_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

create PROCEDURE [dbo].[USP_AR_CertificateVIIIA_RegionalConsolidation]
@AnnexureId INT,@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;
SET @localBranchZonalId=@BranchZonalId;

			SELECT 
			--CASE
			--	When t2.RecordHeadID between 1 and 5 then 'Under CDR Mechanism'
			--	When t2.RecordHeadID between 6 and 10 then 'Under SME Debt Restructuring Mechanism'
			--	When t2.RecordHeadID between 11 and 15 then 'Others'
			--	Else 'Total'
			--End As Type, 
			(SELECT RecordHead FROM AnnexureRecordHeadMaster WHERE HeadID=t1.HeadID) AS Head,
			SUM(t1.RA_Number) AS RA_Number,SUM(t1.RA_Amount) AS RA_Amount,SUM(t1.RA_Provision) AS RA_Provision,
			SUM(t1.FR_Number) AS FR_Number,SUM(t1.FR_Amount) AS FR_Amount,SUM(t1.FR_Provision) AS FR_Provision,
			SUM(t1.UR_Number) AS UR_Number,SUM(t1.UR_Amount) AS UR_Amount,SUM(t1.UR_Provision) AS UR_Provision,
			SUM(t1.RS_Number) AS RS_Number,SUM(t1.RS_Amount) AS RS_Amount,SUM(t1.RS_Provision) AS RS_Provision,
			SUM(t1.DR_Number) AS DR_Number,SUM(t1.DR_Amount) AS DR_Amount,SUM(t1.DR_Provision) AS DR_Provision,
			SUM(t1.WR_Number) AS WR_Number,SUM(t1.WR_Amount) AS WR_Amount,SUM(t1.WR_Provision) AS WR_Provision,
			SUM(t1.RA1_Number) AS RA1_Number,SUM(t1.RA1_Amount) AS RA1_Amount,SUM(t1.RA1_Provision) AS RA1_Provision
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateVIIIA AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)
					AND t2.AnnexureID=@AnnexureId) 
			GROUP BY t1.HeadID
			ORDER BY t1.HeadID
END



GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateX_A_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateX_A_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t2.RecordHead,
			t1.NoOfAccounts,t1.AmountDisbursed,t1.AmountSubvention
			
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateX_A AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END



GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateX_A_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[USP_AR_CertificateX_A_RegionalConsolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS
BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT 'Loans up to Rs.3 lakh' AS LoanSize,SUM(t1.NoOfAccounts) AS NoOfAccounts,SUM(t1.AmountDisbursed) AS AmountDisbursed,SUM(t1.AmountSubvention) AS AmountSubvention
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateX_A AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId =0) 
					AND 
					(t4.BranchZonalID =@localBranchZonalId OR @localBranchZonalId =0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2))
			
END



-- exec [USP_AR_CertificateX_A_RegionalConsolidation] 0,2,8,5,0


GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateX_B_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[USP_AR_CertificateX_B_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t2.RecordHead,
			t1.GenNoOfAccounts,t1.GenAmountDisbursed,t1.GenAmountSubvention,t1.SCNoOfAccounts,t1.SCAmountDisbursed,t1.SCAmountSubvention,
			t1.STNoOfAccounts,t1.STAmountDisbursed,t1.STAmountSubvention
			
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateX_B AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END




GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateX_B_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[USP_AR_CertificateX_B_RegionalConsolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS
BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT 'Loans up to Rs.3 lakh' AS LoanSize,SUM(t1.GenNoOfAccounts) AS GenNoOfAccounts,SUM(t1.GenAmountDisbursed) AS GenAmountDisbursed,SUM(t1.GenAmountSubvention) AS GenAmountSubvention,
                   SUM(t1.SCNoOfAccounts) AS SCNoOfAccounts,SUM(t1.SCAmountDisbursed) AS SCAmountDisbursed,SUM(t1.SCAmountSubvention) AS SCAmountSubvention,
                   SUM(t1.STNoOfAccounts) AS STNoOfAccounts,SUM(t1.STAmountDisbursed) AS STAmountDisbursed,SUM(t1.STAmountSubvention) AS STAmountSubvention
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateX_B AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId =0) 
					AND 
					(t4.BranchZonalID =@localBranchZonalId OR @localBranchZonalId =0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2))
			
END



-- exec [USP_AR_CertificateX_B_RegionalConsolidation] 0,2,8,5,0


GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXII_A_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateXII_A_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t2.RecordHead,
			t1.NoOfAccounts1,t1.AmountDisbursed1,t1.NoOfAccounts2,t1.AmountDisbursed2,t1.AmountSubvention
			
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXII_A AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END




GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXII_A_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


create PROCEDURE [dbo].[USP_AR_CertificateXII_A_RegionalConsolidation]
@AnnexureId INT,@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT (SELECT RecordHead FROM AnnexureRecordHeadMaster WHERE HeadID=t1.HeadID) AS Head,SUM(t1.NoOfAccounts1) AS NoOfAccounts1,SUM(t1.AmountDisbursed1) AS AmountDisbursed1,
			SUM(t1.NoOfAccounts2) AS NoOfAccounts2, SUM(t1.AmountDisbursed2) AS AmountDisbursed2,SUM(t1.AmountSubvention) AS AmountSubvention
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXII_A AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)AND t2.AnnexureID=@AnnexureId)
			GROUP BY t1.HeadID
			ORDER BY t1.HeadID
END


-- exec [USP_AR_CertificateXXIV_A_RegionalConsolidation] 137,0,2,8,5,0

GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXII_B_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateXII_B_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t2.RecordHead,
			t1.GenNoOfAccounts,t1.GenAmountDisbursed,t1.GenAmountSubvention,t1.SCNoOfAccounts,t1.SCAmountDisbursed,t1.SCAmountSubvention,
			t1.STNoOfAccounts,t1.STAmountDisbursed,t1.STAmountSubvention
			
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXII_B AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END



GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXII_B_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


create PROCEDURE [dbo].[USP_AR_CertificateXII_B_RegionalConsolidation]
@AnnexureId INT,@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT (SELECT RecordHead FROM AnnexureRecordHeadMaster WHERE HeadID=t1.HeadID) AS Head,SUM(t1.GenNoOfAccounts) AS GenNoOfAccounts,SUM(t1.GenAmountDisbursed) AS GenAmountDisbursed,
			SUM(t1.GenAmountSubvention) AS GenAmountSubvention, SUM(t1.SCNoOfAccounts) AS SCNoOfAccounts,SUM(t1.SCAmountDisbursed) AS SCAmountDisbursed,SUM(t1.SCAmountSubvention) AS SCAmountSubvention
			,SUM(t1.STNoOfAccounts) AS STNoOfAccounts,SUM(t1.STAmountDisbursed) AS STAmountDisbursed,SUM(t1.STAmountSubvention) AS STAmountSubvention
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXII_B AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)AND t2.AnnexureID=@AnnexureId)
			GROUP BY t1.HeadID
			ORDER BY t1.HeadID
END


-- exec [USP_AR_CertificateXXIV_A_RegionalConsolidation] 137,0,2,8,5,0

GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXIII_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateXIII_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,'Bank of Baroda Branches' AS RecordHead,t1.NoOfBorrowers,t1.AmountInLacs
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXIII AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID
END


GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXIV_A1_A_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[USP_AR_CertificateXIV_A1_A_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t2.RecordHeadID,t2.RecordHead,
			t1.NoOfAccounts,t1.SubsidyReceived
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXIV_A1_A AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END



GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXIV_A1_A_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


create PROCEDURE [dbo].[USP_AR_CertificateXIV_A1_A_RegionalConsolidation]
@AnnexureId INT,@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT (SELECT RecordHead FROM AnnexureRecordHeadMaster WHERE HeadID=t1.HeadID) AS Head,
			SUM(t1.NoOfAccounts) AS NoOfAccounts,SUM(t1.SubsidyReceived) AS SubsidyReceived
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXIV_A1_A AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)AND t2.AnnexureID=@AnnexureId)
			GROUP BY t1.HeadID
			ORDER BY t1.HeadID
END


-- exec [USP_AR_CertificateXIV_A1_A_RegionalConsolidation] 136,0,2,8,5,0

GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXIV_A1_B_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateXIV_A1_B_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t2.RecordHeadID,t2.RecordHead,
			t1.NoOfAccounts,t1.SubsidyReceived
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXIV_A1_B AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END



GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXIV_A1_B_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

create PROCEDURE [dbo].[USP_AR_CertificateXIV_A1_B_RegionalConsolidation]
@AnnexureId INT,@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT (SELECT RecordHead FROM AnnexureRecordHeadMaster WHERE HeadID=t1.HeadID) AS Head,
			SUM(t1.NoOfAccounts) AS NoOfAccounts,SUM(t1.SubsidyReceived) AS SubsidyReceived
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXIV_A1_B AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)
					AND t2.AnnexureID=@AnnexureId)
			GROUP BY t1.HeadID
			ORDER BY t1.HeadID
END


-- exec USP_AR_CertificateXIV_A1_B_RegionalConsolidation 136,0,2,8,5,0

GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXIV_A2_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateXIV_A2_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,
			t1.LoanAccountNo,t1.NameOfBorrower,t1.NoOfAccounts,t1.SubsidyReceived,t1.ProcessingFees,t1.TotalSubsidy,t1.RefundMade
			
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXIV_A2 AS t1 ON t.BranchYearID=t1.BranchYearID
				
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID
END





GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXIV_A2_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create PROCEDURE [dbo].[USP_AR_CertificateXIV_A2_RegionalConsolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS
BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT SUM(t1.SubsidyReceived) AS SubsidyReceived,SUM(t1.ProcessingFees) AS ProcessingFees,SUM(t1.TotalSubsidy) AS TotalSubsidy
			,SUM(t1.RefundMade) AS RefundMade
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXIV_A2 AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId =0) 
					AND 
					(t4.BranchZonalID =@localBranchZonalId OR @localBranchZonalId =0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2))
			
END



-- exec [USP_AR_CertificateXIV_A2_RegionalConsolidation] 0,2,8,5,0


GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXIV_B_A_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateXIV_B_A_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t2.RecordHead,
			t1.DNHBNoOfAccounts,t1.DNHBInterestSubsidy,t1.[DNHBProcessingFees ],t1.DNHBTDS,t1.DNHBTotalAmount,
			t1.RNHBNoOfAccounts,t1.RNHBInterestSubsidy,t1.[RNHBProcessingFees ],t1.RNHBTotalAmount
			
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXIV_B_A AS t1 ON t.BranchYearID=t1.BranchYearID
	     	JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END



GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXIV_B_A_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateXIV_B_A_RegionalConsolidation]
@AnnexureId INT, @isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT (SELECT RecordHead FROM AnnexureRecordHeadMaster WHERE HeadID=t1.HeadID) AS Head,
			SUM(t1.DNHBNoOfAccounts) AS DNHBNoOfAccounts,SUM(t1.DNHBInterestSubsidy) AS DNHBInterestSubsidy,SUM(t1.[DNHBProcessingFees ]) AS DNHBProcessingFees ,SUM(t1.DNHBTDS) AS DNHBTDS,SUM(t1.DNHBTotalAmount) AS DNHBTotalAmount,
			SUM(t1.RNHBNoOfAccounts) AS RNHBNoOfAccounts,SUM(t1.RNHBInterestSubsidy) AS RNHBInterestSubsidy,SUM(t1.[RNHBProcessingFees ]) AS RNHBProcessingFees ,SUM(t1.RNHBTotalAmount) AS RNHBTotalAmount
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXIV_B_A AS t1 ON t.BranchYearID=t1.BranchYearID
	     	JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
					AND t2.AnnexureID=@AnnexureId
			GROUP BY t1.HeadID
			Order by t1.HeadID
END

--  exec USP_AR_CertificateXIV_B_A_RegionalConsolidation 152,0,2,8,5,0

GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXIV_B_B_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateXIV_B_B_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t2.RecordHead,
			t1.DNHBNoOfAccounts,t1.DNHBInterestSubsidy,t1.[DNHBProcessingFees ],t1.DNHBTDS,t1.DNHBTotalAmount,
			t1.RNHBNoOfAccounts,t1.RNHBInterestSubsidy,t1.[RNHBProcessingFees ],t1.RNHBTotalAmount
			
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXIV_B_B AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END



GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXIV_B_B_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateXIV_B_B_RegionalConsolidation]
@AnnexureId INT,@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT (SELECT RecordHead FROM AnnexureRecordHeadMaster WHERE HeadID=t1.HeadID) AS Head,
			SUM(t1.DNHBNoOfAccounts) AS DNHBNoOfAccounts,SUM(t1.DNHBInterestSubsidy) AS DNHBInterestSubsidy,SUM(t1.[DNHBProcessingFees ]) AS DNHBProcessingFees,SUM(t1.DNHBTDS) AS DNHBTDS,SUM(t1.DNHBTotalAmount) AS DNHBTotalAmount,
			SUM(t1.RNHBNoOfAccounts) AS RNHBNoOfAccounts,SUM(t1.RNHBInterestSubsidy) AS RNHBInterestSubsidy,SUM(t1.[RNHBProcessingFees ]) AS RNHBProcessingFees,SUM(t1.RNHBTotalAmount) AS RNHBTotalAmount
			
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXIV_B_B AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
					AND t2.AnnexureID=@AnnexureId
			GROUP BY t1.HeadID
			Order by t1.HeadID
END

--  exec USP_AR_CertificateXIV_B_B_RegionalConsolidation 152,0,2,8,5,0

GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXIV_C_A_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[USP_AR_CertificateXIV_C_A_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t2.RecordHeadID,t2.RecordHead,
			t1.NoOfAccounts,t1.NetSubsidyReceived
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXIV_C_A AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END



GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXIV_C_A_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[USP_AR_CertificateXIV_C_A_RegionalConsolidation]
@AnnexureId INT,@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT (SELECT RecordHead FROM AnnexureRecordHeadMaster WHERE HeadID=t1.HeadID) AS Head,
					SUM(t1.NoOfAccounts) AS NoOfAccounts,SUM(t1.NetSubsidyReceived) AS NetSubsidyReceived
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXIV_C_A AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)
					AND t2.AnnexureID=@AnnexureId)
			GROUP BY t1.HeadID
			ORDER BY t1.HeadID
END

--  exec USP_AR_CertificateXIV_C_A_RegionalConsolidation 158,0,2,8,5,0

GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXIV_C_B_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[USP_AR_CertificateXIV_C_B_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t2.RecordHeadID,t2.RecordHead,
					t1.NoOfAccounts,t1.NetSubsidyReceived
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXIV_C_B AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2))
			ORDER BY t1.BranchYearID,t1.HeadID
END



GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXIV_C_B_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[USP_AR_CertificateXIV_C_B_RegionalConsolidation]
@AnnexureId INT,@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT (SELECT RecordHead FROM AnnexureRecordHeadMaster WHERE HeadID=t1.HeadID) AS Head,
					SUM(t1.NoOfAccounts) AS NoOfAccounts,SUM(t1.NetSubsidyReceived) AS NetSubsidyReceived
			
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXIV_C_B AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)
					AND t2.AnnexureID=@AnnexureId)
			GROUP BY t1.HeadID		 
			ORDER BY t1.HeadID
END

-- exec USP_AR_CertificateXIV_C_B_RegionalConsolidation 158,0,2,8,5,0

GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXIV_C_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateXIV_C_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,
			t1.LoanAccountNo,t1.[Name of borrower],t1.SubsidyReceived,t1.ProcessingFees,t1.TotalSubsidy,t1.RefundMade
			
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXIV_C AS t1 ON t.BranchYearID=t1.BranchYearID
				
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID
END





GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXIV_C_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create PROCEDURE [dbo].[USP_AR_CertificateXIV_C_RegionalConsolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS
BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT SUM(t1.SubsidyReceived) AS SubsidyReceived,SUM(t1.ProcessingFees) AS ProcessingFees,SUM(t1.TotalSubsidy) AS TotalSubsidy
			,SUM(t1.RefundMade) AS RefundMade
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXIV_C AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId =0) 
					AND 
					(t4.BranchZonalID =@localBranchZonalId OR @localBranchZonalId =0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2))
			
END



-- exec [USP_AR_CertificateXIV_C_RegionalConsolidation] 0,2,8,5,0


GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXIV_D_A_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[USP_AR_CertificateXIV_D_A_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t2.RecordHead,
			t1.DNHBNoOfAccounts,t1.DNHBInterestSubsidy,t1.[DNHBProcessingFees ],t1.DNHBTDS,t1.DNHBTotalAmount,
			t1.RNHBNoOfAccounts,t1.RNHBInterestSubsidy,t1.[RNHBProcessingFees ],t1.RNHBTotalAmount
			
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXIV_D_A AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END




GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXIV_D_A_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


create PROCEDURE [dbo].[USP_AR_CertificateXIV_D_A_RegionalConsolidation]
@AnnexureId INT,@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT (SELECT RecordHead FROM AnnexureRecordHeadMaster WHERE HeadID=t1.HeadID) AS Head,
			SUM(t1.DNHBNoOfAccounts) AS DNHBNoOfAccounts,SUM(t1.DNHBInterestSubsidy) AS DNHBInterestSubsidy,SUM(t1.[DNHBProcessingFees ]) AS DNHBProcessingFees,SUM(t1.DNHBTDS) AS DNHBTDS,SUM(t1.DNHBTotalAmount) AS DNHBTotalAmount,
			SUM(t1.RNHBNoOfAccounts) AS RNHBNoOfAccounts,SUM(t1.RNHBInterestSubsidy) AS RNHBInterestSubsidy,SUM(t1.[RNHBProcessingFees ]) AS RNHBProcessingFees,SUM(t1.RNHBTotalAmount) AS RNHBTotalAmount
			
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXIV_D_A AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)
					AND t2.AnnexureID=@AnnexureId) 
			GROUP BY t1.HeadID
			ORDER BY t1.HeadID
END

-- exec USP_AR_CertificateXIV_D_A_RegionalConsolidation 160,0,2,8,5,0


GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXIV_D_B_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[USP_AR_CertificateXIV_D_B_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t2.RecordHead,
			t1.DNHBNoOfAccounts,t1.DNHBInterestSubsidy,t1.[DNHBProcessingFees ],t1.DNHBTDS,t1.DNHBTotalAmount,
			t1.RNHBNoOfAccounts,t1.RNHBInterestSubsidy,t1.[RNHBProcessingFees ],t1.RNHBTotalAmount
			
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXIV_D_B AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END




GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXIV_D_B_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


create PROCEDURE [dbo].[USP_AR_CertificateXIV_D_B_RegionalConsolidation]
@AnnexureId INT,@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT (SELECT RecordHead FROM AnnexureRecordHeadMaster WHERE HeadID=t1.HeadID) AS Head,
			SUM(t1.DNHBNoOfAccounts) AS DNHBNoOfAccounts,SUM(t1.DNHBInterestSubsidy) AS DNHBInterestSubsidy,SUM(t1.[DNHBProcessingFees ]) AS DNHBProcessingFees,SUM(t1.DNHBTDS) AS DNHBTDS,SUM(t1.DNHBTotalAmount) AS DNHBTotalAmount,
			SUM(t1.RNHBNoOfAccounts) AS RNHBNoOfAccounts,SUM(t1.RNHBInterestSubsidy) AS RNHBInterestSubsidy,SUM(t1.[RNHBProcessingFees ]) AS RNHBProcessingFees,SUM(t1.RNHBTotalAmount) AS RNHBTotalAmount
			
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXIV_D_B AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)
					AND t2.AnnexureID=@AnnexureId) 
			GROUP BY t1.HeadID
			ORDER BY t1.HeadID
END

-- exec USP_AR_CertificateXIV_D_B_RegionalConsolidation 160,0,2,8,5,0


GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXIX_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[USP_AR_CertificateXIX_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t1.AccountsDuringYear,t1.AmountDuringYear,t1.AccountsPreviousYearEnd,t1.AmountPreviousYearEnd,t1.AccountsCurrentYearEnd,t1.AmountCurrentYearEnd,t1.AccountsRegular,t1.AmountRegular,t1.AmountOfInterest
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXIX AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID
END




GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXIX_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


create PROCEDURE [dbo].[USP_AR_CertificateXIX_RegionalConsolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT SUM(t1.AccountsDuringYear) AS AccountsDuringYear,SUM(t1.AmountDuringYear) AS AmountDuringYear,SUM(t1.AccountsPreviousYearEnd) AS AccountsPreviousYearEnd,
			SUM(t1.AmountPreviousYearEnd) AS AmountPreviousYearEnd,SUM(t1.AccountsCurrentYearEnd) AS AccountsCurrentYearEnd,SUM(t1.AmountCurrentYearEnd) AS AmountCurrentYearEnd,
			SUM(t1.AccountsRegular) AS AccountsRegular,SUM(t1.AmountRegular) AS AmountRegular,SUM(t1.AmountOfInterest) AS AmountOfInterest
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXIX AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
END




GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXV_A_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateXV_A_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t2.RecordHead,t1.NoOfAccounts,t1.Amount
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXV_A AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END





GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXV_A_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateXV_A_RegionalConsolidation]
@AnnexureId INT,@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT (SELECT RecordHead FROM AnnexureRecordHeadMaster WHERE HeadID=t1.HeadID) AS Head,SUM(t1.NoOfAccounts) AS NoOfAccounts,SUM(t1.Amount) AS Amount
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXV_A AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)
					AND t2.AnnexureID=@AnnexureId)
			GROUP BY t1.HeadID
			ORDER BY t1.HeadID
END

-- exec USP_AR_CertificateXV_A_RegionalConsolidation 149,0,2,8,5,0



GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXV_B_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateXV_B_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t2.RecordHead,t1.Q1_NoOfAccounts,t1.Q1_Amount,t1.Q2_NoOfAccounts,t1.Q2_Amount,
			t1.Q3_NoOfAccounts,t1.Q3_Amount,t1.Q4_NoOfAccounts,t1.Q4_Amount,t1.Total_NoOfAccounts,t1.Total_Amount
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXV_B AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END




GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXV_B_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

create PROCEDURE [dbo].[USP_AR_CertificateXV_B_RegionalConsolidation]
@AnnexureId INT,@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT (SELECT RecordHead FROM AnnexureRecordHeadMaster WHERE HeadID=t1.HeadID) AS Head,SUM(t1.Q1_NoOfAccounts) AS Q1_NoOfAccounts,SUM(t1.Q1_Amount) AS Q1_Amount,
			SUM(t1.Q2_NoOfAccounts) AS Q2_NoOfAccounts,SUM(t1.Q2_Amount) AS Q2_Amount,SUM(t1.Q3_NoOfAccounts) AS Q3_NoOfAccounts,SUM(t1.Q3_Amount) AS Q3_Amount,
			SUM(t1.Q4_NoOfAccounts) AS Q4_NoOfAccounts,SUM(t1.Q4_Amount) AS Q4_Amount,SUM(t1.Total_NoOfAccounts) AS Total_NoOfAccounts,SUM(t1.Total_Amount) AS Total_Amount
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXV_B AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)
					AND t2.AnnexureID=@AnnexureId)
			GROUP BY t1.HeadID
			ORDER BY t1.HeadID
END


-- exec USP_AR_CertificateXV_B_RegionalConsolidation 150,0,2,8,5,0

GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXV_C_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateXV_C_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t2.RecordHead,t1.Q1_NoOfAccounts,t1.Q1_Amount,t1.Q2_NoOfAccounts,t1.Q2_Amount,
			t1.Q3_NoOfAccounts,t1.Q3_Amount,t1.Q4_NoOfAccounts,t1.Q4_Amount,t1.Total_NoOfAccounts,t1.Total_Amount
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXV_C AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END




GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXV_C_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


create PROCEDURE [dbo].[USP_AR_CertificateXV_C_RegionalConsolidation]
@AnnexureId INT,@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT (SELECT RecordHead FROM AnnexureRecordHeadMaster WHERE HeadID=t1.HeadID) AS Head,SUM(t1.Q1_NoOfAccounts) AS Q1_NoOfAccounts,SUM(t1.Q1_Amount) AS Q1_Amount,SUM(t1.Q2_NoOfAccounts) AS Q2_NoOfAccounts,SUM(t1.Q2_Amount) AS Q2_Amount,
			SUM(t1.Q3_NoOfAccounts) AS Q3_NoOfAccounts,SUM(t1.Q3_Amount) AS Q3_Amount,SUM(t1.Q4_NoOfAccounts) AS Q4_NoOfAccounts,SUM(t1.Q4_Amount) AS Q4_Amount,SUM(t1.Total_NoOfAccounts) AS Total_NoOfAccounts,SUM(t1.Total_Amount) AS Total_Amount
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXV_C AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)AND t2.AnnexureID=@AnnexureId)
			GROUP BY t1.HeadID
			ORDER BY t1.HeadID
END


-- exec [USP_AR_CertificateXXIV_A_RegionalConsolidation] 137,0,2,8,5,0

GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXVIII_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[USP_AR_CertificateXVIII_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t1.AccountsDuringYear,t1.AmountDuringYear,t1.AccountsPreviousYearEnd,t1.AmountPreviousYearEnd,t1.AccountsCurrentYearEnd,t1.AmountCurrentYearEnd,t1.AmountOfInterest
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXVIII AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID
END




GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXVIII_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


create PROCEDURE [dbo].[USP_AR_CertificateXVIII_RegionalConsolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT SUM(t1.AccountsDuringYear) AS AccountsDuringYear,SUM(t1.AmountDuringYear) AS AmountDuringYear,SUM(t1.AccountsPreviousYearEnd) AS AccountsPreviousYearEnd,
			SUM(t1.AmountPreviousYearEnd) AS AmountPreviousYearEnd,SUM(t1.AccountsCurrentYearEnd) AS AccountsCurrentYearEnd,SUM(t1.AmountCurrentYearEnd) AS AmountCurrentYearEnd,SUM(t1.AmountOfInterest) AS AmountOfInterest
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXVIII AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
END




GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXX_A_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateXX_A_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.RegionCode,t.RegionName,t.ZonalCode,t.ZonalName,t1.NameofUnit,t1.SubsidyAmountreceived,t1.NO,t1.Date,t1.Amount
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN  AR_CertificateXX_A AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID
END



GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXX_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[USP_AR_CertificateXX_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t1.NameofUnit,t1.SubsidyAmountreceived,t1.NO,t1.Date,t1.Amount
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXX AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID
END




GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXI_A_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateXXI_A_RegionalConsolidation]
@AnnexureId INT,@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT SUM(t1.TotalRecovery) AS TotalRecovery,SUM(t1.AmountPassed) AS AmountPassed,SUM(t1.ShortAmount) AS ShortAmount 
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN  AR_CertificateXXI_A AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2) AND t2.AnnexureID=@AnnexureId)
			GROUP BY t1.HeadID
			ORDER BY t1.HeadID
END



GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXI_I_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[USP_AR_CertificateXXI_I_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t1.Branch,t1.Region,t1.TotalRecovery,t1.AmountPassed,t1.ShortAmount
			
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXI_A AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END


GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXI_II_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateXXI_II_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t1.NameOfAccount,t1.AccountNo,t1.CGPAN,t1.OpeningBalance,t1.AmountTransferredFromBranch,t1.ClaimsReceived,t1.TotalClaims,t1.Recoveries,t1.LegalCharges,t1.RecoveryNetCharges,t1.RecoveriesRemitted,t1.AmountPending,t1.AmountTransferredToAccount,t1.TotalAmount,t1.ClosingBalance,t1.IrregularitySBA,t1.ReplyOfBranch
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXI_II AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID
END




GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXI_II_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[USP_AR_CertificateXXI_II_RegionalConsolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS
BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT SUM(t1.OpeningBalance) AS OpeningBalance,SUM(t1.AmountTransferredFromBranch) AS AmountTransferredFromBranch,SUM(t1.ClaimsReceived) AS ClaimsReceived
			,SUM(t1.TotalClaims) AS TotalClaims,SUM(t1.Recoveries) AS Recoveries,SUM(t1.LegalCharges) AS LegalCharges,SUM(t1.RecoveryNetCharges) AS RecoveryNetCharges,SUM(t1.RecoveriesRemitted) AS RecoveriesRemitted,
			SUM(t1.AmountPending) AS AmountPending,SUM(t1.AmountTransferredToAccount) AS AmountTransferredToAccount,SUM(t1.TotalAmount) AS TotalAmount,SUM(t1.ClosingBalance) AS ClosingBalance
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXI_II AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId =0) 
					AND 
					(t4.BranchZonalID =@localBranchZonalId OR @localBranchZonalId =0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2))
			
END



-- exec [USP_AR_CertificateXXI_II_RegionalConsolidation] 0,2,8,5,0


GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXI_III_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateXXI_III_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t1.NameOfAccount,t1.AccountNo,t1.CGPAN,t1.OpeningBalance,t1.AmountTransferredFromBranch,t1.ClaimsReceived,t1.TotalClaims,t1.Recoveries,t1.LegalCharges,t1.RecoveryNetCharges,t1.RecoveriesRemitted,t1.AmountPending,t1.AmountTransferredToAccount,t1.TotalAmount,t1.ClosingBalance,t1.IrregularitySBA,t1.ReplyOfBranch
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXI_III AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID
END




GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXI_III_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create PROCEDURE [dbo].[USP_AR_CertificateXXI_III_RegionalConsolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS
BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT SUM(t1.OpeningBalance) AS OpeningBalance,SUM(t1.AmountTransferredFromBranch) AS AmountTransferredFromBranch,SUM(t1.ClaimsReceived) AS ClaimsReceived
			,SUM(t1.TotalClaims) AS TotalClaims,SUM(t1.Recoveries) AS Recoveries,SUM(t1.LegalCharges) AS LegalCharges,SUM(t1.RecoveryNetCharges) AS RecoveryNetCharges,SUM(t1.RecoveriesRemitted) AS RecoveriesRemitted,
			SUM(t1.AmountPending) AS AmountPending,SUM(t1.AmountTransferredToAccount) AS AmountTransferredToAccount,SUM(t1.TotalAmount) AS TotalAmount,SUM(t1.ClosingBalance) AS ClosingBalance
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXI_III AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId =0) 
					AND 
					(t4.BranchZonalID =@localBranchZonalId OR @localBranchZonalId =0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2))
			
END



-- exec [USP_AR_CertificateXXI_III_RegionalConsolidation] 0,2,8,5,0


GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXI_IV_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateXXI_IV_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t1.NameOfAccount,t1.AccountNo,t1.CGPAN,t1.OpeningBalance,t1.AmountTransferredFromBranch,t1.ClaimsReceived,t1.TotalClaims,t1.Recoveries,t1.LegalCharges,t1.RecoveryNetCharges,t1.RecoveriesRemitted,t1.AmountPending,t1.AmountTransferredToAccount,t1.TotalAmount,t1.ClosingBalance,t1.IrregularitySBA,t1.ReplyOfBranch
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXI_IV AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID
END




GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXI_IV_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create PROCEDURE [dbo].[USP_AR_CertificateXXI_IV_RegionalConsolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS
BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT SUM(t1.OpeningBalance) AS OpeningBalance,SUM(t1.AmountTransferredFromBranch) AS AmountTransferredFromBranch,SUM(t1.ClaimsReceived) AS ClaimsReceived
			,SUM(t1.TotalClaims) AS TotalClaims,SUM(t1.Recoveries) AS Recoveries,SUM(t1.LegalCharges) AS LegalCharges,SUM(t1.RecoveryNetCharges) AS RecoveryNetCharges,SUM(t1.RecoveriesRemitted) AS RecoveriesRemitted,
			SUM(t1.AmountPending) AS AmountPending,SUM(t1.AmountTransferredToAccount) AS AmountTransferredToAccount,SUM(t1.TotalAmount) AS TotalAmount,SUM(t1.ClosingBalance) AS ClosingBalance
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXI_IV AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId =0) 
					AND 
					(t4.BranchZonalID =@localBranchZonalId OR @localBranchZonalId =0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2))
			
END



-- exec [USP_AR_CertificateXXI_IV_RegionalConsolidation] 0,2,8,5,0


GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXII_A_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateXXII_A_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t1.NameOfTheSugarMill,t1.Amount
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXII_A AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID
END





GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXII_A_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create PROCEDURE [dbo].[USP_AR_CertificateXXII_A_RegionalConsolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS
BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT SUM(t1.Amount) AS Amount
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXII_A AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId =0) 
					AND 
					(t4.BranchZonalID =@localBranchZonalId OR @localBranchZonalId =0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2))
			
END



-- exec [USP_AR_CertificateXXII_A_RegionalConsolidation] 0,2,8,5,0


GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXII_B_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateXXII_B_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t1.NameOfTheSugarMill,t1.Amount
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXII_B AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID
END




GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXII_B_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create PROCEDURE [dbo].[USP_AR_CertificateXXII_B_RegionalConsolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS
BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT SUM(t1.Amount) AS Amount
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXII_B AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId =0) 
					AND 
					(t4.BranchZonalID =@localBranchZonalId OR @localBranchZonalId =0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2))
			
END



-- exec [USP_AR_CertificateXXII_B_RegionalConsolidation] 0,2,8,5,0


GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXIII_A_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateXXIII_A_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t2.RecordHead,t1.NoOfAccounts,t1.Outstanding
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXIII_A AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END




GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXIII_A_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


create PROCEDURE [dbo].[USP_AR_CertificateXXIII_A_RegionalConsolidation]
@AnnexureId INT,@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT (SELECT RecordHead FROM AnnexureRecordHeadMaster WHERE HeadID=t1.HeadID) AS Head,
			SUM(t1.NoOfAccounts) AS NoOfAccounts,SUM(t1.Outstanding) AS Outstanding
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXIII_A AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)AND t2.AnnexureID=@AnnexureId)
			GROUP BY t1.HeadID
			ORDER BY t1.HeadID
END


-- exec [USP_AR_CertificateXIV_A1_A_RegionalConsolidation] 136,0,2,8,5,0

GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXIII_B_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateXXIII_B_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t1.CustomeId,
			t1.PanNo,t1.NameOfAccount,t1.Amount,t1.DateOfRP,t1.AssetClassification_Before,t1.AssetClassification_After,
			t1.RP_Ownership,t1.ProvisionAmount,t1.IrregularitySBA,t1.DateOfRFA,t1.DateOfLifRFA,t1.DateOfDecOfFraud
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXIII_B AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID
END




GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXIII_B_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateXXIII_B_RegionalConsolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT SUM(t1.Amount) AS Amount
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXIII_B AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
END


--  exec [USP_AR_CertificateXXIII_B_RegionalConsolidation] 0,2,8,5,0

GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXIV_A_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateXXIV_A_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t2.RecordHead,t1.NewLoanAccountsOpened_NoOfAccounts_CY,t1.NewLoanAccountsOpened_Amount_CY,t1.Outstanding_NoOfAccounts_PY,t1.Outstanding_Amount_PY,t1.TotalOutstandingas_NoOfAccounts_PY,t1.TotalOutstandingas_Amount_PY,t1.AmountofInterestSubvention_Amount_PY
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXIV_A AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END




GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXIV_A_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[USP_AR_CertificateXXIV_A_RegionalConsolidation]
@AnnexureId INT,@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT (SELECT RecordHead FROM AnnexureRecordHeadMaster WHERE HeadID=t1.HeadID) AS Head,
			SUM(t1.NewLoanAccountsOpened_NoOfAccounts_CY) AS NewLoanAccountsOpened_NoOfAccounts_CY,SUM(t1.NewLoanAccountsOpened_Amount_CY) AS NewLoanAccountsOpened_Amount_CY,
			SUM(t1.Outstanding_NoOfAccounts_PY) AS Outstanding_NoOfAccounts_PY,SUM(t1.Outstanding_Amount_PY) AS Outstanding_Amount_PY,
			SUM(t1.TotalOutstandingas_NoOfAccounts_PY) AS TotalOutstandingas_NoOfAccounts_PY,SUM(t1.TotalOutstandingas_Amount_PY) AS TotalOutstandingas_Amount_PY,SUM(t1.AmountofInterestSubvention_Amount_PY) AS AmountofInterestSubvention_Amount_PY
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXIV_A AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)AND t2.AnnexureID=@AnnexureId)
			GROUP BY t1.HeadID
			ORDER BY t1.HeadID
END


-- exec [USP_AR_CertificateXXIV_A_RegionalConsolidation] 137,0,2,8,5,0

GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXIV_B_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateXXIV_B_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t2.RecordHead,
			t1.NewLoanAccountsOpened_NoOfAccounts_CY,t1.NewLoanAccountsOpened_Amount_CY,t1.Outstanding_NoOfAccounts_PY,
			t1.Outstanding_Amount_PY,t1.TotalOutstandingas_NoOfAccounts_PY,t1.TotalOutstandingas_Amount_PY,t1.EligibleWomenSHG,t1.AmountofInterestSubvention_Amount_PY
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXIV_B AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END




GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXIV_B_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


create PROCEDURE [dbo].[USP_AR_CertificateXXIV_B_RegionalConsolidation]
@AnnexureId INT,@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT (SELECT RecordHead FROM AnnexureRecordHeadMaster WHERE HeadID=t1.HeadID) AS Head,
			SUM(t1.NewLoanAccountsOpened_NoOfAccounts_CY) AS NewLoanAccountsOpened_NoOfAccounts_CY,SUM(t1.NewLoanAccountsOpened_Amount_CY) AS NewLoanAccountsOpened_Amount_CY,
			SUM(t1.Outstanding_NoOfAccounts_PY) AS Outstanding_NoOfAccounts_PY,SUM(t1.Outstanding_Amount_PY) AS Outstanding_Amount_PY,
			SUM(t1.TotalOutstandingas_NoOfAccounts_PY) AS TotalOutstandingas_NoOfAccounts_PY,SUM(t1.TotalOutstandingas_Amount_PY) AS TotalOutstandingas_Amount_PY,SUM(t1.AmountofInterestSubvention_Amount_PY) AS AmountofInterestSubvention_Amount_PY
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXIV_B AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)AND t2.AnnexureID=@AnnexureId)
			GROUP BY t1.HeadID
			ORDER BY t1.HeadID
END


-- exec [USP_AR_CertificateXXIV_A_RegionalConsolidation] 137,0,2,8,5,0

GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXIV_C_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateXXIV_C_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t2.RecordHead,t1.NewLoanAccountsOpened_NoOfAccounts_CY,t1.NewLoanAccountsOpened_Amount_CY,t1.Outstanding_NoOfAccounts_PY,t1.Outstanding_Amount_PY,t1.TotalOutstandingas_NoOfAccounts_PY,t1.TotalOutstandingas_Amount_PY,t1.AmountofInterestSubvention_Amount_PY
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXIV_C AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END




GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXIV_C_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


create PROCEDURE [dbo].[USP_AR_CertificateXXIV_C_RegionalConsolidation]
@AnnexureId INT,@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT (SELECT RecordHead FROM AnnexureRecordHeadMaster WHERE HeadID=t1.HeadID) AS Head,
			SUM(t1.NewLoanAccountsOpened_NoOfAccounts_CY) AS NewLoanAccountsOpened_NoOfAccounts_CY,SUM(t1.NewLoanAccountsOpened_Amount_CY) AS NewLoanAccountsOpened_Amount_CY,
			SUM(t1.Outstanding_NoOfAccounts_PY) AS Outstanding_NoOfAccounts_PY,SUM(t1.Outstanding_Amount_PY) AS Outstanding_Amount_PY,
			SUM(t1.TotalOutstandingas_NoOfAccounts_PY) AS TotalOutstandingas_NoOfAccounts_PY,SUM(t1.TotalOutstandingas_Amount_PY) AS TotalOutstandingas_Amount_PY,SUM(t1.AmountofInterestSubvention_Amount_PY) AS AmountofInterestSubvention_Amount_PY
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXIV_C AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)AND t2.AnnexureID=@AnnexureId)
			GROUP BY t1.HeadID
			ORDER BY t1.HeadID
END


-- exec [USP_AR_CertificateXXIV_A_RegionalConsolidation] 137,0,2,8,5,0

GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXIV_D_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateXXIV_D_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t2.RecordHead,t1.NewLoanAccountsOpened_NoOfAccounts_CY,t1.NewLoanAccountsOpened_Amount_CY,t1.Outstanding_NoOfAccounts_PY,t1.Outstanding_Amount_PY,t1.TotalOutstandingas_NoOfAccounts_PY,t1.TotalOutstandingas_Amount_PY,t1.AmountofInterestSubvention_Amount_PY
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXIV_D AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END




GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXIV_D_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


create PROCEDURE [dbo].[USP_AR_CertificateXXIV_D_RegionalConsolidation]
@AnnexureId INT,@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT (SELECT RecordHead FROM AnnexureRecordHeadMaster WHERE HeadID=t1.HeadID) AS Head,
			SUM(t1.NewLoanAccountsOpened_NoOfAccounts_CY) AS NewLoanAccountsOpened_NoOfAccounts_CY,SUM(t1.NewLoanAccountsOpened_Amount_CY) AS NewLoanAccountsOpened_Amount_CY,
			SUM(t1.Outstanding_NoOfAccounts_PY) AS Outstanding_NoOfAccounts_PY,SUM(t1.Outstanding_Amount_PY) AS Outstanding_Amount_PY,
			SUM(t1.TotalOutstandingas_NoOfAccounts_PY) AS TotalOutstandingas_NoOfAccounts_PY,SUM(t1.TotalOutstandingas_Amount_PY) AS TotalOutstandingas_Amount_PY,SUM(t1.AmountofInterestSubvention_Amount_PY) AS AmountofInterestSubvention_Amount_PY
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXIV_D AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)AND t2.AnnexureID=@AnnexureId)
			GROUP BY t1.HeadID
			ORDER BY t1.HeadID
END


-- exec [USP_AR_CertificateXXIV_A_RegionalConsolidation] 137,0,2,8,5,0

GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXV_A_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateXXV_A_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t2.RecordHead,
			t1.MSME1,t1.MSME2,t1.Total1,t1.MSME3,t1.MSME4,t1.Total2
			
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXV_A AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END



GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXV_A_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[USP_AR_CertificateXXV_A_RegionalConsolidation]
@AnnexureId INT,@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT (SELECT RecordHead FROM AnnexureRecordHeadMaster WHERE HeadID=t1.HeadID) AS Head,
			SUM(t1.MSME1) AS MSME1,SUM(t1.MSME2) AS MSME2,SUM(t1.Total1) AS Total1,SUM(t1.MSME3) AS MSME3,SUM(t1.MSME4) AS MSME4,SUM(t1.Total2) AS Total2
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXV_A AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)AND t2.AnnexureID=@AnnexureId)
			GROUP BY t1.HeadID
			ORDER BY t1.HeadID
END


-- exec [USP_AR_CertificateXXIV_A_RegionalConsolidation] 137,0,2,8,5,0

GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXV_B_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateXXV_B_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t2.RecordHead,
			t1.MSME1,t1.MSME2,t1.Total1,t1.MSME3,t1.MSME4,t1.Total2
			
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXV_B AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END




GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXV_B_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


create PROCEDURE [dbo].[USP_AR_CertificateXXV_B_RegionalConsolidation]
@AnnexureId INT,@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT (SELECT RecordHead FROM AnnexureRecordHeadMaster WHERE HeadID=t1.HeadID) AS Head,
			SUM(t1.MSME1) AS MSME1,SUM(t1.MSME2) AS MSME2,SUM(t1.Total1) AS Total1,SUM(t1.MSME3) AS MSME3,SUM(t1.MSME4) AS MSME4,SUM(t1.Total2) AS Total2
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXV_B AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)AND t2.AnnexureID=@AnnexureId)
			GROUP BY t1.HeadID
			ORDER BY t1.HeadID
END


-- exec [USP_AR_CertificateXXIV_A_RegionalConsolidation] 137,0,2,8,5,0

GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXV_C_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateXXV_C_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t2.RecordHead,
			t1.MSME1,t1.MSME2,t1.Total1,t1.MSME3,t1.MSME4,t1.Total2
			
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXV_C AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END



GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXV_C_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


create PROCEDURE [dbo].[USP_AR_CertificateXXV_C_RegionalConsolidation]
@AnnexureId INT,@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT (SELECT RecordHead FROM AnnexureRecordHeadMaster WHERE HeadID=t1.HeadID) AS Head,
			SUM(t1.MSME1) AS MSME1,SUM(t1.MSME2) AS MSME2,SUM(t1.Total1) AS Total1,SUM(t1.MSME3) AS MSME3,SUM(t1.MSME4) AS MSME4,SUM(t1.Total2) AS Total2
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXV_C AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)AND t2.AnnexureID=@AnnexureId)
			GROUP BY t1.HeadID
			ORDER BY t1.HeadID
END


-- exec [USP_AR_CertificateXXIV_A_RegionalConsolidation] 137,0,2,8,5,0

GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXV_D_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateXXV_D_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t2.RecordHead,
			t1.MSME1,t1.MSME2,t1.TradingActivities,t1.Total1,t1.MSME3,t1.MSME4,t1.TradingActivities1,t1.Total2
			
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXV_D AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END




GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXV_D_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


create PROCEDURE [dbo].[USP_AR_CertificateXXV_D_RegionalConsolidation]
@AnnexureId INT,@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT (SELECT RecordHead FROM AnnexureRecordHeadMaster WHERE HeadID=t1.HeadID) AS Head,
			SUM(t1.MSME1) AS MSME1,SUM(t1.MSME2) AS MSME2,SUM(t1.TradingActivities) AS TradingActivities,SUM(t1.Total1) AS Total1,SUM(t1.MSME3) AS MSME3,SUM(t1.MSME4) AS MSME4,SUM(t1.TradingActivities1) AS TradingActivities1,SUM(t1.Total2) AS Total2
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXV_D AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)AND t2.AnnexureID=@AnnexureId)
			GROUP BY t1.HeadID
			ORDER BY t1.HeadID
END


-- exec [USP_AR_CertificateXXIV_A_RegionalConsolidation] 137,0,2,8,5,0

GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXVII_A_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateXXVII_A_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,
			t1.NameofUnit,t1.BranchRegionZone,t1.SubsidyAmountreceived,t1.SubsidyAmountdisbursed,t1.SubsidyDisbursedDate
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXVII_A AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID
END



GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXVII_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[USP_AR_CertificateXXVII_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t1.NameofUnits,t1.SubsidyAmountreceived,t1.SubsidyAmountdisbursed,t1.Amount
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXVII AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID
END




GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXVIII_1_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

create PROCEDURE [dbo].[USP_AR_CertificateXXVIII_1_RegionalConsolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT SUM(t1.General_NoOfAccounts) AS General_NoOfAccounts,SUM(t1.General_AmountDrawn) AS General_AmountDrawn,SUM(t1.General_AmountClaimed) AS General_AmountClaimed,
					SUM(t1.SC_NoOfAccounts) AS SC_NoOfAccounts,SUM(t1.SC_AmountDrawn) AS SC_AmountDrawn,SUM(t1.SC_AmountClaimed) AS SC_AmountClaimed,
					SUM(t1.ST_NoOfAccounts) AS ST_NoOfAccounts,SUM(t1.ST_AmountDrawn) AS ST_AmountDrawn,SUM(t1.ST_AmountClaimed) AS ST_AmountClaimed
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXVIII AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
END


--  exec [USP_AR_CertificateXXIII_B_RegionalConsolidation] 0,2,8,5,0

GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXVIII_A_I_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[USP_AR_CertificateXXVIII_A_I_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,
			t2.RecordHead,t1.NoOfAccounts,t1.AmountDrawn,t1.AmountClaimed
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXVIII_A AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END




GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXVIII_A_II_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[USP_AR_CertificateXXVIII_A_II_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t2.RecordHead,
			t1.General_NoOfAccounts,t1.General_AmountDrawn,t1.General_AmountClaimed,
				   t1.SC_NoOfAccounts,t1.SC_AmountDrawn,t1.SC_AmountClaimed,t1.ST_NoOfAccounts,t1.ST_AmountDrawn,t1.ST_AmountClaimed
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXVIII_A AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END



GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXVIII_A_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

create PROCEDURE [dbo].[USP_AR_CertificateXXVIII_A_RegionalConsolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT SUM(t1.NoOfAccounts) AS NoOfAccounts,SUM(t1.AmountDrawn) AS AmountDrawn,SUM(t1.AmountClaimed) AS AmountClaimed
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXVIII_A AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
END


--  exec [USP_AR_CertificateXXIII_B_RegionalConsolidation] 0,2,8,5,0

GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXVIII_A1_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

create PROCEDURE [dbo].[USP_AR_CertificateXXVIII_A1_RegionalConsolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT SUM(t1.General_NoOfAccounts) AS General_NoOfAccounts,SUM(t1.General_AmountDrawn) AS General_AmountDrawn,SUM(t1.General_AmountClaimed) AS General_AmountClaimed,
					SUM(t1.SC_NoOfAccounts) AS SC_NoOfAccounts,SUM(t1.SC_AmountDrawn) AS SC_AmountDrawn,SUM(t1.SC_AmountClaimed) AS SC_AmountClaimed,
					SUM(t1.ST_NoOfAccounts) AS ST_NoOfAccounts,SUM(t1.ST_AmountDrawn) AS ST_AmountDrawn,SUM(t1.ST_AmountClaimed) AS ST_AmountClaimed
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXVIII_A AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
END


--  exec [USP_AR_CertificateXXIII_B_RegionalConsolidation] 0,2,8,5,0

GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXVIII_B_I_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateXXVIII_B_I_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,
			t2.RecordHead,t1.NoOfAccounts,t1.AmountDrawn,t1.AmountClaimed
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXVIII_B AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END




GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXVIII_B_II_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[USP_AR_CertificateXXVIII_B_II_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t2.RecordHead,
			t1.General_NoOfAccounts,t1.General_AmountDrawn,t1.General_AmountClaimed,
				   t1.SC_NoOfAccounts,t1.SC_AmountDrawn,t1.SC_AmountClaimed,t1.ST_NoOfAccounts,t1.ST_AmountDrawn,t1.ST_AmountClaimed
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXVIII_B AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END



GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXVIII_B_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

create PROCEDURE [dbo].[USP_AR_CertificateXXVIII_B_RegionalConsolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT SUM(t1.NoOfAccounts) AS NoOfAccounts,SUM(t1.AmountDrawn) AS AmountDrawn,SUM(t1.AmountClaimed) AS AmountClaimed
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXVIII_B AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
END


--  exec [USP_AR_CertificateXXIII_B_RegionalConsolidation] 0,2,8,5,0

GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXVIII_B1_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

create PROCEDURE [dbo].[USP_AR_CertificateXXVIII_B1_RegionalConsolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT SUM(t1.General_NoOfAccounts) AS General_NoOfAccounts,SUM(t1.General_AmountDrawn) AS General_AmountDrawn,SUM(t1.General_AmountClaimed) AS General_AmountClaimed,
					SUM(t1.SC_NoOfAccounts) AS SC_NoOfAccounts,SUM(t1.SC_AmountDrawn) AS SC_AmountDrawn,SUM(t1.SC_AmountClaimed) AS SC_AmountClaimed,
					SUM(t1.ST_NoOfAccounts) AS ST_NoOfAccounts,SUM(t1.ST_AmountDrawn) AS ST_AmountDrawn,SUM(t1.ST_AmountClaimed) AS ST_AmountClaimed
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXVIII_B AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
END


--  exec [USP_AR_CertificateXXIII_B_RegionalConsolidation] 0,2,8,5,0

GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXVIII_I_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[USP_AR_CertificateXXVIII_I_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,
			t2.RecordHead,t1.NoOfAccounts,t1.AmountDrawn,t1.AmountClaimed
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXVIII AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END




GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXVIII_II_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[USP_AR_CertificateXXVIII_II_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t2.RecordHead,
			t1.General_NoOfAccounts,t1.General_AmountDrawn,t1.General_AmountClaimed,
				   t1.SC_NoOfAccounts,t1.SC_AmountDrawn,t1.SC_AmountClaimed,t1.ST_NoOfAccounts,t1.ST_AmountDrawn,t1.ST_AmountClaimed
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXVIII AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END



GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXVIII_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

create PROCEDURE [dbo].[USP_AR_CertificateXXVIII_RegionalConsolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT SUM(t1.NoOfAccounts) AS NoOfAccounts,SUM(t1.AmountDrawn) AS AmountDrawn,SUM(t1.AmountClaimed) AS AmountClaimed
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXVIII AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
END


--  exec [USP_AR_CertificateXXIII_B_RegionalConsolidation] 0,2,8,5,0

GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXX_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[USP_AR_CertificateXXX_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,
				   RecordHead = REPLACE(REPLACE(REPLACE( REPLACE(t2.RecordHead,'aaaa',(t3.FinYear)),'bbbb',(t3.FinYear+1)),'cccc',(t3.FinYear+1)),'yyyy',(t3.FinYear)),
				   t1.Amount
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXX AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END




GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXX_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[USP_AR_CertificateXXX_RegionalConsolidation]
@AnnexureId INT,@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT (SELECT RecordHead FROM AnnexureRecordHeadMaster WHERE HeadID=t1.HeadID) AS Head,SUM(t1.Amount) AS Amount
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXX AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)AND t2.AnnexureID=@AnnexureId)
			GROUP BY t1.HeadID
			ORDER BY t1.HeadID
END


-- exec [USP_AR_CertificateXXX_RegionalConsolidation] 145,0,2,8,5,0

GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXXI_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateXXXI_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t1.NumberOfApplications,t1.ApplicationsApproved,t1.ApplicationsRejected
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXXI AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID
END




GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXXIII_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateXXXIII_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,
			       RecordHead = REPLACE(t2.RecordHead,'yyyy',(t3.FinYear)),t1.PendingEntries
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXXIII AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END




GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXXIII_RegionalConsolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[USP_AR_CertificateXXXIII_RegionalConsolidation]
@AnnexureId INT,@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT (SELECT RecordHead FROM AnnexureRecordHeadMaster WHERE HeadID=t1.HeadID) AS Head,SUM(t1.PendingEntries) AS PendingEntries
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXXIII AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)AND t2.AnnexureID=@AnnexureId)
			GROUP BY t1.HeadID
			ORDER BY t1.HeadID
END


-- exec USP_AR_CertificateXXXIII_RegionalConsolidation 148,0,2,8,5,0

GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXXIX_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

create PROCEDURE [dbo].[USP_AR_CertificateXXXIX_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,
			t1.PAN,t1.NameOfAccount,t1.Amount,t1.RFA_Date,t1.RFALiftingDate,t1.DeclarationOfFraudDate,
			t1.IrregularitySBA,t1.ReplyOfBranch
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXXIX AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID
END




GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXXV_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateXXXV_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t1.Date1,t1.Amount5,t1.Amount2,t1.Amount3,t1.Amount4
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AnnexureDetails AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)
					AND
					(t1.AnnexureID = 181))
			ORDER BY t1.BranchYearID
END


GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXXVII_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

create PROCEDURE [dbo].[USP_AR_CertificateXXXVII_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,
			t1.CustomerId,t1.NameOfAccount,t1.ProjectCategory,t1.ParticularsOfProject,t1.AccountNumber,
			t1.OriginalDCCODate,t1.DCCOExtentionDate,t1.DCCOCompleted,t1.DCCOCompletionDate,
			t1.TwoYearsOfCompletion,t1.Amount,t1.ProvisionAmount,t1.IrregularitySBA,t1.ReplyOfBranch
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXXVII AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID
END




GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXXVIII_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_AR_CertificateXXXVIII_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t2.RecordHead,
			t1.NoOfAccounts,t1.ExposureToaccounts,t1.AggregateAmount,
			t1.AdditionalFunding,t1.IncreaseInProvision
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXXVIII AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END




GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXXX_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

create PROCEDURE [dbo].[USP_AR_CertificateXXXX_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,
			t1.Number1,t1.Amount1
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AnnexureDetails AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)
					AND
					(t1.AnnexureID = 190))
			ORDER BY t1.BranchYearID
END


GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXXXII_A_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

create PROCEDURE [dbo].[USP_AR_CertificateXXXXII_A_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;


			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t2.RecordHead,
			t1.NoOfAccounts,t1.Ammount_Credit,t1.NoOfAccounts_Repay,
			t1.Amount_Repay,t1.AmountClaimed
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXXXII_A AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END




GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXXXII_B_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

create PROCEDURE [dbo].[USP_AR_CertificateXXXXII_B_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t2.RecordHead,
			t1.NoOfAccounts_General,t1.AmmountCredit_General,t1.AmountClaimed_General,
			t1.NoOfAccounts_SC,t1.AmmountCredit_SC,t1.AmountClaimed_SC,
			t1.NoOfAccounts_ST,t1.AmmountCredit_ST,t1.AmountClaimed_ST
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXXXII_B AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END




GO
/****** Object:  StoredProcedure [dbo].[USP_AR_CertificateXXXXIII_Consolidation]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

create PROCEDURE [dbo].[USP_AR_CertificateXXXXIII_Consolidation]
@isClosed BIT, @auditType TINYINT,  @RoleTypeId INT, @BranchRegionalId INT, @BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS SMALLINT;
SET @localBranchZonalId=@BranchZonalId;

			SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName,t2.RecordHead,
			t1.General_IS,t1.SC_IS,t1.ST_IS,
			t1.General_CGTMSE,t1.SC_CGTMSE,t1.ST_CGTMSE,t1.Total
			FROM   vw_BranchDetailsWithRegion AS t
			JOIN   AR_CertificateXXXXIII AS t1 ON t.BranchYearID=t1.BranchYearID
			JOIN   AnnexureRecordHeadMaster AS t2 ON t1.HeadID = t2.HeadID
			JOIN   BranchYearDetails AS t3 ON t1.BranchYearID=t3.BranchYearID
			JOIN   BranchMaster AS t4 ON t3.BranchID=t4.BranchID
			WHERE  (t4.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
					AND 
					(t4.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
					AND
					((@isClosed = 1 AND t.IsClosed_Annual = 1) OR (@isClosed = 0))
					AND
					((@auditType = 1 AND t.IsManagerAuditing = 1) OR (@auditType = 0 
					AND 
					(t.IsManagerAuditing = 0 OR t.IsManagerAuditing = NULL)) OR (@auditType = 2)) 
			ORDER BY t1.BranchYearID,t1.HeadID
END




GO
/****** Object:  StoredProcedure [dbo].[USP_AR_PendingStatusBranchList]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [dbo].[USP_AR_PendingStatusBranchList]
@finYear SMALLINT,@isAudited BIT,@BranchRegionalId INT,@BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS INT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS INT;
SET @localBranchZonalId=@BranchZonalId;

SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName
FROM vw_BranchDetailsWithRegion AS t
JOIN BranchMaster AS bm ON t.BranchID=bm.BranchID
JOIN UserProfile AS u ON t.ManagerUserID=u.UserID
WHERE u.IsApplicableForAnnual=1 AND t.FinYear=@finYear AND (t.AuditStartDate_Annual IS NOT NULL) AND ISNULL(t.IsClosed_Annual,0) = 0 AND
((@isAudited=1 AND (t.IsManagerAuditing=0 OR t.IsManagerAuditing IS NULL)) OR (@isAudited=0 AND t.IsManagerAuditing=1)) AND
(bm.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
AND 
(bm.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
AND t.BranchYearID !=1

END

-- exec [USP_AR_PendingStatusBranchList] 2020,0,0,0

GO
/****** Object:  StoredProcedure [dbo].[USP_AR_TotalBranchesList]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [dbo].[USP_AR_TotalBranchesList]
@finYear SMALLINT,@isAudited BIT,@BranchRegionalId INT,@BranchZonalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS INT;
SET @localBranchRegionalId=@BranchRegionalId;

DECLARE @localBranchZonalId AS INT;
SET @localBranchZonalId=@BranchZonalId;

SELECT t.BranchCode,t.BranchName,t.ZonalCode,t.ZonalName,t.RegionCode,t.RegionName
FROM vw_BranchDetailsWithRegion AS t
JOIN BranchMaster AS bm ON t.BranchID=bm.BranchID
JOIN UserProfile AS u ON t.ManagerUserID=u.UserID
WHERE u.IsApplicableForAnnual=1 AND t.FinYear=@finYear AND 
((@isAudited=1 AND (t.IsManagerAuditing=0 OR t.IsManagerAuditing IS NULL)) OR (@isAudited=0 AND t.IsManagerAuditing=1)) AND
(bm.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
AND 
(bm.BranchZonalID = @localBranchZonalId OR @localBranchZonalId=0)
AND t.BranchYearID !=1

END

-- exec [USP_AR_TotalBranchesList] 2020,0,0,0

GO
/****** Object:  StoredProcedure [dbo].[USP_GetOtherUploadFilesByBranchCode]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[USP_GetOtherUploadFilesByBranchCode]
@branchCode varchar(10)
AS

BEGIN

SET FMTONLY OFF;

SELECT t2.BranchYearID,t3.BranchCode,(SELECT BranchCode FROM dbo.BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = t3.BranchRegionalID)) AS ZoneCode,
		t3.RegionCode,
		(SELECT BranchID FROM dbo.BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID =t3.BranchRegionalID)) AS BranchRegionalID,UploadFile  AS FilePath 
FROM   AR_OtherUploads AS t1
JOIN   BranchYearDetails AS t2 ON t1.BranchYearID=t2.BranchYearID
JOIN   BranchMaster AS t3 ON t2.BranchID = t3.BranchID
WHERE  t3.BranchCode = @branchCode AND UploadFile IS NOT NULL

END




GO
/****** Object:  StoredProcedure [dbo].[USP_GetOtherUploadFilesByFileID]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[USP_GetOtherUploadFilesByFileID]
@fileId INT, @BranchRegionalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

SELECT t2.BranchYearID,t3.BranchCode,(SELECT BranchCode FROM dbo.BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = t3.BranchRegionalID)) AS ZoneCode,t3.RegionCode,
		(SELECT BranchID FROM dbo.BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID =t3.BranchRegionalID)) AS BranchRegionalID,UploadFile  AS FilePath 
FROM   AR_OtherUploads AS t1
JOIN   BranchYearDetails AS t2 ON t1.BranchYearID=t2.BranchYearID
JOIN   BranchMaster AS t3 ON t2.BranchID = t3.BranchID
WHERE  (t3.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
	   AND t1.UploadId=@fileId AND UploadFile IS NOT NULL

END





GO
/****** Object:  StoredProcedure [dbo].[USP_GetROUploadFilesByFileID]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create PROCEDURE [dbo].[USP_GetROUploadFilesByFileID]
@fileId INT, @BranchRegionalId INT
AS

BEGIN

SET FMTONLY OFF;

DECLARE @localBranchRegionalId AS SMALLINT;
SET @localBranchRegionalId=@BranchRegionalId;

SELECT t2.BranchYearID,t3.BranchCode,(SELECT BranchCode FROM dbo.BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = t3.BranchRegionalID)) AS ZoneCode,t3.RegionCode,
		(SELECT BranchID FROM dbo.BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = t3.BranchRegionalID)) AS BranchRegionalID,UploadFile  AS FilePath 
FROM   AR_ROUploads AS t1
JOIN   BranchYearDetails AS t2 ON t1.BranchYearID=t2.BranchYearID
JOIN   BranchMaster AS t3 ON t2.BranchID = t3.BranchID
WHERE  (t3.BranchRegionalID = @localBranchRegionalId OR @localBranchRegionalId=0) 
	   AND t1.UploadId=@fileId AND UploadFile IS NOT NULL

END






GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_AnnexureClosure_RO]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

create PROCEDURE [dbo].[USP_LFAR_AnnexureClosure_RO]
@BranchRegionalId int
AS
BEGIN
DECLARE @Count INT
DECLARE @LoopIndex INT
DECLARE @AnnexureDisplayID TINYINT
DECLARE @AnnexureID TINYINT
DECLARE @Query varchar(512)

SET FMTONLY OFF;

CREATE TABLE #TmpTable
        (
		  BranchYearId int,
          ANNEXUREID TINYINT,
          RECORDCOUNT INT,
		  BranchCode varchar(10)
        )
SET @Count = 0
SELECT @Count = COUNT(*) FROM LFAR_AnnexureMaster
	
SET @LoopIndex = 1

WHILE @LoopIndex <= @Count
	BEGIN
		SET @AnnexureDisplayID = @LoopIndex
		SELECT @Query = AnnexureTableName FROM LFAR_AnnexureMaster 
			WHERE DisplayOrder = @AnnexureDisplayID     
		SELECT @AnnexureID = AnnexureID FROM LFAR_AnnexureMaster 
			WHERE DisplayOrder = @AnnexureDisplayID     

		BEGIN TRY

		IF(@AnnexureID=48)
		BEGIN
		--SET @Query ='';
		SET @Query = 'INSERT INTO #TMPTABLE ' +
					'SELECT BranchYearDetails.BranchYearId,' + CAST(@AnnexureID AS VARCHAR(10)) + ', COUNT(LFAR_Annexure46A.BRANCHYEARID),BranchMaster.BranchCode                                                  
						 FROM LFAR_Annexure46A ' + 
						' INNER JOIN BranchYearDetails ON BranchYearDetails.BranchYearId=LFAR_Annexure46A.BranchYearId 
						INNER JOIN BranchMaster ON BranchMaster.BranchId=BranchYearDetails.BranchId  WHERE BranchRegionalID=' + CAST(@BranchRegionalId AS VARCHAR(10))	
							+' GROUP BY BranchYearDetails.BranchYearId,BranchMaster.BranchCode'
		END
		ELSE
				BEGIN
					SET @Query = 'INSERT INTO #TMPTABLE ' +
						'SELECT BranchYearDetails.BranchYearId,' + CAST(@AnnexureID AS VARCHAR(10)) + ', COUNT('+@Query+'.BRANCHYEARID),BranchMaster.BranchCode
						 FROM ' + @Query + 
							' INNER JOIN BranchYearDetails ON BranchYearDetails.BranchYearId='+@Query+'.BranchYearId 
							INNER JOIN BranchMaster ON BranchMaster.BranchId=BranchYearDetails.BranchId  WHERE BranchRegionalID=' + CAST(@BranchRegionalId AS VARCHAR(10))	
							+' GROUP BY BranchYearDetails.BranchYearId,BranchMaster.BranchCode'		
					
				END
				print(@Query)
			EXEC (@Query)
		END TRY
		BEGIN CATCH
		END CATCH
        
		SET @LoopIndex = @LoopIndex + 1
	END
	
	
	SELECT annexDetail.BranchYearID,BranchMaster.BranchCode,annexMast.AnnexureID, annexMast.AnnexureName,annexMast.AnnexureTitle,RECORDCOUNT=( CASE WHEN RECORDCOUNT IS NULL THEN 0 ELSE RECORDCOUNT END ),annexDetail.IsClosureApplied,annexDetail.IsApproved,annexDetail.ClosureAppliedDate,annexDetail.ClosureIssuedDate,
	annexDetail.ZOComments
	FROM ClosureAnnexureDetails annexDetail  
	LEFT JOIN #TMPTABLE on #TMPTABLE.BranchYearId = annexDetail.BranchYearID AND #TMPTABLE.AnnexureID = annexDetail.AnnexureID
	INNER JOIN LFAR_AnnexureMaster annexMast ON annexMast.AnnexureID = annexDetail.AnnexureID
	INNER JOIN BranchYearDetails ON BranchYearDetails.BranchYearID = annexDetail.BranchYearID 
	INNER JOIN BranchMaster ON BranchMaster.BranchID = BranchYearDetails.BranchID 
	WHERE annexDetail.IsClosureApplied=1 AND annexDetail.IsApproved!=1 AND BranchMaster.BranchRegionalID = @BranchRegionalId
	--ORDER BY #TMPTABLE.BranchYearId
	ORDER BY BranchMaster.BranchCode

	select * from #TMPTABLE

	DROP TABLE #TmpTable
END


--USP_LFAR_AnnexureClosure_RO 2

--08143882345



--select * from ClosureAnnexureDetails where IsClosureApplied = 1 and IsApproved != 1




GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_AnnexureClosureFlagsReset_Itemwise]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

create PROCEDURE [dbo].[USP_LFAR_AnnexureClosureFlagsReset_Itemwise]
@BranchYearId INT,
@AnnexureID TINYINT,
@SlNo SMALLINT

AS
BEGIN
 DECLARE @TableName VARCHAR(50)
 DECLARE @Query VARCHAR(512)

 SET FMTONLY OFF;

 SET @TableName = ''
 SELECT @TableName = AnnexureTableName FROM LFAR_AnnexureMaster WHERE AnnexureID=@AnnexureID

	BEGIN

	IF(@SlNo != 0)
	BEGIN

	SET @Query = 'UPDATE ' + @TableName +' SET IsClosureApplied = 0, IsApproved = 0, ClosureAppliedDate = NULL, ClosureIssuedDate = NULL, ZOComments = NULL WHERE BranchYearID = '+ CAST(@BranchYearId AS VARCHAR(5)) + ' AND (SlNo = ' + CAST(@SlNo AS VARCHAR(5)) + ')'

	END
	ELSE
	BEGIN

	SET @Query = 'UPDATE ' + @TableName +' SET IsClosureApplied = 0, IsApproved = 0, ClosureAppliedDate = NULL, ClosureIssuedDate = NULL, ZOComments = NULL WHERE BranchYearID = '+ CAST(@BranchYearId AS VARCHAR(5)) 

	END
	END
	
 print(@Query)
 EXEC (@Query)
END





GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_AnnexureClosureItemwiseReview]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

create PROCEDURE [dbo].[USP_LFAR_AnnexureClosureItemwiseReview]
@BranchYearId INT,
@AnnexureId TINYINT,
@flag bit
AS
BEGIN

DECLARE @localBranchYearId AS SMALLINT;
SET @localBranchYearId=@BranchYearId;

SET FMTONLY OFF;

CREATE TABLE #TmpTable
        (
		  BRANCHYEARID INT,
		  SlNo SMALLINT,
		  ANNEXURENAME VARCHAR(350),
          ANNEXUREID TINYINT,
		  AUDITORREMARKS VARCHAR(2000),
		  BRANCHREMARKS VARCHAR(2000),
		  ISCLOSUREAPPLIED BIT,
		  ISAPPROVED TINYINT,
		  CLOSUREAPPLIEDDATE DATETIME,
		  CLOSUREISSUEDDATE DATETIME,
		  ZOCOMMENTS VARCHAR(2000),
		  COLUMNSDATA VARCHAR(5000)
        )

		IF(@AnnexureId=1 or @AnnexureId=0)
		BEGIN
INSERT INTO #TmpTable
SELECT  a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure1') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure1') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED, a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE, a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Date&&' + ISNULL(CONVERT(VARCHAR(10), a.Date, 103),'') +'¿¿¿'+'Balance&&'+ISNULL(CAST(a.Balance as varchar(20)),'')+'¿¿¿'+'Approved Limit&&'+ISNULL(CAST(a.ApprovedLimited AS VARCHAR(20)),'')) AS COLUMNSDATA FROM LFAR_Annexure1 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!='' 
END
	
IF(@AnnexureId=2 or @AnnexureId=0)
		BEGIN
INSERT INTO #TmpTable
SELECT  a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure2') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure2') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED, a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Name of the Borrower&&' + ISNULL(a.NameOfTheBorrower,'') +'¿¿¿'+'Account Number&&'+ISNULL(a.AccNumber,'')+'¿¿¿'+'Type of Facility&&'+ISNULL(a.Facility,'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.Balance AS VARCHAR(20)),'')+'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Sanctioning Authority&&'+ISNULL(a.SanctioningAuthority,'')+'¿¿¿'+'Amount sanctioned exceeding delegated authority&&'+ISNULL(CAST(a.AmountSanctioned AS VARCHAR(20)),'')+'¿¿¿'+'Date of ratification by higher authority&&'+ISNULL(CONVERT(VARCHAR(10), a.RatificationDate, 103),'')) AS COLUMNSDATA FROM LFAR_Annexure2 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

IF(@AnnexureId=3 or @AnnexureId=0)
		BEGIN
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure3') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure3') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED, a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Name of the Borrower&&' + ISNULL(a.NameOfTheBorrower,'') +'¿¿¿'+'Account Number&&'+ISNULL(a.AccNumber,'')+'¿¿¿'+'Type of Facility&&'+ISNULL(a.Facility,'')+'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Sanctioning Authority&&'+ISNULL(a.SanctioningAuthority,'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.Balance AS VARCHAR(20)),'')+'¿¿¿'+'Nature of irregularity /Documents Not obtained&&'+ISNULL(a.DocumentsNotObtained,'')) AS COLUMNSDATA FROM LFAR_Annexure3 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

IF(@AnnexureId=4 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure4') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure4') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,  a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Name of the Borrower&&' + ISNULL(a.NameOfTheBorrower,'') +'¿¿¿'+'Account Number&&'+ISNULL(a.AccNumber,'')+'¿¿¿'+'Type of Facility&&'+ISNULL(a.Facility,'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.Balance AS VARCHAR(20)),'')+'¿¿¿'+'Limit&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Sanction date&&'+ISNULL(CONVERT(VARCHAR(10), a.SanctionedDate, 103),'')+'¿¿¿'+'Sanction Authority&&'+ISNULL(a.SanctionAuthority,'')) AS COLUMNSDATA FROM LFAR_Annexure4 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END


IF(@AnnexureId=5 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure4A') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure4A') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,  a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Name of the Borrower&&' + ISNULL(a.NameOfTheBorrower,'') +'¿¿¿'+'Account Number&&'+ISNULL(a.AccNumber,'')+'¿¿¿'+'Outstanding balance&&'+ISNULL(CAST(a.OutstandingBalance AS VARCHAR(20)),'')+'¿¿¿'+'Sanction limit&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Sanction Authority&&'+ISNULL(a.SanctionAuthority,'')+'¿¿¿'+'Description of documents&&'+ISNULL(a.DocumentsDescription,'')+'¿¿¿'+'Date of Document&&'+ISNULL(CONVERT(VARCHAR(10), a.DocumentDate, 103),'')) AS COLUMNSDATA FROM LFAR_Annexure4A AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

IF(@AnnexureId=6 or @AnnexureId=0)
 BEGIN 
 INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure5') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure5') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,  a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Name of the Borrower&&' + ISNULL(a.NameOfTheBorrower,'') +'¿¿¿'+'Account Number&&'+ISNULL(a.AccNumber,'')+'¿¿¿'+'Sanction limit&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Sanctioned Authority&&'+ISNULL(a.SanctionAuthority,'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.Balance AS VARCHAR(20)),'')+'¿¿¿'+'Date of Document Matured&&'+ISNULL(CONVERT(VARCHAR(10),a.DocumentMaturedDate, 103),'')+'¿¿¿'+'Particulars of security&&'+ISNULL(a.SecurityParticulars,'')) AS COLUMNSDATA FROM LFAR_Annexure5 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

IF(@AnnexureId=7 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure5A') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure5A') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,  a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Loan Account Number or guarantee issued&&'+ISNULL(a.LoanAccountNo,'')+'¿¿¿'+'Name of the Borrower&&' + ISNULL(a.NameOfBorrower,'') +'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.LimitSanctioned AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.SpecifiedBalance AS VARCHAR(20)),'')+'¿¿¿'+'FD A/c. Number(security or lien&&'+ISNULL(a.FDAccNo,'')) AS COLUMNSDATA FROM LFAR_Annexure5A AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

IF(@AnnexureId=8 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure6') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure6') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,  a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Name of the Borrower&&' + ISNULL(a.NameOfBorrower,'') +'¿¿¿'+'Account Number&&'+ISNULL(a.AccountNo,'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.SpecifiedBalance AS VARCHAR(20)),'')+'¿¿¿'+'Last date of Review&&'+ISNULL(CONVERT(VARCHAR(10), a.LastDateOfReview, 103),'')) AS COLUMNSDATA FROM LFAR_Annexure6 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

IF(@AnnexureId=9 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure7') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure7') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,  a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Name of the Borrower&&' + ISNULL(a.NameOfBorrower,'') +'¿¿¿'+'Account Number&&'+ISNULL(a.AccountNo,'')+'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.LimitSanctioned AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.SpecifiedBalance AS VARCHAR(20)),'')+'¿¿¿'+'Doc. not Submitted&&'+ISNULL(a.DocNotSubmitted,'')+'¿¿¿'+'Date last submitted&&'+ISNULL(CONVERT(VARCHAR(10), a.LastDateSubmitted, 103),'')) AS COLUMNSDATA FROM LFAR_Annexure7 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

IF(@AnnexureId=10 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure8') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure8') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,  a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Name of the Borrower&&' + ISNULL(a.NameOfBorrower,'') +'¿¿¿'+'Account Number&&'+ISNULL(a.AccountNo,'')+'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.LimitSanctioned AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.SpecifiedBalance AS VARCHAR(20)),'')+'¿¿¿'+'Date of last stock audit completed&&'+ISNULL(CONVERT(VARCHAR(10), a.DateOfLastStockAuditCompleted, 103),'')) AS COLUMNSDATA FROM LFAR_Annexure8 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

IF(@AnnexureId=11 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure9') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure9') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,  a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Name of the Borrower&&' + ISNULL(a.NameOfBorrower,'') +'¿¿¿'+'Account Number&&'+ISNULL(a.AccountNo,'')+'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.LimitSanctioned AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.SpecifiedBalance AS VARCHAR(20)),'')+'¿¿¿'+'Date of last stock audit completed&&'+ISNULL(CONVERT(VARCHAR(10), a.LastDateOfAuditedAccSubmitted, 103),'')) AS COLUMNSDATA FROM LFAR_Annexure9 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

IF(@AnnexureId=12 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure10') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure10') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,  a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Name of the Borrower&&' + ISNULL(a.NameOfBorrower,'') +'¿¿¿'+'Account Number&&'+ISNULL(a.AccountNo,'')+'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.LimitSanctioned AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.SpecifiedBalance AS VARCHAR(20)),'')+'¿¿¿'+'Nature of Security&&'+ISNULL(a.NatureOfSecurity,'')+'¿¿¿'+'Last date of inspection/physical verification&&'+ISNULL(CONVERT(VARCHAR(10), a.LastDateOfInspection, 103),'')) AS COLUMNSDATA FROM LFAR_Annexure10 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

IF(@AnnexureId=13 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure11') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure11') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,  a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Name of the Borrower&&' + ISNULL(a.NameOfBorrower,'') +'¿¿¿'+'Account Number&&'+ISNULL(a.AccountNo,'')+'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.LimitSanctioned AS VARCHAR(20)),'') +'¿¿¿'+'Balance Outstanding&&'+ISNULL(CAST(a.BalanceOutstanding AS VARCHAR(20)),'')+'¿¿¿'+'Drawing Power&&'+ISNULL(CAST(a.DrawingPower AS VARCHAR(20)),'')+'¿¿¿'+'Irregularity&&'+ISNULL(a.Irregularity,'')) AS COLUMNSDATA FROM LFAR_Annexure11 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

IF(@AnnexureId=14 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure12') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure12') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,  a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Name of the Borrower&&' + ISNULL(a.NameOfBorrower,'') +'¿¿¿'+'Account Number&&'+ISNULL(a.AccountNo,'')+'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.LimitSanctioned AS VARCHAR(20)),'') +'¿¿¿'+'Balance Outstanding&&'+ISNULL(CAST(a.BalanceOutstanding AS VARCHAR(20)),'')+'¿¿¿'+'Nature of security&&'+ISNULL(a.NatureOfSecurity,'')+'¿¿¿'+'Value&&'+ISNULL(CAST(a.TotalValue AS VARCHAR(20)),'')+'¿¿¿'+'Date last inspection/valuation&&'+ISNULL(CONVERT(VARCHAR(10), a.DateLastInspection, 103),'')) AS COLUMNSDATA FROM LFAR_Annexure12 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

IF(@AnnexureId=15 or @AnnexureId=0)
 BEGIN 
 INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure13') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure13') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,  a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Name of the Borrower&&' + ISNULL(a.NameOfBorrower,'') +'¿¿¿'+'Account Number&&'+ISNULL(a.AccountNo,'')+'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.LimitSanctioned AS VARCHAR(20)),'') +'¿¿¿'+'Balance Outstanding&&'+ISNULL(CAST(a.SpecifiedBalance AS VARCHAR(20)),'')+'¿¿¿'+'Insurance cover available&&'+ISNULL(CAST(a.InsuranceCoverAvailable AS VARCHAR(20)),'')+'¿¿¿'+'Value of security&&'+ISNULL(CAST(a.ValueOfSecurity AS VARCHAR(20)),'')) AS COLUMNSDATA FROM LFAR_Annexure13 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

IF(@AnnexureId=16 or @AnnexureId=0)
 BEGIN 
 INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure14') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure14') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,  a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Name of the Borrower&&' + ISNULL(a.NameOfBorrower,'') +'¿¿¿'+'Loan Account Number&&'+ISNULL(a.LoanAccountNo,'')+'¿¿¿'+'Limit&&'+ISNULL(CAST(a.Limit AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.SpecifiedBalance AS VARCHAR(20)),'')) AS COLUMNSDATA FROM LFAR_Annexure14 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

IF(@AnnexureId=17 or @AnnexureId=0)
 BEGIN 
 INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure15') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure15') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,  a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Account Number&&'+ISNULL(a.AccountNo,'')+'¿¿¿'+'Name of the Borrower&&' + ISNULL(a.NameOfBorrower,'') +'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.SpecifiedBalance AS VARCHAR(20)),'')+'¿¿¿'+'Date of instruction to take legal action&&'+ISNULL(CONVERT(VARCHAR(10), a.Dateoftakelegalaction, 103),'')+'¿¿¿'+'Present Status&&'+ISNULL(a.PresentStatus,'')) AS COLUMNSDATA FROM LFAR_Annexure15 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

IF(@AnnexureId=18 or @AnnexureId=0)
 BEGIN 
 INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure16') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure16') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,  a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Account Number&&'+ISNULL(a.AccountNo,'')+'¿¿¿'+'Name of the Borrower&&' + ISNULL(a.NameOfBorrower,'') +'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.SpecifiedBalance AS VARCHAR(20)),'')+'¿¿¿'+'Date of sanction Rehabilitation programme&&'+ISNULL(CONVERT(VARCHAR(10), a.DateofsanctionRehabilitation, 103),'')+'¿¿¿'+'Present Status&&'+ISNULL(a.PresentStatus,'')) AS COLUMNSDATA FROM LFAR_Annexure16 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

IF(@AnnexureId=19 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure17') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure17') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,  a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Name of the Borrower&&' + ISNULL(a.NameOfBorrower,'') +'¿¿¿'+'Account Number&&'+ISNULL(a.AccountNo,'')+'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.SpecifiedBalance AS VARCHAR(20)),'')
+ '¿¿¿' + 'Security&&'+ISNULL(a.Security,'')+'¿¿¿'+'Value of Security&&'+ISNULL(CAST(a.ValueofSecurity AS VARCHAR(20)),'')+'¿¿¿'+'Last Valuation Report date&&'+ISNULL(CONVERT(VARCHAR(10), a.LastValuationReportdate, 103),'')
) AS COLUMNSDATA FROM LFAR_Annexure17 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

IF(@AnnexureId=20 or @AnnexureId=0)
 BEGIN 
 INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure18') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure18') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,  a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Name of the Borrower&&' + ISNULL(a.NameOfBorrower,'') +'¿¿¿'+'Account Number&&'+ISNULL(a.AccountNo,'')+'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.SpecifiedBalance AS VARCHAR(20)),'')+'¿¿¿'+'Compromise/Settlement amount&&'+ISNULL(CAST(a.CompromiseSettlementamount AS VARCHAR(20)),'')+'¿¿¿'+'Recovery effected&&'+ISNULL(CAST(a.Recoveryeffected AS VARCHAR(20)),'')+'¿¿¿'+'Recovery to be effected&&'+ISNULL(CAST(a.Recoverytobeffected AS VARCHAR(20)),'')) AS COLUMNSDATA FROM LFAR_Annexure18 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

IF(@AnnexureId=21 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure19') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure19') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,  a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Description of Security(Cheque/DD etc.)&&' + ISNULL(a.DescriptionofSecurity,'') +'¿¿¿'+'Serial Number From&&'+ISNULL(CAST(a.SFrom AS VARCHAR(4)),'')+'¿¿¿'+'Serial Number To&&'+ISNULL(CAST(a.STo AS VARCHAR(4)),'')+'¿¿¿'+'Number of Documents&&'+ISNULL(CAST(a.NumberofDocuments AS VARCHAR(4)),'')+'¿¿¿'+'Date of Missing&&'+ISNULL(CONVERT(VARCHAR(10), a.DateofMissing, 103),'')+'¿¿¿'+'Missing Reported on&&'+ISNULL(CONVERT(VARCHAR(10), a.MissingReportedon, 103),'')) AS COLUMNSDATA FROM LFAR_Annexure19 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

IF(@AnnexureId=22 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure20') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure20') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,  a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Year&&' + ISNULL(a.Year,'') +'¿¿¿'+'Particulars of Debit entry&&'+ISNULL(a.ParticularDebitEntry,'')+'¿¿¿'+'Head of Account&&'+ISNULL(a.HeadofAccount,'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.Balance AS VARCHAR(20)),'')) AS COLUMNSDATA FROM LFAR_Annexure20 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

IF(@AnnexureId=23 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure21') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure21') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,  a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Type of Loan&&' + ISNULL(a.Type_of_Loan,'') +'¿¿¿'+'Loan Account Number&&'+ISNULL(a.Loan_Account_no,'')+'¿¿¿'+'Interest calculated by the system&&'+ISNULL(CAST(a.Interest_calculated_by_the_system AS VARCHAR(20)),'')+'¿¿¿'+'Interest calculated by Auditor&&'+ISNULL(CAST(a.Interest_calculated_by_Auditor AS VARCHAR(20)),'')+'¿¿¿'+'Difference&&'+ISNULL(CAST(a.Differences AS VARCHAR(20)),'')) AS COLUMNSDATA FROM LFAR_Annexure21 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

IF(@AnnexureId=24 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure22') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure22') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,  a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Type of Deposit&&' + ISNULL(a.Type_of_Deposit,'') +'¿¿¿'+'Deposit Account Number&&'+ISNULL(a.Deposit_Account_no,'')+'¿¿¿'+'Interest calculated by the system&&'+ISNULL(CAST(a.Interest_calculated_by_the_system AS VARCHAR(20)),'')+'¿¿¿'+'Interest calculated by Auditor&&'+ISNULL(CAST(a.Interest_calculated_by_Auditor AS VARCHAR(20)),'')+'¿¿¿'+'Difference&&'+ISNULL(CAST(a.Differences AS VARCHAR(20)),'')) AS COLUMNSDATA FROM LFAR_Annexure22 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

IF(@AnnexureId=25 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure23') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure23') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,  a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Account Number&&'+ISNULL(a.AccNumber,'')+'¿¿¿'+'Name of the Borrower&&' +ISNULL( a.NameoftheBorrower,'') +'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.Balance AS VARCHAR(20)),'')) AS COLUMNSDATA FROM LFAR_Annexure23 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

IF(@AnnexureId=26 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure24') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure24') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,  a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Account Number&&'+ISNULL(a.AccNumber,'')+'¿¿¿'+'Name of the Borrower&&' + ISNULL(a.NameoftheBorrower ,'')+'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.Balance AS VARCHAR(20)),'')) AS COLUMNSDATA FROM LFAR_Annexure24 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

IF(@AnnexureId=27 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure25') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure25') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,  a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Account Number&&'+ISNULL(a.AccNumber,'')+'¿¿¿'+'Name of the Borrower&&' + ISNULL(a.NameoftheBorrower,'') +'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.Balance AS VARCHAR(20)),'')) AS COLUMNSDATA FROM LFAR_Annexure25 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

IF(@AnnexureId=28 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure26') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure26') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,  a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Account Number&&'+ISNULL(a.AccNumber,'')+'¿¿¿'+'Name of the Borrower&&' + ISNULL(a.NameoftheBorrower,'') +'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.Balance AS VARCHAR(20)),'')) AS COLUMNSDATA FROM LFAR_Annexure26 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

IF(@AnnexureId=29 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure27') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure27') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,  a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Account Number&&'+ISNULL(a.AccNumber,'')+'¿¿¿'+'Name of the Borrower&&' + ISNULL(a.NameoftheBorrower,'') +'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.Balance AS VARCHAR(20)),'')+'¿¿¿'+'Remarks (Last date of inspection or physical verification)&&'+ISNULL(CONVERT(VARCHAR(10), a.Last_date_of_inspection, 103),'')) AS COLUMNSDATA FROM LFAR_Annexure27 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

IF(@AnnexureId=30 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure28') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure28') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,  a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Account Number&&'+ISNULL(a.AccNumber,'')+'¿¿¿'+'Name of the Borrower&&' + ISNULL(a.NameoftheBorrower,'') +'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.Balance AS VARCHAR(20)),'')+'¿¿¿'+'Date of Last Audited Balance sheet Available on record&&'+ISNULL(CONVERT(VARCHAR(10), a.Date_of_Last_Audited, 103),'')) AS COLUMNSDATA FROM LFAR_Annexure28 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

IF(@AnnexureId=31 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure29') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure29') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,  a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Account Number&&'+ISNULL(a.AccNumber,'')+'¿¿¿'+'Name of the Borrower&&' + ISNULL(a.NameoftheBorrower,'') +'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.Balance AS VARCHAR(20)),'')+'¿¿¿'+'Remarks Present status of joint documentation&&'+ISNULL(a.status_of_joint_doc,'')) AS COLUMNSDATA FROM LFAR_Annexure29 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

IF(@AnnexureId=32 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure30') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure30') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,  a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Account Number&&'+ISNULL(a.AccNumber,'')+'¿¿¿'+'Name of the Borrower&&' + ISNULL(a.NameoftheBorrower,'') +'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.Balance AS VARCHAR(20)),'')+'¿¿¿'+'Remark Last Date of renewal&&'+ISNULL(CONVERT(VARCHAR(10), a.Last_Date_of_renewal, 103),'')) AS COLUMNSDATA FROM LFAR_Annexure30 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

IF(@AnnexureId=33 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure31') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure31') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,  a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Account Number&&'+ISNULL(a.AccountNo,'')+'¿¿¿'+'Name of the Borrower&&' + ISNULL(a.NameOfBorrower,'') +'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.SpecifiedBalance AS VARCHAR(20)),'')+'¿¿¿'+'Latest Date of Regular Review&&'+ISNULL(CONVERT(VARCHAR(10), a.LatestDateofRegularReview, 103),'')) AS COLUMNSDATA FROM LFAR_Annexure31 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

IF(@AnnexureId=34 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure32') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure32') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,  a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Account Number&&'+ISNULL(a.AccountNo,'')+'¿¿¿'+'Name of the Borrower&&' + ISNULL(a.NameOfBorrower,'') +'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.SpecifiedBalance AS VARCHAR(20)),'')+'¿¿¿'+'Remarks Last Date of QIS/HalfYearly Statement&&'+ISNULL(CONVERT(VARCHAR(10), a.LastDateofQIS, 103),'')) AS COLUMNSDATA FROM LFAR_Annexure32 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

IF(@AnnexureId=35 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure33') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure33') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,  a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Account Number&&'+ISNULL(a.AccountNo,'')+'¿¿¿'+'Name of the Borrower&&' + ISNULL(a.NameOfBorrower,'') +'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.SpecifiedBalance AS VARCHAR(20)),'')+'¿¿¿'+'Date of last stock audit&&'+ISNULL(CONVERT(VARCHAR(10), a.DateofLastStockAudit, 103),'')) AS COLUMNSDATA FROM LFAR_Annexure33 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

IF(@AnnexureId=36 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure34') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure34') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,  a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Account Number&&'+ISNULL(a.AccountNo,'')+'¿¿¿'+'Name of the Borrower&&' + ISNULL(a.NameOfBorrower,'') +'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.SpecifiedBalance AS VARCHAR(20)),'')) AS COLUMNSDATA FROM LFAR_Annexure34 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

IF(@AnnexureId=37 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure35') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure35') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,  a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Account Number&&'+ISNULL(a.AccountNo,'')+'¿¿¿'+'Name of the Borrower&&' + ISNULL(a.NameOfBorrower,'') +'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.SpecifiedBalance AS VARCHAR(20)),'')) AS COLUMNSDATA FROM LFAR_Annexure35 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

IF(@AnnexureId=38 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure36') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure36') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,  a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Loan Account Number&&'+ISNULL(a.AccountNo,'')+'¿¿¿'+'Name of the Borrower&&' + ISNULL(a.NameOfBorrower,'') +'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.SpecifiedBalance AS VARCHAR(20)),'')+'¿¿¿'+'Earlier Classification&&'+ISNULL(a.EarlierClassification,'')+'¿¿¿'+'Present Classification&&'+ISNULL(a.PresentClassification,'')) AS COLUMNSDATA FROM LFAR_Annexure36 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

IF(@AnnexureId=41 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure39') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure39') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,  a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Date of invocation&&'+ISNULL(CONVERT(VARCHAR(10), a.DateOfInvocation, 103),'')+'¿¿¿'+'Name of the party&&' + ISNULL(a.NameOfParty,'') +'¿¿¿'+'Name of beneficiary&&'+a.NameOfBeneficiary+'¿¿¿'+'Amount(Lakhs)&&'+CAST(a.Amount AS VARCHAR(20))+'¿¿¿'+'Date of recovery&&'+ISNULL(CONVERT(VARCHAR(10), a.DateofRecovery, 103),'')) AS COLUMNSDATA FROM LFAR_Annexure39 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

IF(@AnnexureId=42 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure40') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure40') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,  a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Date of invocation&&'+ISNULL(CONVERT(VARCHAR(10), a.DateOfInvocation, 103),'')+'¿¿¿'+'Name of the party&&' + ISNULL(a.NameOfParty,'') +'¿¿¿'+'Name of beneficiary&&'+ISNULL(a.NameOfBeneficiary,'')+'¿¿¿'+'Amount(Lakhs)&&'+ISNULL(CAST(a.Amount AS VARCHAR(20)),'')+'¿¿¿'+'Date of recovery&&'+ISNULL(CONVERT(VARCHAR(10), a.DateofRecovery, 103),'')) AS COLUMNSDATA FROM LFAR_Annexure40 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

IF(@AnnexureId=43 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure41') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure41') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,  a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Date of funding&&'+ISNULL(CONVERT(VARCHAR(10), a.DateOfFunding, 103),'')+'¿¿¿'+'Name of the party&&' + ISNULL(a.NameOfParty,'') +'¿¿¿'+'Nature(LC/Co-acceptance,etc.)&&'+ISNULL(a.Nature,'')+'¿¿¿'+'Amount(Lakhs)&&'+ISNULL(CAST(a.Amount AS VARCHAR(20)),'')+'¿¿¿'+'Date of recovery&&'+ISNULL(CONVERT(VARCHAR(10), a.DateofRecovery, 103),'')) AS COLUMNSDATA FROM LFAR_Annexure41 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

IF(@AnnexureId=44 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure42') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure42') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,  a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Head of accounts&&'+ISNULL(a.HeadOfAccount,'')+'¿¿¿'+'Year&&' + ISNULL(CAST(a.Year AS VARCHAR(4)),'') +'¿¿¿'+'Number of items&&'+ISNULL(CAST(a.NumberOfItems AS VARCHAR(4)),'')+'¿¿¿'+'Amount(Lakhs)&&'+ISNULL(CAST(a.Amount AS VARCHAR(20)),'')) AS COLUMNSDATA FROM LFAR_Annexure42 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

IF(@AnnexureId=45 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure43') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure43') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,  a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Head of accounts&&'+ISNULL(a.HeadOfAccount,'')+'¿¿¿'+'Balance (As per general ledger)&&' + ISNULL(CAST(a.AsPerGeneralLadger AS VARCHAR(20)),'')+'¿¿¿'+'Balance (As per subsidiary ledger)&&'+ISNULL(CAST(a.AsPerSubsidiaryLadger AS VARCHAR(20)),'')+'¿¿¿'+'Reconciled up to(specify date of last tallying)&&'+ISNULL(CONVERT(VARCHAR(10), a.ReconciledDate, 103),'')+'¿¿¿'+'Difference(Lakhs)&&'+ISNULL(CAST(a.AmountDifference AS VARCHAR(20)),'')) AS COLUMNSDATA FROM LFAR_Annexure43 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

IF(@AnnexureId=47 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable 
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure45') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure45') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,  a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Name of the Borrower&&'+ISNULL(a.NameofBorrower,'')+'¿¿¿'+'Account Number&&' + ISNULL(a.AccountNumber,'')+'¿¿¿'+'Type of facility&&'+ISNULL(CAST((SELECT ListDescription FROM MasterList WHERE TypeID=27 AND SlNo=a.TypeofFacility) AS VARCHAR(50)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.Balance AS VARCHAR(20)),'')+'¿¿¿'+'Limit&&'+ISNULL(CAST(a.Limit AS VARCHAR(20)),'')+'¿¿¿'+'Asset Classification by Bank&&'+ISNULL(CAST(
Case 
when a.AssetClassificationByBank=1 then 'Standard' 
when a.AssetClassificationByBank=2 then 'Sub standard' 
when a.AssetClassificationByBank=3 then 'D1'
when a.AssetClassificationByBank=4 then 'D2'
when a.AssetClassificationByBank=5 then 'D3'
when a.AssetClassificationByBank=6 then 'Loss'
end
AS VARCHAR(50)),'')+'¿¿¿'+'Asset Classification by Auditor&&'+ISNULL(CAST(
Case 
when a.AssetClassificationByAuditor=1 then 'Standard' 
when a.AssetClassificationByAuditor=2 then 'Sub standard' 
when a.AssetClassificationByAuditor=3 then 'D1'
when a.AssetClassificationByAuditor=4 then 'D2'
when a.AssetClassificationByAuditor=5 then 'D3'
when a.AssetClassificationByAuditor=6 then 'Loss'
end
 AS VARCHAR(50)),'')) AS COLUMNSDATA FROM LFAR_Annexure45 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0  THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

IF(@AnnexureId=49 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure47') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure47') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,  a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Code No. in C414/C413&&'+ISNULL(a.CodeNumber_Debit,'')+'¿¿¿'+'Particulars&&' + ISNULL(a.Particulars_Debit,'')+'¿¿¿'+'Debit&&'+ISNULL(CAST(a.Debit AS VARCHAR(20)),'')+'¿¿¿'+'Code No. in C414/C413&&'+ISNULL(a.CodeNumber_Credit,'')+'¿¿¿'+'Particulars&&' + ISNULL(a.Particulars_Credit,'')+'¿¿¿'+'Credit&&'+ISNULL(CAST(a.Credit AS VARCHAR(20)),'')) AS COLUMNSDATA FROM LFAR_Annexure47 AS a WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and ((a.IsApproved <> CASE WHEN @flag=0  THEN 1 END) or (a.IsApproved = CASE WHEN @flag!=0 THEN 1 END)) and ISNULL(a.IrregularitySBA,'')!=''
END

END
SELECT * FROM #TmpTable





GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_AnnexureClosureItemwiseReview_RO]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

create PROCEDURE [dbo].[USP_LFAR_AnnexureClosureItemwiseReview_RO]
@BranchRegionalId TINYINT,
@BranchYearID SMALLINT,
@AnnexureId TINYINT,
@fromDate DATE,
@toDate DATE

AS
BEGIN

 DECLARE @LocalfromDate VARCHAR(10) 
 DECLARE @LocaltoDate VARCHAR(23)
 DECLARE @localBranchYearId AS SMALLINT
 SET @localBranchYearId=@BranchYearID;

SET @LocalfromDate= CASE WHEN (@fromDate='1900-01-01') THEN '' ELSE CONVERT(CHAR(10), @fromDate, 120) END ;
SET @LocaltoDate= CASE WHEN (@toDate='1900-01-01') THEN '' ELSE CONVERT(CHAR(10), @toDate, 120) END ;

SET FMTONLY OFF;

CREATE TABLE #TmpTable
        (
		  BRANCHYEARID INT,
		  BRANCHCODE VARCHAR(10),
		  SlNo SMALLINT,
		  ANNEXURENAME VARCHAR(350),
          ANNEXUREID TINYINT,
		  AUDITORREMARKS VARCHAR(2000),
		  BRANCHREMARKS VARCHAR(2000),
		  ISCLOSUREAPPLIED BIT,
		  ISAPPROVED TINYINT,
		  CLOSUREAPPLIEDDATE DATETIME,
		  CLOSUREISSUEDDATE DATETIME,
		  ZOCOMMENTS VARCHAR(2000),
		  COLUMNSDATA VARCHAR(5000)
        )

IF(@AnnexureId=1 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure1') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure1') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Date&&' + ISNULL(CONVERT(VARCHAR(10), a.Date, 103),'') +'¿¿¿'+'Balance&&'+ISNULL(CAST(a.Balance as varchar(20)),'')+'¿¿¿'+'Approved Limit&&'+ISNULL(CAST(a.ApprovedLimited AS VARCHAR(20)),'')) AS COLUMNSDATA FROM LFAR_Annexure1 AS a INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End
 
 IF(@AnnexureId=2 or @AnnexureId=0) 
 BEGIN 
 INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure2') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure2') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Name of the Borrower&&' + ISNULL(a.NameOfTheBorrower,'') +'¿¿¿'+'Account Number&&'+ISNULL(a.AccNumber,'')+'¿¿¿'+'Type of Facility&&'+ISNULL(a.Facility,'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.Balance AS VARCHAR(20)),'')+'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Sanctioning Authority&&'+ISNULL(a.SanctioningAuthority,'')+'¿¿¿'+'Amount sanctioned exceeding delegated authority&&'+ISNULL(CAST(a.AmountSanctioned AS VARCHAR(20)),'')+'¿¿¿'+'Date of ratification by higher authority&&'+ISNULL(CONVERT(VARCHAR(10), a.RatificationDate, 103),'')) AS COLUMNSDATA FROM LFAR_Annexure2 AS a INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End

IF(@AnnexureId=3 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure3') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure3') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Name of the Borrower&&' + ISNULL(a.NameOfTheBorrower,'') +'¿¿¿'+'Account Number&&'+ISNULL(a.AccNumber,'')+'¿¿¿'+'Type of Facility&&'+ISNULL(a.Facility,'')+'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Sanctioning Authority&&'+ISNULL(a.SanctioningAuthority,'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.Balance AS VARCHAR(20)),'')+'¿¿¿'+'Nature of irregularity /Documents Not obtained&&'+ISNULL(a.DocumentsNotObtained,'')) AS COLUMNSDATA FROM LFAR_Annexure3 AS a INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End

IF(@AnnexureId=4 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure4') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure4') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Name of the Borrower&&' + ISNULL(a.NameOfTheBorrower,'') +'¿¿¿'+'Account Number&&'+ISNULL(a.AccNumber,'')+'¿¿¿'+'Type of Facility&&'+ISNULL(a.Facility,'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.Balance AS VARCHAR(20)),'')+'¿¿¿'+'Limit&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Sanction date&&'+ISNULL(CONVERT(VARCHAR(10), a.SanctionedDate, 103),'')+'¿¿¿'+'Sanction Authority&&'+ISNULL(a.SanctionAuthority,'')) AS COLUMNSDATA FROM LFAR_Annexure4 AS a INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1)
and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End

IF(@AnnexureId=5 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure4A') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure4A') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Name of the Borrower&&' + ISNULL(a.NameOfTheBorrower,'') +'¿¿¿'+'Account Number&&'+ISNULL(a.AccNumber,'')+'¿¿¿'+'Outstanding balance&&'+ISNULL(CAST(a.OutstandingBalance AS VARCHAR(20)),'')+'¿¿¿'+'Sanction limit&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Sanction Authority&&'+ISNULL(a.SanctionAuthority,'')+'¿¿¿'+'Description of documents&&'+ISNULL(a.DocumentsDescription,'')+'¿¿¿'+'Date of Document&&'+ISNULL(CONVERT(VARCHAR(10), a.DocumentDate, 103),'')) AS COLUMNSDATA FROM LFAR_Annexure4A AS a INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End

IF(@AnnexureId=6 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure5') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure5') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Name of the Borrower&&' + ISNULL(a.NameOfTheBorrower,'') +'¿¿¿'+'Account Number&&'+ISNULL(a.AccNumber,'')+'¿¿¿'+'Sanction limit&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Sanctioned Authority&&'+ISNULL(a.SanctionAuthority,'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.Balance AS VARCHAR(20)),'')+'¿¿¿'+'Date of Document Matured&&'+ISNULL(CONVERT(VARCHAR(10), a.DocumentMaturedDate, 103),'')+'¿¿¿'+'Particulars of security&&'+ISNULL(a.SecurityParticulars,'')) AS COLUMNSDATA FROM LFAR_Annexure5 AS a INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End

IF(@AnnexureId=7 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure5A') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure5A') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Loan Account Number or guarantee issued&&'+ISNULL(a.LoanAccountNo,'')+'¿¿¿'+'Name of the Borrower&&' + ISNULL(a.NameOfBorrower,'') +'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.LimitSanctioned AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.SpecifiedBalance AS VARCHAR(20)),'')+'¿¿¿'+'FD A/c. Number(security or lien&&'+ISNULL(a.FDAccNo,'')) AS COLUMNSDATA FROM LFAR_Annexure5A AS a INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End

IF(@AnnexureId=8 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure6') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure6') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Name of the Borrower&&' + ISNULL(a.NameOfBorrower,'') +'¿¿¿'+'Account Number&&'+ISNULL(a.AccountNo,'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.SpecifiedBalance AS VARCHAR(20)),'')+'¿¿¿'+'Last date of Review&&'+ISNULL(CONVERT(VARCHAR(10), a.LastDateOfReview, 103),'')) AS COLUMNSDATA FROM LFAR_Annexure6 AS a INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End

IF(@AnnexureId=9 or @AnnexureId=0)
 BEGIN 
 INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure7') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure7') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Name of the Borrower&&' + ISNULL(a.NameOfBorrower,'') +'¿¿¿'+'Account Number&&'+ISNULL(a.AccountNo,'')+'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.LimitSanctioned AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.SpecifiedBalance AS VARCHAR(20)),'')+'¿¿¿'+'Doc. not Submitted&&'+ISNULL(a.DocNotSubmitted,'')+'¿¿¿'+'Date last submitted&&'+ISNULL(CONVERT(VARCHAR(10), a.LastDateSubmitted, 103),'')) AS COLUMNSDATA FROM LFAR_Annexure7 AS a INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End

IF(@AnnexureId=10 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure8') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure8') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Name of the Borrower&&' + ISNULL(a.NameOfBorrower,'') +'¿¿¿'+'Account Number&&'+ISNULL(a.AccountNo,'')+'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.LimitSanctioned AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.SpecifiedBalance AS VARCHAR(20)),'')+'¿¿¿'+'Date of last stock audit completed&&'+ISNULL(CONVERT(VARCHAR(10), a.DateOfLastStockAuditCompleted, 103),'')) AS COLUMNSDATA FROM LFAR_Annexure8 AS a INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End

IF(@AnnexureId=11 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure9') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure9') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Name of the Borrower&&' + ISNULL(a.NameOfBorrower,'') +'¿¿¿'+'Account Number&&'+ISNULL(a.AccountNo,'')+'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.LimitSanctioned AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.SpecifiedBalance AS VARCHAR(20)),'')+'¿¿¿'+'Date of last stock audit completed&&'+ISNULL(CONVERT(VARCHAR(10), a.LastDateOfAuditedAccSubmitted, 103),'')) AS COLUMNSDATA FROM LFAR_Annexure9 AS a INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End

IF(@AnnexureId=12 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure10') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure10') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Name of the Borrower&&' + ISNULL(a.NameOfBorrower,'') +'¿¿¿'+'Account Number&&'+ISNULL(a.AccountNo,'')+'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.LimitSanctioned AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.SpecifiedBalance AS VARCHAR(20)),'')+'¿¿¿'+'Nature of Security&&'+ISNULL(a.NatureOfSecurity,'')+'¿¿¿'+'Last date of inspection/physical verification&&'+ISNULL(CONVERT(VARCHAR(10), a.LastDateOfInspection, 103),'')) AS COLUMNSDATA FROM LFAR_Annexure10 AS a INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End

IF(@AnnexureId=13 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure11') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure11') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Name of the Borrower&&' + ISNULL(a.NameOfBorrower,'') +'¿¿¿'+'Account Number&&'+ISNULL(a.AccountNo,'')+'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.LimitSanctioned AS VARCHAR(20)),'') +'¿¿¿'+'Balance Outstanding&&'+ISNULL(CAST(a.BalanceOutstanding AS VARCHAR(20)),'')+'¿¿¿'+'Drawing Power&&'+ISNULL(CAST(a.DrawingPower AS VARCHAR(20)),'')+'¿¿¿'+'Irregularity&&'+ISNULL(a.Irregularity,'')) AS COLUMNSDATA FROM LFAR_Annexure11 AS a INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End

IF(@AnnexureId=14 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure12') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure12') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Name of the Borrower&&' + ISNULL(a.NameOfBorrower,'') +'¿¿¿'+'Account Number&&'+ISNULL(a.AccountNo,'')+'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.LimitSanctioned AS VARCHAR(20)),'') +'¿¿¿'+'Balance Outstanding&&'+ISNULL(CAST(a.BalanceOutstanding AS VARCHAR(20)),'')+'¿¿¿'+'Nature of security&&'+ISNULL(a.NatureOfSecurity,'')+'¿¿¿'+'Value&&'+ISNULL(CAST(a.TotalValue AS VARCHAR(20)),'')+'¿¿¿'+'Date last inspection/valuation&&'+ISNULL(CONVERT(VARCHAR(10), a.DateLastInspection, 103),'')) AS COLUMNSDATA FROM LFAR_Annexure12 AS a INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End

IF(@AnnexureId=15 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure13') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure13') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Name of the Borrower&&' + ISNULL(a.NameOfBorrower,'') +'¿¿¿'+'Account Number&&'+ISNULL(a.AccountNo,'')+'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.LimitSanctioned AS VARCHAR(20)),'') +'¿¿¿'+'Balance Outstanding&&'+ISNULL(CAST(a.SpecifiedBalance AS VARCHAR(20)),'')+'¿¿¿'+'Insurance cover available&&'+ISNULL(CAST(a.InsuranceCoverAvailable AS VARCHAR(20)),'')+'¿¿¿'+'Value of security&&'+ISNULL(CAST(a.ValueOfSecurity AS VARCHAR(20)),'')) AS COLUMNSDATA FROM LFAR_Annexure13 AS a INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End

IF(@AnnexureId=16 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure14') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure14') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Name of the Borrower&&' + ISNULL(a.NameOfBorrower,'') +'¿¿¿'+'Loan Account Number&&'+ISNULL(a.LoanAccountNo,'')+'¿¿¿'+'Limit&&'+ISNULL(CAST(a.Limit AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.SpecifiedBalance AS VARCHAR(20)),'')) AS COLUMNSDATA FROM LFAR_Annexure14 AS a INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End

IF(@AnnexureId=17 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure15') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure15') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Account Number&&'+ISNULL(a.AccountNo,'')+'¿¿¿'+'Name of the Borrower&&' + ISNULL(a.NameOfBorrower,'') +'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.SpecifiedBalance AS VARCHAR(20)),'')+'¿¿¿'+'Date of instruction to take legal action&&'+ISNULL(CONVERT(VARCHAR(10), a.Dateoftakelegalaction, 103),'')+'¿¿¿'+'Present Status&&'+ISNULL(a.PresentStatus,'')) AS COLUMNSDATA FROM LFAR_Annexure15 AS a INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End

IF(@AnnexureId=18 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure16') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure16') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Account Number&&'+ISNULL(a.AccountNo,'')+'¿¿¿'+'Name of the Borrower&&' + ISNULL(a.NameOfBorrower,'') +'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.SpecifiedBalance AS VARCHAR(20)),'')+'¿¿¿'+'Date of sanction Rehabilitation programme&&'+ISNULL(CONVERT(VARCHAR(10), a.DateofsanctionRehabilitation, 103),'')+'¿¿¿'+'Present Status&&'+ISNULL(a.PresentStatus,'')) AS COLUMNSDATA FROM LFAR_Annexure16 AS a INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End

IF(@AnnexureId=19 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure17') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure17') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Name of the Borrower&&' + ISNULL(a.NameOfBorrower,'') +'¿¿¿'+'Account Number&&'+ISNULL(a.AccountNo,'')+'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.SpecifiedBalance AS VARCHAR(20)),'')+'¿¿¿'+'Security&&'+ISNULL(a.Security,'')+'¿¿¿'+'Value of Security&&'+ISNULL(CAST(a.ValueofSecurity AS VARCHAR(20)),'')
+'¿¿¿'+'Last Valuation Report date&&'+ISNULL(CONVERT(VARCHAR(10), a.LastValuationReportdate, 103),'')
) AS COLUMNSDATA FROM LFAR_Annexure17 AS a INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End

IF(@AnnexureId=20 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure18') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure18') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Name of the Borrower&&' + ISNULL(a.NameOfBorrower,'') +'¿¿¿'+'Account Number&&'+ISNULL(a.AccountNo,'')+'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.SpecifiedBalance AS VARCHAR(20)),'')+'¿¿¿'+'Compromise/Settlement amount&&'+ISNULL(CAST(a.CompromiseSettlementamount AS VARCHAR(20)),'')+'¿¿¿'+'Recovery effected&&'+ISNULL(CAST(a.Recoveryeffected AS VARCHAR(20)),'')+'¿¿¿'+'Recovery to be effected&&'+ISNULL(CAST(a.Recoverytobeffected AS VARCHAR(20)),'')) AS COLUMNSDATA FROM LFAR_Annexure18 AS a INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End

IF(@AnnexureId=21 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure19') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure19') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Description of Security(Cheque/DD etc.)&&' + ISNULL(a.DescriptionofSecurity,'') +'¿¿¿'+'Serial Number From&&'+ISNULL(CAST(a.SFrom AS VARCHAR(4)),'')+'¿¿¿'+'Serial Number To&&'+ISNULL(CAST(a.STo AS VARCHAR(4)),'')+'¿¿¿'+'Number of Documents&&'+ISNULL(CAST(a.NumberofDocuments AS VARCHAR(4)),'')+'¿¿¿'+'Date of Missing&&'+ISNULL(CONVERT(VARCHAR(10), a.DateofMissing, 103),'')+'¿¿¿'+'Missing Reported on&&'+ISNULL(CONVERT(VARCHAR(10), a.MissingReportedon, 103),'')) AS COLUMNSDATA FROM LFAR_Annexure19 AS a INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End

IF(@AnnexureId=22 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure20') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure20') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Year&&' + ISNULL(a.Year,'') +'¿¿¿'+'Particulars of Debit entry&&'+ISNULL(a.ParticularDebitEntry,'')+'¿¿¿'+'Head of Account&&'+ISNULL(a.HeadofAccount,'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.Balance AS VARCHAR(20)),'')) AS COLUMNSDATA FROM LFAR_Annexure20 AS a INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End

IF(@AnnexureId=23 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure21') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure21') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Type of Loan&&' + ISNULL(a.Type_of_Loan,'') +'¿¿¿'+'Loan Account Number&&'+ISNULL(a.Loan_Account_no,'')+'¿¿¿'+'Interest calculated by the system&&'+ISNULL(CAST(a.Interest_calculated_by_the_system AS VARCHAR(20)),'')+'¿¿¿'+'Interest calculated by Auditor&&'+ISNULL(CAST(a.Interest_calculated_by_Auditor AS VARCHAR(20)),'')+'¿¿¿'+'Difference&&'+ISNULL(CAST(a.Differences AS VARCHAR(20)),'')) AS COLUMNSDATA FROM LFAR_Annexure21 AS a INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End

IF(@AnnexureId=24 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure22') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure22') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Type of Deposit&&' + ISNULL(a.Type_of_Deposit,'') +'¿¿¿'+'Deposit Account Number&&'+ISNULL(a.Deposit_Account_no,'')+'¿¿¿'+'Interest calculated by the system&&'+ISNULL(CAST(a.Interest_calculated_by_the_system AS VARCHAR(20)),'')+'¿¿¿'+'Interest calculated by Auditor&&'+ISNULL(CAST(a.Interest_calculated_by_Auditor AS VARCHAR(20)),'')+'¿¿¿'+'Difference&&'+ISNULL(CAST(a.Differences AS VARCHAR(20)),'')) AS COLUMNSDATA FROM LFAR_Annexure22 AS a INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End

IF(@AnnexureId=25 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure23') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure23') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Account Number&&'+ISNULL(a.AccNumber,'')+'¿¿¿'+'Name of the Borrower&&' +ISNULL( a.NameoftheBorrower,'') +'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.Balance AS VARCHAR(20)),'')) AS COLUMNSDATA FROM LFAR_Annexure23 AS a INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End

IF(@AnnexureId=26 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure24') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure24') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Account Number&&'+ISNULL(a.AccNumber,'')+'¿¿¿'+'Name of the Borrower&&' + ISNULL(a.NameoftheBorrower ,'')+'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.Balance AS VARCHAR(20)),'')) AS COLUMNSDATA FROM LFAR_Annexure24 AS a INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End

IF(@AnnexureId=27 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure25') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure25') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Account Number&&'+ISNULL(a.AccNumber,'')+'¿¿¿'+'Name of the Borrower&&' + ISNULL(a.NameoftheBorrower,'') +'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.Balance AS VARCHAR(20)),'')) AS COLUMNSDATA FROM LFAR_Annexure25 AS a INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End

IF(@AnnexureId=28 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure26') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure26') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Account Number&&'+ISNULL(a.AccNumber,'')+'¿¿¿'+'Name of the Borrower&&' + ISNULL(a.NameoftheBorrower,'') +'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.Balance AS VARCHAR(20)),'')) AS COLUMNSDATA FROM LFAR_Annexure26 AS a INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End

IF(@AnnexureId=29 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure27') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure27') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Account Number&&'+ISNULL(a.AccNumber,'')+'¿¿¿'+'Name of the Borrower&&' + ISNULL(a.NameoftheBorrower,'') +'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.Balance AS VARCHAR(20)),'')+'¿¿¿'+'Remarks (Last date of inspection or physical verification)&&'+ISNULL(CONVERT(VARCHAR(10), a.Last_date_of_inspection, 103),'')) AS COLUMNSDATA FROM LFAR_Annexure27 AS a INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End

IF(@AnnexureId=30 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure28') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure28') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Account Number&&'+ISNULL(a.AccNumber,'')+'¿¿¿'+'Name of the Borrower&&' + ISNULL(a.NameoftheBorrower,'') +'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.Balance AS VARCHAR(20)),'')+'¿¿¿'+'Date of Last Audited Balance sheet Available on record&&'+ISNULL(CONVERT(VARCHAR(10), a.Date_of_Last_Audited, 103),'')) AS COLUMNSDATA FROM LFAR_Annexure28 AS a INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End

IF(@AnnexureId=31 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure29') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure29') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Account Number&&'+ISNULL(a.AccNumber,'')+'¿¿¿'+'Name of the Borrower&&' + ISNULL(a.NameoftheBorrower,'') +'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.Balance AS VARCHAR(20)),'')+'¿¿¿'+'Remarks Present status of joint documentation&&'+ISNULL(a.status_of_joint_doc,'')) AS COLUMNSDATA FROM LFAR_Annexure29 AS a INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End

IF(@AnnexureId=32 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure30') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure30') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Account Number&&'+ISNULL(a.AccNumber,'')+'¿¿¿'+'Name of the Borrower&&' + ISNULL(a.NameoftheBorrower,'') +'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.Balance AS VARCHAR(20)),'')+'¿¿¿'+'Remark Last Date of renewal&&'+ISNULL(CONVERT(VARCHAR(10), a.Last_Date_of_renewal, 103),'')) AS COLUMNSDATA FROM LFAR_Annexure30 AS a
INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End

IF(@AnnexureId=33 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure31') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure31') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Account Number&&'+ISNULL(a.AccountNo,'')+'¿¿¿'+'Name of the Borrower&&' + ISNULL(a.NameOfBorrower,'') +'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.SpecifiedBalance AS VARCHAR(20)),'')+'¿¿¿'+'Latest Date of Regular Review&&'+ISNULL(CONVERT(VARCHAR(10), a.LatestDateofRegularReview, 103),'')) AS COLUMNSDATA FROM LFAR_Annexure31 AS a INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End

IF(@AnnexureId=34 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure32') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure32') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Account Number&&'+ISNULL(a.AccountNo,'')+'¿¿¿'+'Name of the Borrower&&' + ISNULL(a.NameOfBorrower,'') +'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.SpecifiedBalance AS VARCHAR(20)),'')+'¿¿¿'+'Remarks Last Date of QIS/HalfYearly Statement&&'+ISNULL(CONVERT(VARCHAR(10), a.LastDateofQIS, 103),'')) AS COLUMNSDATA FROM LFAR_Annexure32 AS a INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End

IF(@AnnexureId=35 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure33') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure33') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Account Number&&'+ISNULL(a.AccountNo,'')+'¿¿¿'+'Name of the Borrower&&' + ISNULL(a.NameOfBorrower,'') +'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.SpecifiedBalance AS VARCHAR(20)),'')+'¿¿¿'+'Date of last stock audit&&'+ISNULL(CONVERT(VARCHAR(10), a.DateofLastStockAudit, 103),'')) AS COLUMNSDATA FROM LFAR_Annexure33 AS a
INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End

IF(@AnnexureId=36 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure34') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure34') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Account Number&&'+ISNULL(a.AccountNo,'')+'¿¿¿'+'Name of the Borrower&&' + ISNULL(a.NameOfBorrower,'') +'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.SpecifiedBalance AS VARCHAR(20)),'')) AS COLUMNSDATA FROM LFAR_Annexure34 AS a INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End

IF(@AnnexureId=37 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure35') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure35') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Account Number&&'+ISNULL(a.AccountNo,'')+'¿¿¿'+'Name of the Borrower&&' + ISNULL(a.NameOfBorrower,'') +'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.SpecifiedBalance AS VARCHAR(20)),'')) AS COLUMNSDATA FROM LFAR_Annexure35 AS a INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End

IF(@AnnexureId=38 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure36') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure36') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Loan Account Number&&'+ISNULL(a.AccountNo,'')+'¿¿¿'+'Name of the Borrower&&' + ISNULL(a.NameOfBorrower,'') +'¿¿¿'+'Limit Sanctioned&&'+ISNULL(CAST(a.SanctionedLimit AS VARCHAR(20)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.SpecifiedBalance AS VARCHAR(20)),'')+'¿¿¿'+'Earlier Classification&&'+ISNULL(a.EarlierClassification,'')+'¿¿¿'+'Present Classification&&'+ISNULL(a.PresentClassification,'')) AS COLUMNSDATA FROM LFAR_Annexure36 AS a INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End

IF(@AnnexureId=41 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure39') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure39') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Date of invocation&&'+ISNULL(CONVERT(VARCHAR(10), a.DateOfInvocation, 103),'')+'¿¿¿'+'Name of the party&&' + ISNULL(a.NameOfParty,'') +'¿¿¿'+'Name of beneficiary&&'+a.NameOfBeneficiary+'¿¿¿'+'Amount(Lakhs)&&'+CAST(a.Amount AS VARCHAR(20))+'¿¿¿'+'Date of recovery&&'+ISNULL(CONVERT(VARCHAR(10), a.DateofRecovery, 103),'')) AS COLUMNSDATA FROM LFAR_Annexure39 AS a
 INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
 End
 
IF(@AnnexureId=42 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure40') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure40') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Date of invocation&&'+ISNULL(CONVERT(VARCHAR(10), a.DateOfInvocation, 103),'')+'¿¿¿'+'Name of the party&&' + ISNULL(a.NameOfParty,'') +'¿¿¿'+'Name of beneficiary&&'+ISNULL(a.NameOfBeneficiary,'')+'¿¿¿'+'Amount(Lakhs)&&'+ISNULL(CAST(a.Amount AS VARCHAR(20)),'')+'¿¿¿'+'Date of recovery&&'+ISNULL(CONVERT(VARCHAR(10), a.DateofRecovery, 103),'')) AS COLUMNSDATA FROM LFAR_Annexure40 AS a
INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End

IF(@AnnexureId=43 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure41') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure41') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Date of funding&&'+ISNULL(CONVERT(VARCHAR(10), a.DateOfFunding, 103),'')+'¿¿¿'+'Name of the party&&' + ISNULL(a.NameOfParty,'') +'¿¿¿'+'Nature(LC/Co-acceptance,etc.)&&'+ISNULL(a.Nature,'')+'¿¿¿'+'Amount(Lakhs)&&'+ISNULL(CAST(a.Amount AS VARCHAR(20)),'')+'¿¿¿'+'Date of recovery&&'+ISNULL(CONVERT(VARCHAR(10), a.DateofRecovery, 103),'')) AS COLUMNSDATA FROM LFAR_Annexure41 AS a
INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End

IF(@AnnexureId=44 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure42') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure42') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Head of accounts&&'+ISNULL(a.HeadOfAccount,'')+'¿¿¿'+'Year&&' + ISNULL(CAST(a.Year AS VARCHAR(4)),'') +'¿¿¿'+'Number of items&&'+ISNULL(CAST(a.NumberOfItems AS VARCHAR(4)),'')+'¿¿¿'+'Amount(Lakhs)&&'+ISNULL(CAST(a.Amount AS VARCHAR(20)),'')) AS COLUMNSDATA FROM LFAR_Annexure42 AS a INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End

IF(@AnnexureId=45 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure43') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure43') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Head of accounts&&'+ISNULL(a.HeadOfAccount,'')+'¿¿¿'+'Balance (As per general ledger)&&' + ISNULL(CAST(a.AsPerGeneralLadger AS VARCHAR(20)),'')+'¿¿¿'+'Balance (As per subsidiary ledger)&&'+ISNULL(CAST(a.AsPerSubsidiaryLadger AS VARCHAR(20)),'')+'¿¿¿'+'Reconciled up to(specify date of last tallying)&&'+ISNULL(CONVERT(VARCHAR(10), a.ReconciledDate, 103),'')+'¿¿¿'+'Difference(Lakhs)&&'+ISNULL(CAST(a.AmountDifference AS VARCHAR(20)),'')) AS COLUMNSDATA FROM LFAR_Annexure43 AS a INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End

IF(@AnnexureId=47 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable 
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure45') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure45') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Name of the Borrower&&'+ISNULL(a.NameofBorrower,'')+'¿¿¿'+'Account Number&&' + ISNULL(a.AccountNumber,'')+'¿¿¿'+'Type of facility&&'+ISNULL(CAST((SELECT ListDescription FROM MasterList WHERE TypeID=27 AND SlNo=a.TypeofFacility) AS VARCHAR(50)),'')+'¿¿¿'+'Balance&&'+ISNULL(CAST(a.Balance AS VARCHAR(20)),'')+'¿¿¿'+'Limit&&'+ISNULL(CAST(a.Limit AS VARCHAR(20)),'')+'¿¿¿'+'Asset Classification by Bank&&'+ISNULL(CAST(
Case 
when a.AssetClassificationByBank=1 then 'Standard' 
when a.AssetClassificationByBank=2 then 'Sub standard' 
when a.AssetClassificationByBank=3 then 'D1'
when a.AssetClassificationByBank=4 then 'D2'
when a.AssetClassificationByBank=5 then 'D3'
when a.AssetClassificationByBank=6 then 'Loss'
end
 AS VARCHAR(50)),'')+'¿¿¿'+'Asset Classification by Auditor&&'+ISNULL(CAST(
Case 
when a.AssetClassificationByAuditor=1 then 'Standard' 
when a.AssetClassificationByAuditor=2 then 'Sub standard' 
when a.AssetClassificationByAuditor=3 then 'D1'
when a.AssetClassificationByAuditor=4 then 'D2'
when a.AssetClassificationByAuditor=5 then 'D3'
when a.AssetClassificationByAuditor=6 then 'Loss'
end
 AS VARCHAR(50)),'')) AS COLUMNSDATA FROM LFAR_Annexure45 AS a INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')
End

IF(@AnnexureId=49 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE,a.SlNo,(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure47') AS ANNEXURENAME,(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure47') AS ANNEXUREID, a.IrregularitySBA AS AUDITORREMARKS, a.ReplyOfBranch AS BRANCHREMARKS, a.IsClosureApplied AS ISCLOSUREAPPLIED, a.IsApproved AS ISAPPROVED ,a.ClosureAppliedDate AS CLOSUREAPPLIEDDATE,a.ClosureIssuedDate AS CLOSUREISSUEDDATE,a.ZOComments AS ZOCOMMENTS,('Code No. in C414/C413&&'+ISNULL(a.CodeNumber_Debit,'')+'¿¿¿'+'Particulars&&' + ISNULL(a.Particulars_Debit,'')+'¿¿¿'+'Debit&&'+ISNULL(CAST(a.Debit AS VARCHAR(20)),'')+'¿¿¿'+'Code No. in C414/C413&&'+ISNULL(a.CodeNumber_Credit,'')+'¿¿¿'+'Particulars&&' + ISNULL(a.Particulars_Credit,'')+'¿¿¿'+'Credit&&'+ISNULL(CAST(a.Credit AS VARCHAR(20)),'')) AS COLUMNSDATA FROM LFAR_Annexure47 AS a INNER JOIN BranchYearDetails AS bd ON a.BranchYearID=bd.BranchYearID INNER JOIN BranchMaster AS bm ON bd.BranchID=bm.BranchID WHERE (a.BranchYearID=@localBranchYearId or @localBranchYearId=0) and bm.BranchRegionalID=@BranchRegionalId and (a.IsClosureApplied=1 and a.IsApproved!=1) and (CAST(a.ClosureAppliedDate AS DATE) >= CAST(@LocalfromDate AS VARCHAR(10)) OR CAST(@LocalfromDate AS VARCHAR(10))='') AND (CAST(a.ClosureAppliedDate AS DATE) <= CAST(@LocaltoDate AS VARCHAR) or CAST(@LocaltoDate  AS VARCHAR)='')

END
End

SELECT * FROM #TmpTable





GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_AnnexureClosureItemwiseUpdate]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

create PROCEDURE [dbo].[USP_LFAR_AnnexureClosureItemwiseUpdate]
@BranchYearId INT,
@AnnexureID TINYINT,
@SlNo SMALLINT,
@IsApplied BIT

AS
BEGIN
 DECLARE @TableName VARCHAR(50)
 DECLARE @Query VARCHAR(512)

 SET FMTONLY OFF;

 SET @TableName = ''
 SELECT @TableName = AnnexureTableName FROM LFAR_AnnexureMaster WHERE AnnexureID=@AnnexureID

  IF(@IsApplied=1)
 BEGIN
	IF(@SlNo != 0)
	BEGIN
	SET @Query = 'UPDATE ' + @TableName +' SET IsClosureApplied=''' + CAST(@IsApplied AS VARCHAR(1)) + ''',ClosureAppliedDate=''' + CAST(GETDATE() AS VARCHAR(25)) + ''' WHERE BranchYearId=' + CAST(@BranchYearId AS VARCHAR(5)) + ' and SlNo=' +CAST(@SlNo AS  VARCHAR(5))	
	END
	ELSE
	BEGIN
	  SET @Query = 'UPDATE ' + @TableName +' SET IsClosureApplied=''' + CAST(@IsApplied AS VARCHAR(1)) +''',ClosureAppliedDate=''' + CAST(GETDATE() AS VARCHAR(25)) + ''',ClosureIssuedDate=''' + CAST(GETDATE() AS VARCHAR(25)) + ''', IsApproved=1 WHERE BranchYearId=' + CAST(@BranchYearId AS VARCHAR(5)) + ' and IrregularitySBA IS NULL'
	END	
 END
 ELSE
 BEGIN
  IF(@SlNo != 0)
	BEGIN
	SET @Query = 'UPDATE ' + @TableName +' SET IsClosureApplied=''' + CAST(@IsApplied AS VARCHAR(1)) + ''', ClosureAppliedDate = NULL  WHERE BranchYearId=' + CAST(@BranchYearId AS VARCHAR(5)) + ' and SlNo=' + CAST(@SlNo AS VARCHAR(5))	
    END
  ELSE
    BEGIN
	SET @Query = 'UPDATE ' + @TableName +' SET IsClosureApplied=''' + CAST(@IsApplied AS VARCHAR(1)) + ''',ClosureAppliedDate = NULL, ClosureIssuedDate = NULL, IsApproved = 0  WHERE BranchYearId=' + CAST(@BranchYearId AS VARCHAR(5))
	END
 END
 print(@Query)
 EXEC (@Query)
END





GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_AnnexureClosureItemwiseUpdate_RO]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-----------------------------------------------------------------------------
create PROCEDURE [dbo].[USP_LFAR_AnnexureClosureItemwiseUpdate_RO]
@BranchYearId INT,
@AnnexureID TINYINT,
@SlNo SMALLINT,
@IsApproved TINYINT,
@ZOComments VARCHAR(2000)

AS
BEGIN
 DECLARE @TableName VARCHAR(50)
 DECLARE @Query VARCHAR(512)

 SET FMTONLY OFF;

 SET @TableName = ''
 SELECT @TableName = AnnexureTableName FROM LFAR_AnnexureMaster WHERE AnnexureID=@AnnexureID
 
 IF(@IsApproved = 1)
 BEGIN
 SET @Query = 'UPDATE ' + @TableName +' SET IsApproved=''' + CAST(@IsApproved AS VARCHAR(1)) + ''',ClosureIssuedDate='''+ CAST(GETDATE() AS VARCHAR(25)) + ''',ZOComments='''+ @ZOComments +'''  WHERE BranchYearId=' + CAST(@BranchYearId AS  VARCHAR(5)) + ' and  SlNo=' + CAST(@SlNo AS  VARCHAR(5))	
 END
 ELSE IF(@IsApproved = 2)
 BEGIN
  SET @Query = 'UPDATE ' + @TableName +' SET IsApproved=''' + CAST(@IsApproved AS VARCHAR(1)) + ''',ClosureIssuedDate='''+ CAST(GETDATE() AS VARCHAR(25)) + ''',ZOComments='''+ @ZOComments +''', IsClosureApplied = 0 WHERE BranchYearId=' + CAST(@BranchYearId AS  VARCHAR(5)) + ' and SlNo=' + CAST(@SlNo AS  VARCHAR(5))	
 END

 print(@Query)

 EXEC (@Query)
END





GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_AnnexureClosureReview]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


create PROCEDURE [dbo].[USP_LFAR_AnnexureClosureReview]
@BranchYearId int,
@flag tinyint,
@userRoleType int
AS
BEGIN
DECLARE @Count INT
DECLARE @LoopIndex INT
DECLARE @AnnexureDisplayID TINYINT
DECLARE @AnnexureID TINYINT
DECLARE @Query varchar(512)

SET FMTONLY OFF;

CREATE TABLE #TmpTable
        (
          ANNEXUREID TINYINT,
          RECORDCOUNT INT
        )
SET @Count = 0
SELECT @Count = COUNT(*) FROM LFAR_AnnexureMaster
	
SET @LoopIndex = 1

WHILE @LoopIndex <= @Count
	BEGIN
		SET @AnnexureDisplayID = @LoopIndex
		SELECT @Query = AnnexureTableName FROM LFAR_AnnexureMaster 
			WHERE DisplayOrder = @AnnexureDisplayID     
		SELECT @AnnexureID = AnnexureID FROM LFAR_AnnexureMaster 
			WHERE DisplayOrder = @AnnexureDisplayID     

		BEGIN TRY

		IF(@AnnexureID=48)
		BEGIN
		SET @Query = 'INSERT INTO #TMPTABLE ' +
						'SELECT ' + CAST(@AnnexureID AS VARCHAR(10)) + ', COUNT(BRANCHYEARID) FROM LFAR_Annexure46A WHERE BRANCHYEARID=' + CAST(@BranchYearId AS VARCHAR(10))
		END
		ELSE
				BEGIN
					SET @Query = 'INSERT INTO #TMPTABLE ' +
						'SELECT ' + CAST(@AnnexureID AS VARCHAR(10)) + ', COUNT(BRANCHYEARID) FROM ' + @Query + 
							'  WHERE BRANCHYEARID=' + CAST(@BranchYearId AS VARCHAR(10))								
				END
				--print(@Query)
			EXEC (@Query)
		END TRY
		BEGIN CATCH
		END CATCH
        
		SET @LoopIndex = @LoopIndex + 1
	END
	if(@userRoleType=7 or @userRoleType=8)
	begin
	if(@flag=1)
	begin 
	SELECT annexMast.AnnexureID, annexMast.AnnexureName,annexMast.AnnexureTitle, annexMast.AnnexureTableName, annexMast.AnnexureColumnHeaders, RECORDCOUNT,annexDetail.IsClosureApplied,annexDetail.IsApproved,annexDetail.ClosureAppliedDate,annexDetail.ClosureIssuedDate,annexDetail.ZOComments
	FROM LFAR_AnnexureMaster annexMast
	INNER JOIN #TMPTABLE ON annexMast.AnnexureID = #TMPTABLE.AnnexureID
	left outer join dbo.ClosureAnnexureDetails annexDetail on #TMPTABLE.AnnexureID=annexDetail.AnnexureID and annexDetail.BranchYearID=@BranchYearId
	where annexDetail.IsClosureApplied=1 and annexDetail.IsApproved!=1
	end
	else if(@flag=2)
	begin
	SELECT annexMast.AnnexureID, annexMast.AnnexureName,annexMast.AnnexureTitle, annexMast.AnnexureTableName, annexMast.AnnexureColumnHeaders, RECORDCOUNT,annexDetail.IsClosureApplied,annexDetail.IsApproved,annexDetail.ClosureAppliedDate,annexDetail.ClosureIssuedDate,annexDetail.ZOComments
	FROM LFAR_AnnexureMaster annexMast
	INNER JOIN #TMPTABLE ON annexMast.AnnexureID = #TMPTABLE.AnnexureID
	left outer join dbo.ClosureAnnexureDetails annexDetail on #TMPTABLE.AnnexureID=annexDetail.AnnexureID and annexDetail.BranchYearID=@BranchYearId
	where annexDetail.IsApproved=1
	end
	else if(@flag=4)
	begin 
		SELECT annexMast.AnnexureID, annexMast.AnnexureName,annexMast.AnnexureTitle, annexMast.AnnexureTableName, annexMast.AnnexureColumnHeaders, RECORDCOUNT,annexDetail.IsClosureApplied,annexDetail.IsApproved,annexDetail.ClosureAppliedDate,annexDetail.ClosureIssuedDate,
	annexDetail.ZOComments
	FROM LFAR_AnnexureMaster annexMast
	INNER JOIN #TMPTABLE ON annexMast.AnnexureID = #TMPTABLE.AnnexureID
	left outer join dbo.ClosureAnnexureDetails annexDetail on #TMPTABLE.AnnexureID=annexDetail.AnnexureID and annexDetail.BranchYearID=@BranchYearId
	where annexDetail.IsApproved!=1
	end
	else
	begin
	SELECT annexMast.AnnexureID, annexMast.AnnexureName,annexMast.AnnexureTitle, annexMast.AnnexureTableName, annexMast.AnnexureColumnHeaders, RECORDCOUNT,annexDetail.IsClosureApplied,annexDetail.IsApproved,annexDetail.ClosureAppliedDate,annexDetail.ClosureIssuedDate,annexDetail.ZOComments
	FROM LFAR_AnnexureMaster annexMast
	INNER JOIN #TMPTABLE ON annexMast.AnnexureID = #TMPTABLE.AnnexureID
	left outer join dbo.ClosureAnnexureDetails annexDetail on #TMPTABLE.AnnexureID=annexDetail.AnnexureID and annexDetail.BranchYearID=@BranchYearId
	where annexDetail.IsClosureApplied=0
	end
	end

	else
	begin
	if(@flag=1)
	begin 

	SELECT annexMast.AnnexureID, annexMast.AnnexureName,annexMast.AnnexureTitle, annexMast.AnnexureTableName, annexMast.AnnexureColumnHeaders, RECORDCOUNT,annexDetail.IsClosureApplied,annexDetail.IsApproved,annexDetail.ClosureAppliedDate,annexDetail.ClosureIssuedDate,
	annexDetail.ZOComments
	FROM LFAR_AnnexureMaster annexMast
	INNER JOIN #TMPTABLE ON annexMast.AnnexureID = #TMPTABLE.AnnexureID
	left outer join dbo.ClosureAnnexureDetails annexDetail on #TMPTABLE.AnnexureID=annexDetail.AnnexureID and annexDetail.BranchYearID=@BranchYearId
	where annexDetail.IsApproved!=1
	end
	else
	begin
	SELECT annexMast.AnnexureID, annexMast.AnnexureName,annexMast.AnnexureTitle, annexMast.AnnexureTableName, annexMast.AnnexureColumnHeaders, RECORDCOUNT,annexDetail.IsClosureApplied,annexDetail.IsApproved,annexDetail.ClosureAppliedDate,annexDetail.ClosureIssuedDate,annexDetail.ZOComments
	FROM LFAR_AnnexureMaster annexMast
	INNER JOIN #TMPTABLE ON annexMast.AnnexureID = #TMPTABLE.AnnexureID
	left outer join dbo.ClosureAnnexureDetails annexDetail on #TMPTABLE.AnnexureID=annexDetail.AnnexureID and annexDetail.BranchYearID=@BranchYearId
	where annexDetail.IsApproved=1
	end
	end

	DROP TABLE #TmpTable
END






GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_ConsolidateAnnexure001]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_LFAR_ConsolidateAnnexure001] 
	  @FinYear SMALLINT,
	  @BranchFilter SMALLINT = NULL,
	  @FilterComment BIT= NULL,
	  @IsAuditClosed BIT = NULL,
	  @IsRectifcationClosed BIT = NULL,
	  @BranchRegionalId TINYINT = 0 
AS
BEGIN
	DECLARE @HundredCrAdvance int
	DECLARE @NotHundredCrAdvance int
	IF @BranchFilter = 1
	BEGIN
		SET @HundredCrAdvance = 10000
		SET @NotHundredCrAdvance = NULL
	END
	ELSE IF @BranchFilter = 2
	BEGIN
		SET @HundredCrAdvance = NULL
		SET @NotHundredCrAdvance = 10000
	END
	ELSE
	BEGIN
		SET @HundredCrAdvance = NULL
		SET @NotHundredCrAdvance = NULL
	END
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
		
	SET NOCOUNT ON;
	SELECT (SELECT BranchName FROM BranchMaster WHERE BranchTypeID = 3 AND BranchRegionalID = A.BranchRegionalID) AS Region, A.BranchCode AS BIC, A.BranchName,ISNULL(CAST( CAST(LFAR_Main_Annexure001.DateOfInvocation AS DATE) AS varchar),'') as DateOfInvocation, ISNULL(LFAR_Main_Annexure001.PartyName,'') as PartyName,ISNULL(LFAR_Main_Annexure001.BeneficiaryName,'') as BeneficiaryName, ISNULL(CAST(LFAR_Main_Annexure001.Amount AS nvarchar),'') as Amount,ISNULL(CAST( CAST(LFAR_Main_Annexure001.DateOfRecovery AS DATE) AS varchar),'') as DateOfRecovery, LFAR_Main_Annexure001.IrregularitySBA AS AuditorComments, 
		LFAR_Main_Annexure001.ReplyOfBranch AS BranchRectificationComments,LFAR_Main_Annexure001.BranchYearID, SlNo, ('Party - '+ ISNULL(LFAR_Main_Annexure001.PartyName,'') 
			+ '@@@Beneficiary - '+ ISNULL(LFAR_Main_Annexure001.BeneficiaryName,'') 
			+ '@@@Invocation Date - ' +ISNULL(CAST( CAST(LFAR_Main_Annexure001.DateOfInvocation AS DATE) AS varchar),'')
			+ '@@@Invoked Amount - '+ISNULL(CAST(LFAR_Main_Annexure001.Amount AS nvarchar),'')
			+ '@@@Recovery Date - '+ISNULL(CAST( CAST(LFAR_Main_Annexure001.DateOfRecovery AS DATE) AS varchar),'')) AS BorrowerDetails
	FROM BranchMaster A 
		INNER JOIN BranchYearDetails ON A.BranchID = BranchYearDetails.BranchID 
		INNER JOIN LFAR_Main_Annexure001 ON BranchYearDetails.BranchYearID = LFAR_Main_Annexure001.BranchYearID 
		LEFT OUTER JOIN ClosureDetails ON BranchYearDetails.BranchYearID = ClosureDetails.BranchYearID
	Where  BranchYearDetails.FinYear = @FinYear 
		 AND  (BranchYearDetails.IsClosed = @IsAuditClosed OR (@IsAuditClosed IS NULL OR @IsAuditClosed = 0))
		 AND  (ClosureDetails.ClosureIssued = @IsRectifcationClosed OR (@IsRectifcationClosed IS NULL OR @IsRectifcationClosed = 0))
		 AND  (BranchYearDetails.AdvancesAmount >= @HundredCrAdvance OR @HundredCrAdvance IS NULL)
		 AND  ((BranchYearDetails.AdvancesAmount < @NotHundredCrAdvance OR BranchYearDetails.AdvancesAmount IS NULL) 
			OR @NotHundredCrAdvance IS NULL)
		 AND  (LFAR_Main_Annexure001.Amount > 0)
		 AND  ((@FilterComment IS NULL OR @FilterComment = 0) OR  LEN(IrregularitySBA) > 15 )
		 AND ((@BranchRegionalId <> 0 AND (A.BranchRegionalID = @BranchRegionalId)) OR
		(@BranchRegionalId = 0 AND (A.BranchTypeID = 3 OR A.BranchTypeID = 4 OR A.BranchTypeID = 2)))
	OPTION (RECOMPILE)
END











GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_ConsolidateAnnexure002]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_LFAR_ConsolidateAnnexure002] 
	  @FinYear SMALLINT,
	  @BranchFilter SMALLINT = NULL,
	  @FilterComment BIT= NULL,
	  @IsAuditClosed BIT = NULL,
	  @IsRectifcationClosed BIT = NULL,
	  @BranchRegionalId TINYINT = 0	 
AS
BEGIN
	DECLARE @HundredCrAdvance int
	DECLARE @NotHundredCrAdvance int
	IF @BranchFilter = 1
	BEGIN
		SET @HundredCrAdvance = 10000
		SET @NotHundredCrAdvance = NULL
	END
	ELSE IF @BranchFilter = 2
	BEGIN
		SET @HundredCrAdvance = NULL
		SET @NotHundredCrAdvance = 10000
	END
	ELSE
	BEGIN
		SET @HundredCrAdvance = NULL
		SET @NotHundredCrAdvance = NULL
	END
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.	
		
	SET NOCOUNT ON;
	SELECT (SELECT BranchName FROM BranchMaster WHERE BranchTypeID = 3 AND BranchRegionalID = A.BranchRegionalID) AS Region,A.BranchCode AS BIC, A.BranchName,ISNULL(CAST( CAST(LFAR_Main_Annexure002.DateOfInvocation AS DATE) AS varchar),'') as DateOfInvocation,ISNULL(LFAR_Main_Annexure002.PartyName,'') as PartyName,ISNULL(LFAR_Main_Annexure002.BeneficiaryName,'') as BeneficiaryName,ISNULL(CAST(LFAR_Main_Annexure002.Amount AS nvarchar),'') as Amount,ISNULL(CAST( CAST(LFAR_Main_Annexure002.DateOfRecovery AS DATE) AS varchar),'') as DateOfRecovery,LFAR_Main_Annexure002.IrregularitySBA AS AuditorComments, 
		LFAR_Main_Annexure002.ReplyOfBranch AS BranchRectificationComments,LFAR_Main_Annexure002.BranchYearID, SlNo,('Party - '+ ISNULL(LFAR_Main_Annexure002.PartyName,'') 
		+ '@@@Beneficiary - '+ ISNULL(LFAR_Main_Annexure002.BeneficiaryName,'') 
		+ '@@@Invocation Date - ' +ISNULL(CAST( CAST(LFAR_Main_Annexure002.DateOfInvocation AS DATE) AS varchar),'')
		+ '@@@Invoked Amount - '+ISNULL(CAST(LFAR_Main_Annexure002.Amount AS nvarchar),'')
		+ '@@@Expiry Date - '+ISNULL(CAST( CAST(LFAR_Main_Annexure002.DateOfRecovery AS DATE) AS varchar),'')) AS BorrowerDetails                                
	FROM  BranchMaster A 
		INNER JOIN BranchYearDetails ON A.BranchID = BranchYearDetails.BranchID 
		INNER JOIN LFAR_Main_Annexure002 ON BranchYearDetails.BranchYearID = LFAR_Main_Annexure002.BranchYearID 
		LEFT OUTER JOIN ClosureDetails ON BranchYearDetails.BranchYearID = ClosureDetails.BranchYearID
	Where  BranchYearDetails.FinYear = @FinYear 
		 AND  (BranchYearDetails.IsClosed = @IsAuditClosed OR (@IsAuditClosed IS NULL OR @IsAuditClosed = 0))
		 AND  (ClosureDetails.ClosureIssued = @IsRectifcationClosed OR (@IsRectifcationClosed IS NULL OR @IsRectifcationClosed = 0))
		 AND  (BranchYearDetails.AdvancesAmount >= @HundredCrAdvance OR @HundredCrAdvance IS NULL)
		 AND  ((BranchYearDetails.AdvancesAmount < @NotHundredCrAdvance OR BranchYearDetails.AdvancesAmount IS NULL) 
			OR @NotHundredCrAdvance IS NULL)
		 AND  (LFAR_Main_Annexure002.Amount > 0)
		 AND  ((@FilterComment IS NULL OR @FilterComment = 0) OR  LEN(IrregularitySBA) > 15 )
		 AND ((@BranchRegionalId <> 0 AND (A.BranchRegionalID = @BranchRegionalId)) OR
		(@BranchRegionalId = 0 AND (A.BranchTypeID = 3 OR A.BranchTypeID = 4 OR A.BranchTypeID =2)))
	OPTION (RECOMPILE)
END













GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_ConsolidateAnnexure003]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_LFAR_ConsolidateAnnexure003] 
	  @FinYear SMALLINT,
	  @BranchFilter SMALLINT = NULL,
	  @FilterComment BIT= NULL,
	  @IsAuditClosed BIT = NULL,
	  @IsRectifcationClosed BIT = NULL,
	  @BranchRegionalId TINYINT = 0
	 
AS
BEGIN
	DECLARE @HundredCrAdvance int
	DECLARE @NotHundredCrAdvance int
	IF @BranchFilter = 1
	BEGIN
		SET @HundredCrAdvance = 10000
		SET @NotHundredCrAdvance = NULL
	END
	ELSE IF @BranchFilter = 2
	BEGIN
		SET @HundredCrAdvance = NULL
		SET @NotHundredCrAdvance = 10000
	END
	ELSE
	BEGIN
		SET @HundredCrAdvance = NULL
		SET @NotHundredCrAdvance = NULL
	END
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.	
		
	SET NOCOUNT ON;
    SELECT (SELECT BranchName FROM BranchMaster WHERE BranchTypeID = 3 AND BranchRegionalID = A.BranchRegionalID) AS Region,A.BranchCode AS BIC, A.BranchName,ISNULL(LFAR_Main_Annexure003.OuststandingType,'') as OuststandingType,ISNULL(CAST( CAST(LFAR_Main_Annexure003.DevolvementDate AS DATE) AS varchar),'') as DevolvementDate,ISNULL(LFAR_Main_Annexure003.PartyName,'') as PartyName,ISNULL(LFAR_Main_Annexure003.BeneficiaryName,'') as BeneficiaryName,ISNULL(CAST(LFAR_Main_Annexure003.Amount AS nvarchar),'') as Amount,ISNULL(CAST( CAST(LFAR_Main_Annexure003.DateOfDebit AS DATE) AS varchar),'') as DateOfDebit,LFAR_Main_Annexure003.IrregularitySBA AS AuditorComments,LFAR_Main_Annexure003.ReplyOfBranch AS BranchRectificationComments,LFAR_Main_Annexure003.BranchYearID, SlNo , ('Ouststanding Type - '+ ISNULL(LFAR_Main_Annexure003.OuststandingType,'')		+ '@@@Devolvement Date - '+ISNULL(CAST( CAST(LFAR_Main_Annexure003.DevolvementDate AS DATE) AS varchar),'')
		+ '@@@Party Name - '+ ISNULL(LFAR_Main_Annexure003.PartyName,'') 
		+ '@@@Beneficiary Name - '+ ISNULL(LFAR_Main_Annexure003.BeneficiaryName,'') 
		+ '@@@Amount - '+ ISNULL(CAST(LFAR_Main_Annexure003.Amount AS nvarchar),'') 
		+ '@@@Date Of Debit - '+ ISNULL(CAST( CAST(LFAR_Main_Annexure003.DateOfDebit AS DATE) AS varchar),''))AS Details                                         
	FROM  BranchMaster A 
		INNER JOIN BranchYearDetails ON A.BranchID = BranchYearDetails.BranchID 
		INNER JOIN LFAR_Main_Annexure003 ON BranchYearDetails.BranchYearID = LFAR_Main_Annexure003.BranchYearID 
		LEFT OUTER JOIN ClosureDetails ON BranchYearDetails.BranchYearID = ClosureDetails.BranchYearID
	Where  BranchYearDetails.FinYear = @FinYear 
		 AND  (BranchYearDetails.IsClosed = @IsAuditClosed OR (@IsAuditClosed IS NULL OR @IsAuditClosed = 0))
		 AND  (ClosureDetails.ClosureIssued = @IsRectifcationClosed OR (@IsRectifcationClosed IS NULL OR @IsRectifcationClosed = 0))
		 AND  (BranchYearDetails.AdvancesAmount >= @HundredCrAdvance OR @HundredCrAdvance IS NULL)
		 AND  ((BranchYearDetails.AdvancesAmount < @NotHundredCrAdvance OR BranchYearDetails.AdvancesAmount IS NULL) 
			OR @NotHundredCrAdvance IS NULL)
		 AND  (LFAR_Main_Annexure003.Amount > 0)
		 AND  ((@FilterComment IS NULL OR @FilterComment = 0) OR  LEN(IrregularitySBA) > 15 )
		 AND ((@BranchRegionalId <> 0 AND (A.BranchRegionalID = @BranchRegionalId)) OR
		(@BranchRegionalId = 0 AND (A.BranchTypeID = 3 OR A.BranchTypeID = 4 OR A.BranchTypeID =2)))
	OPTION (RECOMPILE)
END











GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_ConsolidateAnnexure004]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




CREATE PROCEDURE [dbo].[USP_LFAR_ConsolidateAnnexure004] 
	  @FinYear SMALLINT,
	  @BranchFilter SMALLINT = NULL,
	  @FilterComment BIT= NULL,
	  @IsAuditClosed BIT = NULL,
	  @IsRectifcationClosed BIT = NULL
	 
AS
BEGIN
DECLARE @HundredCrAdvance int
DECLARE @NotHundredCrAdvance int
IF @BranchFilter = 1
BEGIN
SET @HundredCrAdvance = 10000
SET @NotHundredCrAdvance = NULL
END
ELSE IF @BranchFilter = 2
BEGIN
SET @HundredCrAdvance = NULL
SET @NotHundredCrAdvance = 10000
END
ELSE
BEGIN
SET @HundredCrAdvance = NULL
SET @NotHundredCrAdvance = NULL
END
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	
		
	SET NOCOUNT ON;
    SELECT (SELECT BranchName FROM BranchMaster WHERE BranchTypeID = 3 AND BranchRegionalID = A.BranchRegionalID) AS Region,    A.BranchCode AS BIC, A.BranchName, 
[RecordHead]
      ,[TotalCount]
      ,[TotalAmount]
      ,[UptoThreeMonthCount]
      ,[UptoThreeMonthAmount]
      ,[AboveThreeMonthCount]
      ,[AboveThreeMonthAmount]
      ,[AboveSixMonthCount]
      ,[AboveSixMonthAmount]
      ,[AboveoneYearCount]
      ,[AboveoneYearAmount]
      ,[AboveTwoYearCount]
      ,[AboveTwoYearAmount]
      ,[AboveThreeYearCount]
      ,[AboveThreeYearAmount]
      ,[IrregularitySBA] AS AuditorComments
                                          
FROM         BranchMaster A INNER JOIN
                      BranchYearDetails ON A.BranchID = BranchYearDetails.BranchID INNER JOIN
                      LFAR_Main_Annexure004 ON BranchYearDetails.BranchYearID = LFAR_Main_Annexure004.BranchYearID JOIN
					  LFAR_AnnexureRecordHeadMaster ON LFAR_Main_Annexure004.HeadID = LFAR_AnnexureRecordHeadMaster.HeadID LEFT OUTER JOIN
					  ClosureDetails ON BranchYearDetails.BranchYearID = ClosureDetails.BranchYearID

  where  BranchYearDetails.FinYear=@FinYear 
 AND  (BranchYearDetails.IsClosed = @IsAuditClosed OR (@IsAuditClosed IS NULL OR @IsAuditClosed = 0))
 AND  (ClosureDetails.ClosureIssued = @IsRectifcationClosed OR (@IsRectifcationClosed IS NULL OR @IsRectifcationClosed = 0))
 AND  (BranchYearDetails.AdvancesAmount >= @HundredCrAdvance OR @HundredCrAdvance IS NULL)
 AND  (BranchYearDetails.AdvancesAmount < @NotHundredCrAdvance OR @NotHundredCrAdvance IS NULL)
 AND  (LFAR_Main_Annexure004.HeadID <>7 AND   TotalAmount > 0 )
 AND  (@FilterComment IS NULL OR  LEN(IrregularitySBA) > 15 )

	OPTION (RECOMPILE)
END






















GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_ConsolidateAnnexure006]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_LFAR_ConsolidateAnnexure006] 
	  @FinYear SMALLINT,
	  @BranchFilter SMALLINT = NULL,
	  @FilterComment BIT= NULL,
	  @IsAuditClosed BIT = NULL,
	  @IsRectifcationClosed BIT = NULL,
	  @BranchRegionalId TINYINT = 0
	 
AS
BEGIN
	DECLARE @HundredCrAdvance int
	DECLARE @NotHundredCrAdvance int
	IF @BranchFilter = 1
	BEGIN
		SET @HundredCrAdvance = 10000
		SET @NotHundredCrAdvance = NULL
	END
	ELSE IF @BranchFilter = 2
	BEGIN
		SET @HundredCrAdvance = NULL
		SET @NotHundredCrAdvance = 10000
	END
	ELSE
	BEGIN
		SET @HundredCrAdvance = NULL
		SET @NotHundredCrAdvance = NULL
	END
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	
		
	SET NOCOUNT ON;
    SELECT (SELECT BranchName FROM BranchMaster WHERE BranchTypeID = 3 AND BranchRegionalID = A.BranchRegionalID) AS Region,A.BranchCode AS BIC, A.BranchName,ISNULL(LFAR_Main_Annexure006.HeadOfAccount,'') as HeadOfAccount, ISNULL(CAST( CAST(LFAR_Main_Annexure006.LedgerDate AS DATE) AS varchar),'') as LedgerDate, ISNULL(CAST(LFAR_Main_Annexure006.GLBalance AS nvarchar),'') as GLBalance,ISNULL(CAST(LFAR_Main_Annexure006.SubsidiaryBalance AS nvarchar),'') as SubsidiaryBalance,ISNULL(CAST(LFAR_Main_Annexure006.AmountDifference AS nvarchar),'') as AmountDifference,ISNULL(CAST( CAST(LFAR_Main_Annexure006.BalanceDate AS DATE) AS varchar),'') as BalanceDate,
LFAR_Main_Annexure006.IrregularitySBA AS AuditorComments,LFAR_Main_Annexure006.ReplyOfBranch AS BranchRectificationComments,LFAR_Main_Annexure006.BranchYearID, SlNo,('Head of Account - '+ ISNULL(LFAR_Main_Annexure006.HeadOfAccount,'') 
		+ '@@@Ledger Date - '+ ISNULL(CAST( CAST(LFAR_Main_Annexure006.LedgerDate AS DATE) AS varchar),'') 
		+ '@@@GL Balance - '+ ISNULL(CAST(LFAR_Main_Annexure006.GLBalance AS nvarchar),'') 
		+ '@@@SubsidiaryB alance - ' +ISNULL(CAST(LFAR_Main_Annexure006.SubsidiaryBalance AS nvarchar),'')
		+ '@@@Amount Difference - '+ISNULL(CAST(LFAR_Main_Annexure006.AmountDifference AS nvarchar),'')
		+ '@@@Balance Date - '+ISNULL(CAST( CAST(LFAR_Main_Annexure006.BalanceDate AS DATE) AS varchar),'') )AS Details 
	FROM  BranchMaster A 
		INNER JOIN BranchYearDetails ON A.BranchID = BranchYearDetails.BranchID 
		INNER JOIN LFAR_Main_Annexure006 ON BranchYearDetails.BranchYearID = LFAR_Main_Annexure006.BranchYearID 
		LEFT OUTER JOIN ClosureDetails ON BranchYearDetails.BranchYearID = ClosureDetails.BranchYearID
	Where  BranchYearDetails.FinYear = @FinYear 
		 AND  (BranchYearDetails.IsClosed = @IsAuditClosed OR (@IsAuditClosed IS NULL OR @IsAuditClosed = 0))
		 AND  (ClosureDetails.ClosureIssued = @IsRectifcationClosed OR (@IsRectifcationClosed IS NULL OR @IsRectifcationClosed = 0))
		 AND  (BranchYearDetails.AdvancesAmount >= @HundredCrAdvance OR @HundredCrAdvance IS NULL)
		 AND  ((BranchYearDetails.AdvancesAmount < @NotHundredCrAdvance OR BranchYearDetails.AdvancesAmount IS NULL) 
			OR @NotHundredCrAdvance IS NULL)
		 AND  (LFAR_Main_Annexure006.GLBalance > 0 or LFAR_Main_Annexure006.SubsidiaryBalance > 0)
		 AND  ((@FilterComment IS NULL OR @FilterComment = 0) OR  LEN(IrregularitySBA) > 15 )
		 AND ((@BranchRegionalId <> 0 AND (A.BranchRegionalID = @BranchRegionalId)) OR
		(@BranchRegionalId = 0 AND (A.BranchTypeID = 3 OR A.BranchTypeID = 4 OR A.BranchTypeID =2)))
	OPTION (RECOMPILE)
END













GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_ConsolidateAnnexureA]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_LFAR_ConsolidateAnnexureA] 
	  @FinYear SMALLINT,
	  @BranchFilter SMALLINT = NULL,
	  @FilterComment BIT= NULL,
	  @IsAuditClosed BIT = NULL,
	  @IsRectifcationClosed BIT = NULL,
	  @BranchRegionalId TINYINT = 0
	 
AS
	BEGIN
	DECLARE @HundredCrAdvance int
	DECLARE @NotHundredCrAdvance int
	IF @BranchFilter = 1
	BEGIN
		SET @HundredCrAdvance = 10000
		SET @NotHundredCrAdvance = NULL
	END
	ELSE IF @BranchFilter = 2
	BEGIN
		SET @HundredCrAdvance = NULL
		SET @NotHundredCrAdvance = 10000
	END
	ELSE
	BEGIN
		SET @HundredCrAdvance = NULL
		SET @NotHundredCrAdvance = NULL
	END
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
		
	SET NOCOUNT ON;
	SELECT (SELECT BranchName FROM BranchMaster WHERE BranchTypeID = 3 AND BranchRegionalID = A.BranchRegionalID) AS Region,A.BranchCode AS BIC, A.BranchName,ISNULL(LFAR_AnnexureA.AccNumber,'') as AccNumber,ISNULL(LFAR_AnnexureA.Borrower,'') as Borrower,ISNULL(LFAR_AnnexureA.Facility,'') as Facility,ISNULL(CAST(LFAR_AnnexureA.SanctionedLimit AS nvarchar),'') as SanctionedLimit,ISNULL(CAST( CAST(LFAR_AnnexureA.SanctionDate AS DATE) AS varchar),'') as SanctionDate,ISNULL(CAST( LFAR_AnnexureA.BalanceAmount AS nvarchar),'') as BalanceAmount,
LFAR_AnnexureA.IrregularitySBA AS AuditorComments, LFAR_AnnexureA.ReplyOfBranch AS BranchRectificationComments,LFAR_AnnexureA.BranchYearID, SlNo,('A/C.No. '+ ISNULL(LFAR_AnnexureA.AccNumber,'') + ' - '+ ISNULL(LFAR_AnnexureA.Borrower,'') 
			+ '@@@Facility - ' +ISNULL(LFAR_AnnexureA.Facility,'')
			+ '@@@Limit - '+ISNULL(CAST(LFAR_AnnexureA.SanctionedLimit AS nvarchar),'')
			+ '@@@Sanction Date - '+ISNULL(CAST( CAST(LFAR_AnnexureA.SanctionDate AS DATE) AS varchar),'') 
			+ '@@@Balance O/S - '+ISNULL(CAST( LFAR_AnnexureA.BalanceAmount AS nvarchar),'')) AS BorrowerDetails
	FROM   BranchMaster A 
		INNER JOIN BranchYearDetails ON A.BranchID = BranchYearDetails.BranchID 
		INNER JOIN LFAR_AnnexureA ON BranchYearDetails.BranchYearID = LFAR_AnnexureA.BranchYearID 
		LEFT OUTER JOIN ClosureDetails ON BranchYearDetails.BranchYearID = ClosureDetails.BranchYearID
	WHERE BranchYearDetails.FinYear=@FinYear 
		 AND  (BranchYearDetails.IsClosed = @IsAuditClosed OR (@IsAuditClosed IS NULL OR @IsAuditClosed = 0))
		 AND  (ClosureDetails.ClosureIssued = @IsRectifcationClosed OR (@IsRectifcationClosed IS NULL OR @IsRectifcationClosed = 0))
		 AND  (BranchYearDetails.AdvancesAmount >= @HundredCrAdvance OR @HundredCrAdvance IS NULL)
		 AND  (((BranchYearDetails.AdvancesAmount < @NotHundredCrAdvance OR BranchYearDetails.AdvancesAmount IS NULL) 
		--		AND LFAR_AnnexureA.SanctionedLimit > 200)
				 OR @NotHundredCrAdvance IS NULL))
		-- AND  ((LFAR_AnnexureA.SanctionedLimit = 0)OR (LFAR_AnnexureA.SanctionedLimit IS NULL))
		 AND  ((@FilterComment IS NULL OR @FilterComment = 0) OR  LEN(IrregularitySBA) > 15 )
		 AND ((@BranchRegionalId <> 0 AND (A.BranchRegionalID = @BranchRegionalId)) OR
		(@BranchRegionalId = 0 AND (A.BranchTypeID = 3 OR A.BranchTypeID = 4 OR A.BranchTypeID =2)))
	OPTION (RECOMPILE)
END











GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_ConsolidateAnnexureB]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[USP_LFAR_ConsolidateAnnexureB] 
	  @FinYear SMALLINT,
	  @BranchFilter SMALLINT = NULL,
	  @FilterComment BIT= NULL,
	  @IsAuditClosed BIT = NULL,
	  @IsRectifcationClosed BIT = NULL,
	  @BranchRegionalId TINYINT = 0
	 
AS
	BEGIN
	DECLARE @HundredCrAdvance int
	DECLARE @NotHundredCrAdvance int
	IF @BranchFilter = 1
	BEGIN
		SET @HundredCrAdvance = 10000
		SET @NotHundredCrAdvance = NULL
	END
	ELSE IF @BranchFilter = 2
	BEGIN
		SET @HundredCrAdvance = NULL
		SET @NotHundredCrAdvance = 10000
	END
	ELSE
	BEGIN
		SET @HundredCrAdvance = NULL
		SET @NotHundredCrAdvance = NULL
	END
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
		
	SET NOCOUNT ON;
	SELECT (SELECT BranchName FROM BranchMaster WHERE BranchTypeID = 3 AND BranchRegionalID = A.BranchRegionalID) AS Region,A.BranchCode AS BIC, A.BranchName,ISNULL(LFAR_AnnexureB.AccNumber,'') as AccNumber,ISNULL(LFAR_AnnexureB.Borrower,'') as Borrower,ISNULL(LFAR_AnnexureB.Facility,'') as Facility,ISNULL(CAST(LFAR_AnnexureB.SanctionedLimit AS nvarchar),'') as SanctionedLimit,ISNULL(CAST( CAST(LFAR_AnnexureB.SanctionDate AS DATE) AS varchar),'') as SanctionDate,ISNULL(CAST( LFAR_AnnexureB.BalanceAmount AS nvarchar),'') as BalanceAmount,LFAR_AnnexureB.IrregularitySBA AS AuditorComments, LFAR_AnnexureB.ReplyOfBranch AS BranchRectificationComments,LFAR_AnnexureB.BranchYearID, SlNo,('A/C.No. '+ ISNULL(LFAR_AnnexureB.AccNumber,'') + ' - '+ ISNULL(LFAR_AnnexureB.Borrower,'') 
			+ '@@@Facility- ' +ISNULL(LFAR_AnnexureB.Facility,'')
			+ '@@@Limit- '+ISNULL(CAST(LFAR_AnnexureB.SanctionedLimit AS nvarchar),'')
			+ '@@@Sanction Date- '+ISNULL(CAST( CAST(LFAR_AnnexureB.SanctionDate AS DATE) AS varchar),'') 
			+ '@@@Balance O/S- '+ISNULL(CAST( LFAR_AnnexureB.BalanceAmount AS nvarchar),'')) AS BorrowerDetails
	FROM   BranchMaster A 
		INNER JOIN BranchYearDetails ON A.BranchID = BranchYearDetails.BranchID 
		INNER JOIN LFAR_AnnexureB ON BranchYearDetails.BranchYearID = LFAR_AnnexureB.BranchYearID 
		LEFT OUTER JOIN ClosureDetails ON BranchYearDetails.BranchYearID = ClosureDetails.BranchYearID
	WHERE BranchYearDetails.FinYear=@FinYear 
		 AND  (BranchYearDetails.IsClosed = @IsAuditClosed OR (@IsAuditClosed IS NULL OR @IsAuditClosed = 0))
		 AND  (ClosureDetails.ClosureIssued = @IsRectifcationClosed OR (@IsRectifcationClosed IS NULL OR @IsRectifcationClosed = 0))
		 AND  (BranchYearDetails.AdvancesAmount >= @HundredCrAdvance OR @HundredCrAdvance IS NULL)
		 AND  (((BranchYearDetails.AdvancesAmount < @NotHundredCrAdvance OR BranchYearDetails.AdvancesAmount IS NULL) 
			--	AND LFAR_AnnexureB.SanctionedLimit > 200) 
				OR @NotHundredCrAdvance IS NULL))
		-- AND  ((LFAR_AnnexureB.SanctionedLimit = 0) OR (LFAR_AnnexureB.SanctionedLimit IS NULL))
		 AND  ((@FilterComment IS NULL OR @FilterComment = 0) OR  LEN(IrregularitySBA) > 15 )
		 AND ((@BranchRegionalId <> 0 AND (A.BranchRegionalID = @BranchRegionalId)) OR
		(@BranchRegionalId = 0 AND (A.BranchTypeID = 3 OR A.BranchTypeID = 4 OR A.BranchTypeID =2)))
	OPTION (RECOMPILE)
END











GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_ConsolidateAnnexureBGAndLOC]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-------Annex 11 End------------

-------Annex 12 -------------------

CREATE PROCEDURE [dbo].[USP_LFAR_ConsolidateAnnexureBGAndLOC] 
	  @FinYear SMALLINT,
	  @BranchFilter SMALLINT = NULL,
	  @FilterComment BIT= NULL,
	  @IsAuditClosed BIT = NULL,
	  @IsRectifcationClosed BIT = NULL,
	  @BranchRegionalId TINYINT = 0
	 
AS
BEGIN
DECLARE @HundredCrAdvance int
DECLARE @NotHundredCrAdvance int
IF @BranchFilter = 1
BEGIN
SET @HundredCrAdvance = 10000
SET @NotHundredCrAdvance = NULL
END
ELSE IF @BranchFilter = 2
BEGIN
SET @HundredCrAdvance = NULL
SET @NotHundredCrAdvance = 10000
END
ELSE
BEGIN
SET @HundredCrAdvance = NULL
SET @NotHundredCrAdvance = NULL
END
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	
		
	SET NOCOUNT ON;
 SELECT LFAR_AnnexureBankGuaranteeAndLOC.BranchYearID, SlNo, (SELECT BranchName FROM BranchMaster WHERE BranchTypeID = 3 AND BranchRegionalID = A.BranchRegionalID) AS Region,    A.BranchCode AS BIC, A.BranchName,
 
 ISNULL(LFAR_AnnexureBankGuaranteeAndLOC.PartyName,'') as PartyName,ISNULL(LFAR_AnnexureBankGuaranteeAndLOC.BeneficiaryName,'') as BeneficiaryName,ISNULL(LFAR_AnnexureBankGuaranteeAndLOC.NoticeSentStatus,'') as NoticeSentStatus,ISNULL(CAST(LFAR_AnnexureBankGuaranteeAndLOC.Amount AS nvarchar),'') as Amount,ISNULL(CAST( CAST(LFAR_AnnexureBankGuaranteeAndLOC.DateOfExpiry AS DATE) AS varchar),'') as DateOfExpiry

 
 ,('Party- '+ ISNULL(LFAR_AnnexureBankGuaranteeAndLOC.PartyName,'') + ' Beneficiary- '+ ISNULL(LFAR_AnnexureBankGuaranteeAndLOC.BeneficiaryName,'') + ' Notice Status- ' +ISNULL(LFAR_AnnexureBankGuaranteeAndLOC.NoticeSentStatus,'')+' Invoked Amt- '+ISNULL(CAST(LFAR_AnnexureBankGuaranteeAndLOC.Amount AS nvarchar),'')+' Expiry Date- '+ISNULL(CAST( CAST(LFAR_AnnexureBankGuaranteeAndLOC.DateOfExpiry AS DATE) AS varchar),'')) AS BorrowerDetails, 
  LFAR_AnnexureBankGuaranteeAndLOC.IrregularitySBA AS AuditorComments, LFAR_AnnexureBankGuaranteeAndLOC.ReplyOfBranch AS BranchRectificationComments
                                      
FROM         BranchMaster A INNER JOIN
                      BranchYearDetails ON A.BranchID = BranchYearDetails.BranchID INNER JOIN
                      LFAR_AnnexureBankGuaranteeAndLOC ON BranchYearDetails.BranchYearID = LFAR_AnnexureBankGuaranteeAndLOC.BranchYearID LEFT OUTER JOIN
					  ClosureDetails ON BranchYearDetails.BranchYearID = ClosureDetails.BranchYearID

  where  BranchYearDetails.FinYear=@FinYear 
 AND  (BranchYearDetails.IsClosed = @IsAuditClosed OR (@IsAuditClosed IS NULL OR @IsAuditClosed = 0))
 AND  (ClosureDetails.ClosureIssued = @IsRectifcationClosed OR (@IsRectifcationClosed IS NULL OR @IsRectifcationClosed = 0))
 AND  (BranchYearDetails.AdvancesAmount >= @HundredCrAdvance OR @HundredCrAdvance IS NULL)
 AND  ((BranchYearDetails.AdvancesAmount < @NotHundredCrAdvance AND LFAR_AnnexureBankGuaranteeAndLOC.Amount >100)OR @NotHundredCrAdvance IS NULL)
 AND  (LFAR_AnnexureBankGuaranteeAndLOC.Amount > 0)
 AND  (@FilterComment IS NULL OR  LEN(IrregularitySBA) > 15 )
 AND ((@BranchRegionalId <> 0 AND (A.BranchRegionalID = @BranchRegionalId)) OR
(@BranchRegionalId = 0 AND (A.BranchTypeID = 3 OR A.BranchTypeID = 4)))
	OPTION (RECOMPILE)
END












GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_ConsolidateAnnexureC]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_LFAR_ConsolidateAnnexureC] 
	  @FinYear SMALLINT,
	  @BranchFilter SMALLINT = NULL,
	  @FilterComment BIT= NULL,
	  @IsAuditClosed BIT = NULL,
	  @IsRectifcationClosed BIT = NULL,
	  @BranchRegionalId TINYINT = 0
	 
AS
	BEGIN
	DECLARE @HundredCrAdvance int
	DECLARE @NotHundredCrAdvance int
	IF @BranchFilter = 1
	BEGIN
		SET @HundredCrAdvance = 10000
		SET @NotHundredCrAdvance = NULL
	END
	ELSE IF @BranchFilter = 2
	BEGIN
		SET @HundredCrAdvance = NULL
		SET @NotHundredCrAdvance = 10000
	END
	ELSE
	BEGIN
		SET @HundredCrAdvance = NULL
		SET @NotHundredCrAdvance = NULL
	END
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
		
	SET NOCOUNT ON;
	SELECT (SELECT BranchName FROM BranchMaster WHERE BranchTypeID = 3 AND BranchRegionalID = A.BranchRegionalID) AS Region,A.BranchCode AS BIC, A.BranchName,ISNULL(LFAR_AnnexureC.AccNumber,'') as AccNumber,ISNULL(LFAR_AnnexureC.Borrower,'') as Borrower,ISNULL(LFAR_AnnexureC.Facility,'') as Facility,ISNULL(CAST(LFAR_AnnexureC.SanctionedLimit AS nvarchar),'') as SanctionedLimit,ISNULL(CAST( CAST(LFAR_AnnexureC.SanctionDate AS DATE) AS varchar),'') as SanctionDate,ISNULL(CAST( LFAR_AnnexureC.BalanceAmount AS nvarchar),'') as BalanceAmount,
LFAR_AnnexureC.IrregularitySBA AS AuditorComments, LFAR_AnnexureC.ReplyOfBranch AS BranchRectificationComments,LFAR_AnnexureC.BranchYearID, SlNo,('A/C.No. '+ ISNULL(LFAR_AnnexureC.AccNumber,'') + ' - '+ ISNULL(LFAR_AnnexureC.Borrower,'') 
			+ '@@@Facility- ' +ISNULL(LFAR_AnnexureC.Facility,'')
			+ '@@@Limit- '+ISNULL(CAST(LFAR_AnnexureC.SanctionedLimit AS nvarchar),'')
			+ '@@@Sanction Date- '+ISNULL(CAST( CAST(LFAR_AnnexureC.SanctionDate AS DATE) AS varchar),'') 
			+ '@@@Balance O/S- '+ISNULL(CAST( LFAR_AnnexureC.BalanceAmount AS nvarchar),'')) AS BorrowerDetails
	FROM   BranchMaster A 
		INNER JOIN BranchYearDetails ON A.BranchID = BranchYearDetails.BranchID 
		INNER JOIN LFAR_AnnexureC ON BranchYearDetails.BranchYearID = LFAR_AnnexureC.BranchYearID 
		LEFT OUTER JOIN ClosureDetails ON BranchYearDetails.BranchYearID = ClosureDetails.BranchYearID
	WHERE BranchYearDetails.FinYear=@FinYear 
		 AND  (BranchYearDetails.IsClosed = @IsAuditClosed OR (@IsAuditClosed IS NULL OR @IsAuditClosed = 0))
		 AND  (ClosureDetails.ClosureIssued = @IsRectifcationClosed OR (@IsRectifcationClosed IS NULL OR @IsRectifcationClosed = 0))
		 AND  (BranchYearDetails.AdvancesAmount >= @HundredCrAdvance OR @HundredCrAdvance IS NULL)
		 AND  (((BranchYearDetails.AdvancesAmount < @NotHundredCrAdvance OR BranchYearDetails.AdvancesAmount IS NULL) 
			--	AND LFAR_AnnexureC.SanctionedLimit > 200)
				 OR @NotHundredCrAdvance IS NULL))
		-- AND  ((LFAR_AnnexureC.SanctionedLimit = 0)OR (LFAR_AnnexureC.SanctionedLimit IS NULL))
		 AND  ((@FilterComment IS NULL OR @FilterComment = 0) OR  LEN(IrregularitySBA) > 15 )
		 AND ((@BranchRegionalId <> 0 AND (A.BranchRegionalID = @BranchRegionalId)) OR
		(@BranchRegionalId = 0 AND (A.BranchTypeID = 3 OR A.BranchTypeID = 4 OR A.BranchTypeID =2)))
	OPTION (RECOMPILE)
END











GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_ConsolidateAnnexureCHOSB]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [dbo].[USP_LFAR_ConsolidateAnnexureCHOSB] 
	  @FinYear SMALLINT,
	  @BranchFilter SMALLINT = NULL,
	  @FilterComment BIT= NULL,
	  @IsAuditClosed BIT = NULL,
	  @IsRectifcationClosed BIT = NULL
	 
AS
BEGIN
DECLARE @HundredCrAdvance int
DECLARE @NotHundredCrAdvance int
IF @BranchFilter = 1
BEGIN
SET @HundredCrAdvance = 10000
SET @NotHundredCrAdvance = NULL
END
ELSE IF @BranchFilter = 2
BEGIN
SET @HundredCrAdvance = NULL
SET @NotHundredCrAdvance = 10000
END
ELSE
BEGIN
SET @HundredCrAdvance = NULL
SET @NotHundredCrAdvance = NULL
END
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	
		
	SET NOCOUNT ON;
  SELECT (SELECT BranchName FROM BranchMaster WHERE BranchTypeID = 3 AND BranchRegionalID = A.BranchRegionalID) AS Region,    A.BranchCode AS BIC, A.BranchName, 
      
      (CASE WHEN [ClearingType] =0
            THEN 'Inward' 
            ELSE 'Outward' End) AS ClearingType
      ,[NormalClearingNumber]
      ,[NormalClearingValue]
      ,[HighValueClearingNumber]
      ,[HighValueClearingValue]
      ,[InterBranchClearingNumber]
      ,[InterBranchClearingValue]
      ,[NationalClearingNumber]
      ,[NationalClearingValue]
      ,[ReturnedClearingNumber]
      ,[ReturnedClearingValue]
FROM         BranchMaster A INNER JOIN
                      BranchYearDetails ON A.BranchID = BranchYearDetails.BranchID INNER JOIN
                      LFAR_CHOSB_Clearing ON BranchYearDetails.BranchYearID = LFAR_CHOSB_Clearing.BranchYearID LEFT OUTER JOIN
					  ClosureDetails ON BranchYearDetails.BranchYearID = ClosureDetails.BranchYearID

  where  BranchYearDetails.FinYear=@FinYear 
 AND  (BranchYearDetails.IsClosed = @IsAuditClosed OR (@IsAuditClosed IS NULL OR @IsAuditClosed = 0))
 AND  (ClosureDetails.ClosureIssued = @IsRectifcationClosed OR (@IsRectifcationClosed IS NULL OR @IsRectifcationClosed = 0))
 AND  (BranchYearDetails.AdvancesAmount >= @HundredCrAdvance OR @HundredCrAdvance IS NULL)
 AND  (BranchYearDetails.AdvancesAmount < @NotHundredCrAdvance OR @NotHundredCrAdvance IS NULL)
 AND (NormalClearingValue > 0 OR HighValueClearingValue >0 OR InterBranchClearingValue >0 OR NationalClearingValue >0 OR ReturnedClearingValue >0)
 OPTION (RECOMPILE)
END





















GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_ConsolidateAnnexureE]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_LFAR_ConsolidateAnnexureE] 
	  @FinYear SMALLINT,
	  @BranchFilter SMALLINT = NULL,
	  @FilterComment BIT= NULL,
	  @IsAuditClosed BIT = NULL,
	  @IsRectifcationClosed BIT = NULL,
	  @BranchRegionalId TINYINT = 0
	 
AS
	BEGIN
	DECLARE @HundredCrAdvance int
	DECLARE @NotHundredCrAdvance int
	IF @BranchFilter = 1
	BEGIN
		SET @HundredCrAdvance = 10000
		SET @NotHundredCrAdvance = NULL
	END
	ELSE IF @BranchFilter = 2
	BEGIN
		SET @HundredCrAdvance = NULL
		SET @NotHundredCrAdvance = 10000
	END
	ELSE
	BEGIN
		SET @HundredCrAdvance = NULL
		SET @NotHundredCrAdvance = NULL
	END
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
		
	SET NOCOUNT ON;
	SELECT (SELECT BranchName FROM BranchMaster WHERE BranchTypeID = 3 AND BranchRegionalID = A.BranchRegionalID) AS Region,A.BranchCode AS BIC, A.BranchName,ISNULL(LFAR_AnnexureE.AccNumber,'') as AccNumber,ISNULL(LFAR_AnnexureE.Borrower,'') as Borrower, ISNULL(LFAR_AnnexureE.Facility,'') as Facility,ISNULL(CAST(LFAR_AnnexureE.SanctionedLimit AS nvarchar),'') as SanctionedLimit,ISNULL(CAST( CAST(LFAR_AnnexureE.SanctionDate AS DATE) AS varchar),'') as SanctionDate,ISNULL(CAST( LFAR_AnnexureE.BalanceAmount AS nvarchar),'') as BalanceAmount,ISNULL((SELECT DeficiencyNature FROM LFAR_AnnexureDeficiencyNatureMaster WHERE DeficiencyNatureID=LFAR_AnnexureE.DeficiencyNatureID),'') as DeficiencyNature,LFAR_AnnexureE.IrregularitySBA AS AuditorComments, LFAR_AnnexureE.ReplyOfBranch AS BranchRectificationComments,LFAR_AnnexureE.BranchYearID, SlNo,('A/C.No. '+ ISNULL(LFAR_AnnexureE.AccNumber,'') + ' - '+ ISNULL(LFAR_AnnexureE.Borrower,'') 
			+ '@@@Facility- ' +ISNULL(LFAR_AnnexureE.Facility,'')
			+ '@@@Limit- '+ISNULL(CAST(LFAR_AnnexureE.SanctionedLimit AS nvarchar),'')
			+ '@@@Sanction Date- '+ISNULL(CAST( CAST(LFAR_AnnexureE.SanctionDate AS DATE) AS varchar),'') 
			+ '@@@Balance O/S- '+ISNULL(CAST( LFAR_AnnexureE.BalanceAmount AS nvarchar),'')) AS BorrowerDetails
	FROM   BranchMaster A 
		INNER JOIN BranchYearDetails ON A.BranchID = BranchYearDetails.BranchID 
		INNER JOIN LFAR_AnnexureE ON BranchYearDetails.BranchYearID = LFAR_AnnexureE.BranchYearID 
		LEFT OUTER JOIN ClosureDetails ON BranchYearDetails.BranchYearID = ClosureDetails.BranchYearID
	WHERE BranchYearDetails.FinYear=@FinYear 
		 AND  (BranchYearDetails.IsClosed = @IsAuditClosed OR (@IsAuditClosed IS NULL OR @IsAuditClosed = 0))
		 AND  (ClosureDetails.ClosureIssued = @IsRectifcationClosed OR (@IsRectifcationClosed IS NULL OR @IsRectifcationClosed = 0))
		 AND  (BranchYearDetails.AdvancesAmount >= @HundredCrAdvance OR @HundredCrAdvance IS NULL)
		 AND  (((BranchYearDetails.AdvancesAmount < @NotHundredCrAdvance OR BranchYearDetails.AdvancesAmount IS NULL) 
			--	AND LFAR_AnnexureE.SanctionedLimit > 200) 
				OR @NotHundredCrAdvance IS NULL))
		 -- AND  ((LFAR_AnnexureE.SanctionedLimit = 0)OR (LFAR_AnnexureE.SanctionedLimit IS NULL))
		 AND  ((@FilterComment IS NULL OR @FilterComment = 0) OR  LEN(IrregularitySBA) > 15 )
		 AND ((@BranchRegionalId <> 0 AND (A.BranchRegionalID = @BranchRegionalId)) OR
		(@BranchRegionalId = 0 AND (A.BranchTypeID = 3 OR A.BranchTypeID = 4 OR A.BranchTypeID = 2)))
	OPTION (RECOMPILE)
END











GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_ConsolidateAnnexureF]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[USP_LFAR_ConsolidateAnnexureF] 
	  @FinYear SMALLINT,
	  @BranchFilter SMALLINT = NULL,
	  @FilterComment BIT= NULL,
	  @IsAuditClosed BIT = NULL,
	  @IsRectifcationClosed BIT = NULL,
	  @BranchRegionalId TINYINT = 0
	 
AS
	BEGIN
	DECLARE @HundredCrAdvance int
	DECLARE @NotHundredCrAdvance int
	IF @BranchFilter = 1
	BEGIN
		SET @HundredCrAdvance = 10000
		SET @NotHundredCrAdvance = NULL
	END
	ELSE IF @BranchFilter = 2
	BEGIN
		SET @HundredCrAdvance = NULL
		SET @NotHundredCrAdvance = 10000
	END
	ELSE
	BEGIN
		SET @HundredCrAdvance = NULL
		SET @NotHundredCrAdvance = NULL
	END
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
		
	SET NOCOUNT ON;
	SELECT (SELECT BranchName FROM BranchMaster WHERE BranchTypeID = 3 AND BranchRegionalID = A.BranchRegionalID) AS Region,A.BranchCode AS BIC, A.BranchName,ISNULL(LFAR_AnnexureF.AccNumber,'') as AccNumber,ISNULL(LFAR_AnnexureF.Borrower,'') as Borrower,ISNULL(LFAR_AnnexureF.Facility,'') as Facility,ISNULL(CAST(LFAR_AnnexureF.SanctionedLimit AS nvarchar),'') as SanctionedLimit,ISNULL(CAST( CAST(LFAR_AnnexureF.SanctionDate AS DATE) AS varchar),'') as SanctionDate,ISNULL(CAST( LFAR_AnnexureF.BalanceAmount AS nvarchar),'') as BalanceAmount,
LFAR_AnnexureF.IrregularitySBA AS AuditorComments, LFAR_AnnexureF.ReplyOfBranch AS BranchRectificationComments,LFAR_AnnexureF.BranchYearID, SlNo,('A/C.No. '+ ISNULL(LFAR_AnnexureF.AccNumber,'') + ' - '+ ISNULL(LFAR_AnnexureF.Borrower,'') 
			+ '@@@Facility- ' +ISNULL(LFAR_AnnexureF.Facility,'')
			+ '@@@Limit- '+ISNULL(CAST(LFAR_AnnexureF.SanctionedLimit AS nvarchar),'')
			+ '@@@Sanction Date- '+ISNULL(CAST( CAST(LFAR_AnnexureF.SanctionDate AS DATE) AS varchar),'') 
			+ '@@@Balance O/S- '+ISNULL(CAST( LFAR_AnnexureF.BalanceAmount AS nvarchar),'')) AS BorrowerDetails
	FROM   BranchMaster A 
		INNER JOIN BranchYearDetails ON A.BranchID = BranchYearDetails.BranchID 
		INNER JOIN LFAR_AnnexureF ON BranchYearDetails.BranchYearID = LFAR_AnnexureF.BranchYearID 
		LEFT OUTER JOIN ClosureDetails ON BranchYearDetails.BranchYearID = ClosureDetails.BranchYearID
	WHERE BranchYearDetails.FinYear=@FinYear 
		 AND  (BranchYearDetails.IsClosed = @IsAuditClosed OR (@IsAuditClosed IS NULL OR @IsAuditClosed = 0))
		 AND  (ClosureDetails.ClosureIssued = @IsRectifcationClosed OR (@IsRectifcationClosed IS NULL OR @IsRectifcationClosed = 0))
		 AND  (BranchYearDetails.AdvancesAmount >= @HundredCrAdvance OR @HundredCrAdvance IS NULL)
		 AND  (((BranchYearDetails.AdvancesAmount < @NotHundredCrAdvance OR BranchYearDetails.AdvancesAmount IS NULL) 
			--	AND LFAR_AnnexureF.SanctionedLimit > 200)
				 OR @NotHundredCrAdvance IS NULL))
		-- AND  ((LFAR_AnnexureF.SanctionedLimit = 0) OR (LFAR_AnnexureF.SanctionedLimit IS NULL))
		 AND  ((@FilterComment IS NULL OR @FilterComment = 0) OR  LEN(IrregularitySBA) > 15 )
		 AND ((@BranchRegionalId <> 0 AND (A.BranchRegionalID = @BranchRegionalId)) OR
		(@BranchRegionalId = 0 AND (A.BranchTypeID = 3 OR A.BranchTypeID = 4 or A.BranchTypeID = 2)))
	OPTION (RECOMPILE)
END










GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_ConsolidateAnnexureH]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[USP_LFAR_ConsolidateAnnexureH] 
	  @FinYear SMALLINT,
	  @BranchFilter SMALLINT = NULL,
	  @FilterComment BIT= NULL,
	  @IsAuditClosed BIT = NULL,
	  @IsRectifcationClosed BIT = NULL,
	  @BranchRegionalId TINYINT = 0
	 
AS
	BEGIN
	DECLARE @HundredCrAdvance int
	DECLARE @NotHundredCrAdvance int
	IF @BranchFilter = 1
	BEGIN
		SET @HundredCrAdvance = 10000
		SET @NotHundredCrAdvance = NULL
	END
	ELSE IF @BranchFilter = 2
	BEGIN
		SET @HundredCrAdvance = NULL
		SET @NotHundredCrAdvance = 10000
	END
	ELSE
	BEGIN
		SET @HundredCrAdvance = NULL
		SET @NotHundredCrAdvance = NULL
	END
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
		
	SET NOCOUNT ON;
	SELECT (SELECT BranchName FROM BranchMaster WHERE BranchTypeID = 3 AND BranchRegionalID = A.BranchRegionalID) AS Region,A.BranchCode AS BIC, A.BranchName,ISNULL(LFAR_AnnexureH.AccNumber,'') as AccNumber,ISNULL(LFAR_AnnexureH.Borrower,'') as Borrower,ISNULL(LFAR_AnnexureH.Facility,'') as Facility,ISNULL(CAST(LFAR_AnnexureH.SanctionedLimit AS nvarchar),'') as SanctionedLimit, ISNULL(CAST( CAST(LFAR_AnnexureH.SanctionDate AS DATE) AS varchar),'') as SanctionDate, ISNULL(CAST( LFAR_AnnexureH.BalanceAmount AS nvarchar),'') as BalanceAmount, ISNULL(CAST( CAST(LFAR_AnnexureH.RenewalDate AS DATE) AS varchar),'') as RenewalDate,ISNULL(CASE LFAR_AnnexureH.TypeOfDue WHEN 1 THEN 'Review' ELSE 'Renew' END,'') as TypeOfDue,ISNULL((SELECT DeficiencyNature FROM LFAR_AnnexureDeficiencyNatureMaster WHERE DeficiencyNatureID=LFAR_AnnexureH.DeficiencyNatureID),'') as DeficiencyNatureID,LFAR_AnnexureH.IrregularitySBA AS AuditorComments, LFAR_AnnexureH.ReplyOfBranch AS BranchRectificationComments,LFAR_AnnexureH.BranchYearID, SlNo,('A/C.No. '+ ISNULL(LFAR_AnnexureH.AccNumber,'') + ' - '+ ISNULL(LFAR_AnnexureH.Borrower,'') 
			+ '@@@Facility- ' +ISNULL(LFAR_AnnexureH.Facility,'')
			+ '@@@Limit- '+ISNULL(CAST(LFAR_AnnexureH.SanctionedLimit AS nvarchar),'')
			+ '@@@Sanction Date- '+ISNULL(CAST( CAST(LFAR_AnnexureH.SanctionDate AS DATE) AS varchar),'') 
			+ '@@@Balance O/S- '+ISNULL(CAST( LFAR_AnnexureH.BalanceAmount AS nvarchar),'')) AS BorrowerDetails
	FROM   BranchMaster A 
		INNER JOIN BranchYearDetails ON A.BranchID = BranchYearDetails.BranchID 
		INNER JOIN LFAR_AnnexureH ON BranchYearDetails.BranchYearID = LFAR_AnnexureH.BranchYearID 
		LEFT OUTER JOIN ClosureDetails ON BranchYearDetails.BranchYearID = ClosureDetails.BranchYearID
	WHERE BranchYearDetails.FinYear=@FinYear 
		 AND  (BranchYearDetails.IsClosed = @IsAuditClosed OR (@IsAuditClosed IS NULL OR @IsAuditClosed = 0))
		 AND  (ClosureDetails.ClosureIssued = @IsRectifcationClosed OR (@IsRectifcationClosed IS NULL OR @IsRectifcationClosed = 0))
		 AND  (BranchYearDetails.AdvancesAmount >= @HundredCrAdvance OR @HundredCrAdvance IS NULL)
		 AND  (((BranchYearDetails.AdvancesAmount < @NotHundredCrAdvance OR BranchYearDetails.AdvancesAmount IS NULL) 
			--	AND LFAR_AnnexureH.SanctionedLimit > 200) 
				OR @NotHundredCrAdvance IS NULL))
		-- AND  ((LFAR_AnnexureH.SanctionedLimit = 0) OR (LFAR_AnnexureH.SanctionedLimit IS NULL))
		 AND  ((@FilterComment IS NULL OR @FilterComment = 0) OR  LEN(IrregularitySBA) > 15 )
		 AND ((@BranchRegionalId <> 0 AND (A.BranchRegionalID = @BranchRegionalId)) OR
		(@BranchRegionalId = 0 AND (A.BranchTypeID = 3 OR A.BranchTypeID = 4 OR A.BranchTypeID =2)))
	OPTION (RECOMPILE)
END
 










GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_ConsolidateAnnexureI]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_LFAR_ConsolidateAnnexureI] 
	  @FinYear SMALLINT,
	  @BranchFilter SMALLINT = NULL,
	  @FilterComment BIT= NULL,
	  @IsAuditClosed BIT = NULL,
	  @IsRectifcationClosed BIT = NULL,
	  @BranchRegionalId TINYINT = 0
	 
AS
	BEGIN
	DECLARE @HundredCrAdvance int
	DECLARE @NotHundredCrAdvance int
	IF @BranchFilter = 1
	BEGIN
		SET @HundredCrAdvance = 10000
		SET @NotHundredCrAdvance = NULL
	END
	ELSE IF @BranchFilter = 2
	BEGIN
		SET @HundredCrAdvance = NULL
		SET @NotHundredCrAdvance = 10000
	END
	ELSE
	BEGIN
		SET @HundredCrAdvance = NULL
		SET @NotHundredCrAdvance = NULL
	END
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
		
	SET NOCOUNT ON;
	SELECT (SELECT BranchName FROM BranchMaster WHERE BranchTypeID = 3 AND BranchRegionalID = A.BranchRegionalID) AS Region,A.BranchCode AS BIC, A.BranchName,ISNULL(LFAR_AnnexureI.AccNumber,'') as AccNumber, ISNULL(LFAR_AnnexureI.Borrower,'') as Borrower,ISNULL(LFAR_AnnexureI.Facility,'') as Facility,ISNULL(CAST(LFAR_AnnexureI.SanctionedLimit AS nvarchar),'') as SanctionedLimit,ISNULL(CAST( CAST(LFAR_AnnexureI.SanctionDate AS DATE) AS varchar),'') as SanctionDate,ISNULL(CAST( LFAR_AnnexureI.BalanceAmount AS nvarchar),'') as BalanceAmount,ISNULL(CAST( CAST(LFAR_AnnexureI.DateOfNPA AS DATE) AS varchar),'') as DateOfNPA,ISNULL(LFAR_AnnexureI.AssetClassification,'') as AssetClassification,
LFAR_AnnexureI.IrregularitySBA AS AuditorComments, LFAR_AnnexureI.ReplyOfBranch AS BranchRectificationComments,LFAR_AnnexureI.BranchYearID, SlNo,('A/C.No. '+ ISNULL(LFAR_AnnexureI.AccNumber,'') + ' - '+ ISNULL(LFAR_AnnexureI.Borrower,'') 
			+ '@@@Facility- ' +ISNULL(LFAR_AnnexureI.Facility,'')
			+ '@@@Limit- '+ISNULL(CAST(LFAR_AnnexureI.SanctionedLimit AS nvarchar),'')
			+ '@@@Sanction Date- '+ISNULL(CAST( CAST(LFAR_AnnexureI.SanctionDate AS DATE) AS varchar),'') 
			+ '@@@Balance O/S- '+ISNULL(CAST( LFAR_AnnexureI.BalanceAmount AS nvarchar),'')) AS BorrowerDetails
	FROM   BranchMaster A 
		INNER JOIN BranchYearDetails ON A.BranchID = BranchYearDetails.BranchID 
		INNER JOIN LFAR_AnnexureI ON BranchYearDetails.BranchYearID = LFAR_AnnexureI.BranchYearID 
		LEFT OUTER JOIN ClosureDetails ON BranchYearDetails.BranchYearID = ClosureDetails.BranchYearID
	WHERE BranchYearDetails.FinYear=@FinYear 
		 AND  (BranchYearDetails.IsClosed = @IsAuditClosed OR (@IsAuditClosed IS NULL OR @IsAuditClosed = 0))
		 AND  (ClosureDetails.ClosureIssued = @IsRectifcationClosed OR (@IsRectifcationClosed IS NULL OR @IsRectifcationClosed = 0))
		 AND  (BranchYearDetails.AdvancesAmount >= @HundredCrAdvance OR @HundredCrAdvance IS NULL)
		 AND  (((BranchYearDetails.AdvancesAmount < @NotHundredCrAdvance OR BranchYearDetails.AdvancesAmount IS NULL) 
				-- AND LFAR_AnnexureI.SanctionedLimit > 200)
				 OR @NotHundredCrAdvance IS NULL))
		 -- AND  ((LFAR_AnnexureI.SanctionedLimit = 0)OR (LFAR_AnnexureI.SanctionedLimit IS NULL))
		 AND  ((@FilterComment IS NULL OR @FilterComment = 0) OR  LEN(IrregularitySBA) > 15 )
		 AND ((@BranchRegionalId <> 0 AND (A.BranchRegionalID = @BranchRegionalId)) OR
		(@BranchRegionalId = 0 AND (A.BranchTypeID = 3 OR A.BranchTypeID = 4 OR A.BranchTypeID =2)))
	OPTION (RECOMPILE)
END











GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_ConsolidateAnnexureLAB]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_LFAR_ConsolidateAnnexureLAB] 
	  @FinYear SMALLINT,
	  @BranchFilter SMALLINT = NULL,
	  @FilterComment BIT= NULL,
	  @IsAuditClosed BIT = NULL,
	  @IsRectifcationClosed BIT = NULL
	 
AS
BEGIN
	DECLARE @HundredCrAdvance int
	DECLARE @NotHundredCrAdvance int
	IF @BranchFilter = 1
	BEGIN
		SET @HundredCrAdvance = 10000
		SET @NotHundredCrAdvance = NULL
	END
	ELSE IF @BranchFilter = 2
	BEGIN
		SET @HundredCrAdvance = NULL
		SET @NotHundredCrAdvance = 10000
	END
	ELSE
	BEGIN
		SET @HundredCrAdvance = NULL
		SET @NotHundredCrAdvance = NULL
	END
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.	
		
	SET NOCOUNT ON;
    SELECT LFAR_LABARB_Annexure1.BranchYearID, SlNo, 
		(SELECT BranchName FROM BranchMaster WHERE BranchTypeID = 3 AND BranchRegionalID = A.BranchRegionalID) AS Region, 
		A.BranchCode AS BIC, A.BranchName,LFAR_LABARB_Annexure1.Borrower, LFAR_LABARB_Annexure1.LABRemarks AS AuditorComments                                          
	FROM  BranchMaster A 
		INNER JOIN BranchYearDetails ON A.BranchID = BranchYearDetails.BranchID 
		INNER JOIN LFAR_LABARB_Annexure1 ON BranchYearDetails.BranchYearID = LFAR_LABARB_Annexure1.BranchYearID 
		LEFT OUTER JOIN ClosureDetails ON BranchYearDetails.BranchYearID = ClosureDetails.BranchYearID
	Where  BranchYearDetails.FinYear = @FinYear 
		 AND  (BranchYearDetails.IsClosed = @IsAuditClosed OR (@IsAuditClosed IS NULL OR @IsAuditClosed = 0))
		 AND  (ClosureDetails.ClosureIssued = @IsRectifcationClosed OR (@IsRectifcationClosed IS NULL OR @IsRectifcationClosed = 0))
		 AND  (BranchYearDetails.AdvancesAmount >= @HundredCrAdvance OR @HundredCrAdvance IS NULL)
		 AND  ((BranchYearDetails.AdvancesAmount < @NotHundredCrAdvance OR BranchYearDetails.AdvancesAmount IS NULL) 
			OR @NotHundredCrAdvance IS NULL)
		 AND  ((@FilterComment IS NULL OR @FilterComment = 0) OR  LEN(LABRemarks) > 15 )
 	OPTION (RECOMPILE)
END













GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_ConsolidateAnnexureR]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_LFAR_ConsolidateAnnexureR] 
	  @FinYear SMALLINT,
	  @BranchFilter SMALLINT = NULL,
	  @FilterComment BIT= NULL,
	  @IsAuditClosed BIT = NULL,
	  @IsRectifcationClosed BIT = NULL,
	  @BranchRegionalId TINYINT = 0
	 
AS
BEGIN
	DECLARE @HundredCrAdvance int
	DECLARE @NotHundredCrAdvance int
	IF @BranchFilter = 1
	BEGIN
		SET @HundredCrAdvance = 10000
		SET @NotHundredCrAdvance = NULL
	END
	ELSE IF @BranchFilter = 2
	BEGIN
		SET @HundredCrAdvance = NULL
		SET @NotHundredCrAdvance = 10000
	END
	ELSE
	BEGIN
		SET @HundredCrAdvance = NULL
		SET @NotHundredCrAdvance = NULL
	END
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.	
		
	SET NOCOUNT ON;
	SELECT (SELECT BranchName FROM BranchMaster WHERE BranchTypeID = 3 AND BranchRegionalID = A.BranchRegionalID) AS Region,A.BranchCode AS BIC, A.BranchName,ISNULL(LFAR_AnnexureR.NatureOfIncExp,'') as NatureOfIncExp,ISNULL(CAST(LFAR_AnnexureR.IncExpAmount AS nvarchar),'') as IncExpAmount, LFAR_AnnexureR.IrregularitySBA AS AuditorComments, 
LFAR_AnnexureR.ReplyOfBranch AS BranchRectificationComments,LFAR_AnnexureR.BranchYearID, SlNo,('Nature of Income/Expenditure - '+ ISNULL(LFAR_AnnexureR.NatureOfIncExp,'') 
		+ '@@@Amount - '+ISNULL(CAST(LFAR_AnnexureR.IncExpAmount AS nvarchar),'')) AS BorrowerDetails
	FROM  BranchMaster A 
		INNER JOIN BranchYearDetails ON A.BranchID = BranchYearDetails.BranchID 
		INNER JOIN LFAR_AnnexureR ON BranchYearDetails.BranchYearID = LFAR_AnnexureR.BranchYearID 
		LEFT OUTER JOIN ClosureDetails ON BranchYearDetails.BranchYearID = ClosureDetails.BranchYearID
	Where  BranchYearDetails.FinYear = @FinYear 
		 AND  (BranchYearDetails.IsClosed = @IsAuditClosed OR (@IsAuditClosed IS NULL OR @IsAuditClosed = 0))
		 AND  (ClosureDetails.ClosureIssued = @IsRectifcationClosed OR (@IsRectifcationClosed IS NULL OR @IsRectifcationClosed = 0))
		 AND  (BranchYearDetails.AdvancesAmount >= @HundredCrAdvance OR @HundredCrAdvance IS NULL)
		 AND  ((BranchYearDetails.AdvancesAmount < @NotHundredCrAdvance OR BranchYearDetails.AdvancesAmount IS NULL) 
			OR @NotHundredCrAdvance IS NULL)
		 AND  (LFAR_AnnexureR.IncExpAmount > 0)
		 AND  ((@FilterComment IS NULL OR @FilterComment = 0) OR  LEN(IrregularitySBA) > 15 )
		 AND ((@BranchRegionalId <> 0 AND (A.BranchRegionalID = @BranchRegionalId)) OR
		(@BranchRegionalId = 0 AND (A.BranchTypeID = 3 OR A.BranchTypeID = 4 OR A.BranchTypeID =2)))
	OPTION (RECOMPILE)
END











GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_ConsolidateAnnexureS]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_LFAR_ConsolidateAnnexureS] 
	  @FinYear SMALLINT,
	  @BranchFilter SMALLINT = NULL,
	  @FilterComment BIT= NULL,
	  @IsAuditClosed BIT = NULL,
	  @IsRectifcationClosed BIT = NULL,
	  @BranchRegionalId TINYINT = 0
	 
AS
BEGIN
	DECLARE @HundredCrAdvance int
	DECLARE @NotHundredCrAdvance int
	IF @BranchFilter = 1
	BEGIN
		SET @HundredCrAdvance = 10000
		SET @NotHundredCrAdvance = NULL
	END
	ELSE IF @BranchFilter = 2
	BEGIN
		SET @HundredCrAdvance = NULL
		SET @NotHundredCrAdvance = 10000
	END
	ELSE
	BEGIN
		SET @HundredCrAdvance = NULL
		SET @NotHundredCrAdvance = NULL
	END
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	
		
	SET NOCOUNT ON;
	SELECT (SELECT BranchName FROM BranchMaster WHERE BranchTypeID = 3 AND BranchRegionalID = A.BranchRegionalID) AS Region, A.BranchCode AS BIC, A.BranchName, 
	
	ISNULL(LFAR_AnnexureS.NameOfBank,'') as NameOfBank,ISNULL(LFAR_AnnexureS.AccNumber,'') as AccNumber,ISNULL(CAST(LFAR_AnnexureS.BalanceAmount as nvarchar),'') as BalanceAmount,LFAR_AnnexureS.IrregularitySBA AS AuditorComments, LFAR_AnnexureS.ReplyOfBranch AS BranchRectificationComments,LFAR_AnnexureS.BranchYearID, SlNo,('Bank Name - '+ ISNULL(LFAR_AnnexureS.NameOfBank,'') + '@@@A/C.No. '+ ISNULL(LFAR_AnnexureS.AccNumber,'')+ '@@@Balance Amount - '+ISNULL(CAST(LFAR_AnnexureS.BalanceAmount AS nvarchar),'')) AS Details
	FROM  BranchMaster A 
		INNER JOIN BranchYearDetails ON A.BranchID = BranchYearDetails.BranchID 
		INNER JOIN LFAR_AnnexureS ON BranchYearDetails.BranchYearID = LFAR_AnnexureS.BranchYearID 
		LEFT OUTER JOIN ClosureDetails ON BranchYearDetails.BranchYearID = ClosureDetails.BranchYearID
	WHERE  BranchYearDetails.FinYear=@FinYear 
		 AND  (BranchYearDetails.IsClosed = @IsAuditClosed OR (@IsAuditClosed IS NULL OR @IsAuditClosed = 0))
		 AND  (ClosureDetails.ClosureIssued = @IsRectifcationClosed OR (@IsRectifcationClosed IS NULL OR @IsRectifcationClosed = 0))
		 AND  (BranchYearDetails.AdvancesAmount >= @HundredCrAdvance OR @HundredCrAdvance IS NULL)
		 AND  ((BranchYearDetails.AdvancesAmount < @NotHundredCrAdvance OR BranchYearDetails.AdvancesAmount IS NULL) OR @NotHundredCrAdvance IS NULL)
		 AND  (LFAR_AnnexureS.BalanceAmount > 0)
		 AND  ((@FilterComment IS NULL OR @FilterComment = 0) OR  LEN(IrregularitySBA) > 15 )
		 AND ((@BranchRegionalId <> 0 AND (A.BranchRegionalID = @BranchRegionalId)) OR
		(@BranchRegionalId = 0 AND (A.BranchTypeID = 3 OR A.BranchTypeID = 4 OR A.BranchTypeID =2)))
	OPTION (RECOMPILE)
END










GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_ConsolidateAnnexureTBDecree]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_LFAR_ConsolidateAnnexureTBDecree] 
	  @FinYear SMALLINT,
	  @BranchFilter SMALLINT = NULL,
	  @FilterComment BIT= NULL,
	  @IsAuditClosed BIT = NULL,
	  @IsRectifcationClosed BIT = NULL
	 
AS
BEGIN
	DECLARE @HundredCrAdvance int
	DECLARE @NotHundredCrAdvance int
	IF @BranchFilter = 1
	BEGIN
		SET @HundredCrAdvance = 10000
		SET @NotHundredCrAdvance = NULL
	END
	ELSE IF @BranchFilter = 2
	BEGIN
		SET @HundredCrAdvance = NULL
		SET @NotHundredCrAdvance = 10000
	END
	ELSE
	BEGIN
		SET @HundredCrAdvance = NULL
		SET @NotHundredCrAdvance = NULL
	END
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.	
		
	SET NOCOUNT ON;
    SELECT (SELECT BranchName FROM BranchMaster WHERE BranchTypeID = 3 AND BranchRegionalID = A.BranchRegionalID) AS Region,A.BranchCode AS BIC, A.BranchName,ISNULL(LFAR_AnnexureTimeBarredDecrees.AccNumber,'') as AccNumber, ISNULL(LFAR_AnnexureTimeBarredDecrees.Borrower,'') as Borrower,ISNULL(CAST(LFAR_AnnexureTimeBarredDecrees.Amount AS nvarchar),'') as Amount,ISNULL(LFAR_AnnexureTimeBarredDecrees.CaseDetails,'') as CaseDetails,LFAR_AnnexureTimeBarredDecrees.IrregularitySBA AS AuditorComments, LFAR_AnnexureTimeBarredDecrees.ReplyOfBranch AS  BranchRectificationComments, LFAR_AnnexureTimeBarredDecrees.BranchYearID, SlNo,('Borrower - '+ ISNULL(LFAR_AnnexureTimeBarredDecrees.Borrower,'') 
		+ '@@@Amount - '+ ISNULL(CAST(LFAR_AnnexureTimeBarredDecrees.Amount AS nvarchar),'') 
		+ '@@@Case Details - '+ ISNULL(LFAR_AnnexureTimeBarredDecrees.CaseDetails,'') )AS Details
	FROM  BranchMaster A 
		INNER JOIN BranchYearDetails ON A.BranchID = BranchYearDetails.BranchID 
		INNER JOIN LFAR_AnnexureTimeBarredDecrees ON BranchYearDetails.BranchYearID = LFAR_AnnexureTimeBarredDecrees.BranchYearID 
		LEFT OUTER JOIN ClosureDetails ON BranchYearDetails.BranchYearID = ClosureDetails.BranchYearID
	Where  BranchYearDetails.FinYear = @FinYear 
		 AND  (BranchYearDetails.IsClosed = @IsAuditClosed OR (@IsAuditClosed IS NULL OR @IsAuditClosed = 0))
		 AND  (ClosureDetails.ClosureIssued = @IsRectifcationClosed OR (@IsRectifcationClosed IS NULL OR @IsRectifcationClosed = 0))
		 AND  (BranchYearDetails.AdvancesAmount >= @HundredCrAdvance OR @HundredCrAdvance IS NULL)
		 AND  ((BranchYearDetails.AdvancesAmount < @NotHundredCrAdvance OR BranchYearDetails.AdvancesAmount IS NULL) 
			OR @NotHundredCrAdvance IS NULL)
		 AND (LFAR_AnnexureTimeBarredDecrees.Amount > 0)
		 AND  ((@FilterComment IS NULL OR @FilterComment = 0) OR  LEN(IrregularitySBA) > 15 )
	OPTION (RECOMPILE)
END













GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_ConsolidateAnnexureV]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_LFAR_ConsolidateAnnexureV] 
	  @FinYear SMALLINT,
	  @BranchFilter SMALLINT = NULL,
	  @FilterComment BIT= NULL,
	  @IsAuditClosed BIT = NULL,
	  @IsRectifcationClosed BIT = NULL,
	  @BranchRegionalId TINYINT = 0	 
AS
BEGIN
	DECLARE @HundredCrAdvance int
	DECLARE @NotHundredCrAdvance int
	IF @BranchFilter = 1
	BEGIN
		SET @HundredCrAdvance = 10000
		SET @NotHundredCrAdvance = NULL
	END
	ELSE IF @BranchFilter = 2
	BEGIN
		SET @HundredCrAdvance = NULL
		SET @NotHundredCrAdvance = 10000
	END
	ELSE
	BEGIN
		SET @HundredCrAdvance = NULL
		SET @NotHundredCrAdvance = NULL
	END
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.	
		
	SET NOCOUNT ON;
    SELECT LFAR_AnnexureV.BranchYearID, SlNo,  
		(SELECT BranchName FROM BranchMaster WHERE BranchTypeID = 3 AND BranchRegionalID = A.BranchRegionalID) AS Region,
		A.BranchCode AS BIC, A.BranchName, 
		LFAR_AnnexureV.IrregularitySBA AS AuditorComments, 
		LFAR_AnnexureV.ReplyOfBranch AS BranchRectification
	FROM  BranchMaster A 
		INNER JOIN BranchYearDetails ON A.BranchID = BranchYearDetails.BranchID 
		INNER JOIN LFAR_AnnexureV ON BranchYearDetails.BranchYearID = LFAR_AnnexureV.BranchYearID 
		LEFT OUTER JOIN ClosureDetails ON BranchYearDetails.BranchYearID = ClosureDetails.BranchYearID
	Where  BranchYearDetails.FinYear = @FinYear 
		 AND  (BranchYearDetails.IsClosed = @IsAuditClosed OR (@IsAuditClosed IS NULL OR @IsAuditClosed = 0))
		 AND  (ClosureDetails.ClosureIssued = @IsRectifcationClosed OR (@IsRectifcationClosed IS NULL OR @IsRectifcationClosed = 0))
		 AND  (BranchYearDetails.AdvancesAmount >= @HundredCrAdvance OR @HundredCrAdvance IS NULL)
		 AND  ((BranchYearDetails.AdvancesAmount < @NotHundredCrAdvance OR BranchYearDetails.AdvancesAmount IS NULL) 
			OR @NotHundredCrAdvance IS NULL)
		 AND  ((@FilterComment IS NULL OR @FilterComment = 0) OR  LEN(IrregularitySBA) > 15 )
		 AND ((@BranchRegionalId <> 0 AND (A.BranchRegionalID = @BranchRegionalId)) OR
		(@BranchRegionalId = 0 AND (A.BranchTypeID = 3 OR A.BranchTypeID = 4 OR A.BranchTypeID =2)))
	OPTION (RECOMPILE)
END











GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_ConsolidateBorrowerTop20]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_LFAR_ConsolidateBorrowerTop20]
AS
BEGIN
	SET NOCOUNT ON;
	SELECT ISNULL(Borrower,'') As BorrowerName, 'A2' As Annexure, (SELECT BranchName FROM BranchMaster WHERE BranchTypeID = 3 AND BranchRegionalID = A.BranchRegionalID) AS Region,
		A.BranchCode AS BIC, A.BranchName,('A/C.No. '+ ISNULL(AccNumber,'')  
				+ '@@@Facility - ' +ISNULL(Facility,'')
				+ '@@@Limit - '+ISNULL(CAST(SanctionedLimit AS nvarchar),'')
				+ '@@@Sanction Date - '+ISNULL(CAST( CAST(SanctionDate AS DATE) AS varchar),'') 
				+ '@@@Balance O/S - '+ISNULL(CAST( BalanceAmount AS nvarchar),'')) AS BorrowerDetails, 
		IrregularitySBA AS AuditorComments, ReplyOfBranch AS BranchRectificationComments
		FROM   BranchMaster A 
			INNER JOIN BranchYearDetails ON A.BranchID = BranchYearDetails.BranchID 
			INNER JOIN LFAR_AnnexureA ON BranchYearDetails.BranchYearID = LFAR_AnnexureA.BranchYearID 
			LEFT OUTER JOIN ClosureDetails ON BranchYearDetails.BranchYearID = ClosureDetails.BranchYearID
		WHERE BranchYearDetails.FinYear= (SELECT TOP 1 (FINYEAR) FROM FINYEAR)
			 AND BranchYearDetails.IsClosed = 1
			 AND A.BranchCode in('6027','3049','5063','5088','0461','9017','9042','5009','5037','5000','9031','7010','9095','5077','0460','0400','9044','6002','0418','9531','7008','4310')
	UNION ALL
	SELECT ISNULL(Borrower,'') As BorrowerName, 'A3' As Annexure, (SELECT BranchName FROM BranchMaster WHERE BranchTypeID = 3 AND BranchRegionalID = A.BranchRegionalID) AS Region,
		A.BranchCode AS BIC, A.BranchName,('A/C.No. '+ ISNULL(AccNumber,'')  
				+ '@@@Facility - ' +ISNULL(Facility,'')
				+ '@@@Limit - '+ISNULL(CAST(SanctionedLimit AS nvarchar),'')
				+ '@@@Sanction Date - '+ISNULL(CAST( CAST(SanctionDate AS DATE) AS varchar),'') 
				+ '@@@Balance O/S - '+ISNULL(CAST( BalanceAmount AS nvarchar),'')) AS BorrowerDetails, 
		IrregularitySBA AS AuditorComments, ReplyOfBranch AS BranchRectificationComments
		FROM   BranchMaster A 
			INNER JOIN BranchYearDetails ON A.BranchID = BranchYearDetails.BranchID 
			INNER JOIN LFAR_AnnexureB ON BranchYearDetails.BranchYearID = LFAR_AnnexureB.BranchYearID 
			LEFT OUTER JOIN ClosureDetails ON BranchYearDetails.BranchYearID = ClosureDetails.BranchYearID
		WHERE BranchYearDetails.FinYear= (SELECT TOP 1 (FINYEAR) FROM FINYEAR)
			 AND BranchYearDetails.IsClosed = 1
			 AND A.BranchCode in('6027','3049','5063','5088','0461','9017','9042','5009','5037','5000','9031','7010','9095','5077','0460','0400','9044','6002','0418','9531','7008','4310')
	UNION ALL
	SELECT ISNULL(Borrower,'') As BorrowerName, 'A4' As Annexure, (SELECT BranchName FROM BranchMaster WHERE BranchTypeID = 3 AND BranchRegionalID = A.BranchRegionalID) AS Region,
		A.BranchCode AS BIC, A.BranchName,('A/C.No. '+ ISNULL(AccNumber,'')  
				+ '@@@Facility - ' +ISNULL(Facility,'')
				+ '@@@Limit - '+ISNULL(CAST(SanctionedLimit AS nvarchar),'')
				+ '@@@Sanction Date - '+ISNULL(CAST( CAST(SanctionDate AS DATE) AS varchar),'') 
				+ '@@@Balance O/S - '+ISNULL(CAST( BalanceAmount AS nvarchar),'')) AS BorrowerDetails, 
		IrregularitySBA AS AuditorComments, ReplyOfBranch AS BranchRectificationComments
		FROM   BranchMaster A 
			INNER JOIN BranchYearDetails ON A.BranchID = BranchYearDetails.BranchID 
			INNER JOIN LFAR_AnnexureC ON BranchYearDetails.BranchYearID = LFAR_AnnexureC.BranchYearID 
			LEFT OUTER JOIN ClosureDetails ON BranchYearDetails.BranchYearID = ClosureDetails.BranchYearID
		WHERE BranchYearDetails.FinYear= (SELECT TOP 1 (FINYEAR) FROM FINYEAR)
			 AND BranchYearDetails.IsClosed = 1
			 AND A.BranchCode in('6027','3049','5063','5088','0461','9017','9042','5009','5037','5000','9031','7010','9095','5077','0460','0400','9044','6002','0418','9531','7008','4310')
	UNION ALL
	SELECT ISNULL(Borrower,'') As BorrowerName, 'A5' As Annexure, (SELECT BranchName FROM BranchMaster WHERE BranchTypeID = 3 AND BranchRegionalID = A.BranchRegionalID) AS Region,
		A.BranchCode AS BIC, A.BranchName,('A/C.No. '+ ISNULL(AccNumber,'')  
				+ '@@@Facility - ' +ISNULL(Facility,'')
				+ '@@@Limit - '+ISNULL(CAST(SanctionedLimit AS nvarchar),'')
				+ '@@@Sanction Date - '+ISNULL(CAST( CAST(SanctionDate AS DATE) AS varchar),'') 
				+ '@@@Balance O/S - '+ISNULL(CAST( BalanceAmount AS nvarchar),'')) AS BorrowerDetails, 
		IrregularitySBA AS AuditorComments, ReplyOfBranch AS BranchRectificationComments
		FROM   BranchMaster A 
			INNER JOIN BranchYearDetails ON A.BranchID = BranchYearDetails.BranchID 
			INNER JOIN LFAR_AnnexureH ON BranchYearDetails.BranchYearID = LFAR_AnnexureH.BranchYearID 
			LEFT OUTER JOIN ClosureDetails ON BranchYearDetails.BranchYearID = ClosureDetails.BranchYearID
		WHERE BranchYearDetails.FinYear= (SELECT TOP 1 (FINYEAR) FROM FINYEAR)
			 AND BranchYearDetails.IsClosed = 1
			 AND A.BranchCode in('6027','3049','5063','5088','0461','9017','9042','5009','5037','5000','9031','7010','9095','5077','0460','0400','9044','6002','0418','9531','7008','4310')
	UNION ALL
	SELECT ISNULL(Borrower,'') As BorrowerName, 'A6' As Annexure, (SELECT BranchName FROM BranchMaster WHERE BranchTypeID = 3 AND BranchRegionalID = A.BranchRegionalID) AS Region,
		A.BranchCode AS BIC, A.BranchName,('A/C.No. '+ ISNULL(AccNumber,'')  
				+ '@@@Facility - ' +ISNULL(Facility,'')
				+ '@@@Limit - '+ISNULL(CAST(SanctionedLimit AS nvarchar),'')
				+ '@@@Sanction Date - '+ISNULL(CAST( CAST(SanctionDate AS DATE) AS varchar),'') 
				+ '@@@Balance O/S - '+ISNULL(CAST( BalanceAmount AS nvarchar),'')) AS BorrowerDetails, 
		IrregularitySBA AS AuditorComments, ReplyOfBranch AS BranchRectificationComments
		FROM   BranchMaster A 
			INNER JOIN BranchYearDetails ON A.BranchID = BranchYearDetails.BranchID 
			INNER JOIN LFAR_AnnexureE ON BranchYearDetails.BranchYearID = LFAR_AnnexureE.BranchYearID 
			LEFT OUTER JOIN ClosureDetails ON BranchYearDetails.BranchYearID = ClosureDetails.BranchYearID
		WHERE BranchYearDetails.FinYear= (SELECT TOP 1 (FINYEAR) FROM FINYEAR)
			 AND BranchYearDetails.IsClosed = 1
			 AND A.BranchCode in('6027','3049','5063','5088','0461','9017','9042','5009','5037','5000','9031','7010','9095','5077','0460','0400','9044','6002','0418','9531','7008','4310')
	UNION ALL
	SELECT ISNULL(Borrower,'') As BorrowerName, 'A7' As Annexure, (SELECT BranchName FROM BranchMaster WHERE BranchTypeID = 3 AND BranchRegionalID = A.BranchRegionalID) AS Region,
		A.BranchCode AS BIC, A.BranchName,('A/C.No. '+ ISNULL(AccNumber,'')  
				+ '@@@Facility - ' +ISNULL(Facility,'')
				+ '@@@Limit - '+ISNULL(CAST(SanctionedLimit AS nvarchar),'')
				+ '@@@Sanction Date - '+ISNULL(CAST( CAST(SanctionDate AS DATE) AS varchar),'') 
				+ '@@@Balance O/S - '+ISNULL(CAST( BalanceAmount AS nvarchar),'')) AS BorrowerDetails, 
		IrregularitySBA AS AuditorComments, ReplyOfBranch AS BranchRectificationComments
		FROM   BranchMaster A 
			INNER JOIN BranchYearDetails ON A.BranchID = BranchYearDetails.BranchID 
			INNER JOIN LFAR_AnnexureF ON BranchYearDetails.BranchYearID = LFAR_AnnexureF.BranchYearID 
			LEFT OUTER JOIN ClosureDetails ON BranchYearDetails.BranchYearID = ClosureDetails.BranchYearID
		WHERE BranchYearDetails.FinYear= (SELECT TOP 1 (FINYEAR) FROM FINYEAR)
			 AND BranchYearDetails.IsClosed = 1
			 AND A.BranchCode in('6027','3049','5063','5088','0461','9017','9042','5009','5037','5000','9031','7010','9095','5077','0460','0400','9044','6002','0418','9531','7008','4310')
	UNION ALL
	SELECT ISNULL(Borrower,'') As BorrowerName, 'A9' As Annexure, (SELECT BranchName FROM BranchMaster WHERE BranchTypeID = 3 AND BranchRegionalID = A.BranchRegionalID) AS Region,
		A.BranchCode AS BIC, A.BranchName,('A/C.No. '+ ISNULL(AccNumber,'')  
				+ '@@@Facility - ' +ISNULL(Facility,'')
				+ '@@@Limit - '+ISNULL(CAST(SanctionedLimit AS nvarchar),'')
				+ '@@@Sanction Date - '+ISNULL(CAST( CAST(SanctionDate AS DATE) AS varchar),'') 
				+ '@@@Balance O/S - '+ISNULL(CAST( BalanceAmount AS nvarchar),'')) AS BorrowerDetails, 
		IrregularitySBA AS AuditorComments, ReplyOfBranch AS BranchRectificationComments
		FROM   BranchMaster A 
			INNER JOIN BranchYearDetails ON A.BranchID = BranchYearDetails.BranchID 
			INNER JOIN LFAR_AnnexureI ON BranchYearDetails.BranchYearID = LFAR_AnnexureI.BranchYearID 
			LEFT OUTER JOIN ClosureDetails ON BranchYearDetails.BranchYearID = ClosureDetails.BranchYearID
		WHERE BranchYearDetails.FinYear= (SELECT TOP 1 (FINYEAR) FROM FINYEAR)
			 AND BranchYearDetails.IsClosed = 1
			 AND A.BranchCode in('6027','3049','5063','5088','0461','9017','9042','5009','5037','5000','9031','7010','9095','5077','0460','0400','9044','6002','0418','9531','7008','4310')
	ORDER BY BorrowerName,Annexure,BIC
	
	OPTION (RECOMPILE)
END













GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_ConsolidateMainQuestions]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_LFAR_ConsolidateMainQuestions] 
	  @QuestionID SMALLINT ,
	  @FinYear SMALLINT,
	  @BranchFilter SMALLINT = NULL,
	  @FilterComment BIT= NULL,
	  @AnswerType TINYINT = NULL,
	  @IsAuditClosed BIT = NULL,
	  @IsRectifcationClosed BIT = NULL
AS
BEGIN
	DECLARE @HundredCrAdvance int
	DECLARE @NotHundredCrAdvance int
	IF @BranchFilter = 1
	BEGIN
		SET @HundredCrAdvance = 10000
		SET @NotHundredCrAdvance = NULL
	END
	ELSE IF @BranchFilter = 2
	BEGIN
		SET @HundredCrAdvance = NULL
		SET @NotHundredCrAdvance = 10000
	END
	ELSE
	BEGIN
		SET @HundredCrAdvance = NULL
		SET @NotHundredCrAdvance = NULL
	END
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	SELECT BranchAuditAnswerID, (SELECT BranchName FROM BranchMaster WHERE BranchTypeID = 3 AND BranchRegionalID = A.BranchRegionalID) AS Region,
		A.BranchCode AS BIC, A.BranchName, NULL AS BorrowerDetails,B.AnswerType,B.Compliant,
		[LFARComment] AS AuditorComments, ReplyOne AS BranchRectificationComments,B.ReplyTwo as ROComments
	FROM  BranchMaster A 
		INNER JOIN BranchYearDetails ON A.BranchID = BranchYearDetails.BranchID 
		INNER JOIN [LFAR_StatutoryAuditDetails] B ON BranchYearDetails.BranchYearID = B.BranchYearID 
		INNER JOIN [LFAR_QuestionDetails]  ON B.QuestionID = [LFAR_QuestionDetails].QuestionID 
		LEFT OUTER JOIN ClosureDetails ON BranchYearDetails.BranchYearID = ClosureDetails.BranchYearID
	WHERE B.QuestionID = @QuestionID 
		AND BranchYearDetails.FinYear=@FinYear 
		AND (COALESCE (LFARComment, '') <> ''
		AND ((CASE WHEN @AnswerType = 0 THEN 0 ELSE B.AnswerType END) = @AnswerType) 
		AND (BranchYearDetails.IsClosed = @IsAuditClosed OR (@IsAuditClosed IS NULL OR @IsAuditClosed = 0))
		AND (ClosureDetails.ClosureIssued = @IsRectifcationClosed OR (@IsRectifcationClosed IS NULL OR @IsRectifcationClosed = 0))
		AND (BranchYearDetails.AdvancesAmount >= @HundredCrAdvance OR @HundredCrAdvance IS NULL)
		AND ((BranchYearDetails.AdvancesAmount < @NotHundredCrAdvance OR BranchYearDetails.AdvancesAmount IS NULL) 
				OR @NotHundredCrAdvance IS NULL)
		AND (@FilterComment IS NULL OR @FilterComment = 0 OR (LFARComment NOT LIKE 'nil' collate sql_latin1_general_CP1_CI_AS
			AND LFARComment NOT LIKE 'NA' collate sql_latin1_general_CP1_CI_AS
			AND LFARComment NOT LIKE 'N.A' collate sql_latin1_general_CP1_CI_AS
			AND LFARComment NOT LIKE 'N.A.' collate sql_latin1_general_CP1_CI_AS
			AND LFARComment NOT LIKE 'N/A' collate sql_latin1_general_CP1_CI_AS
			AND LFARComment NOT LIKE '%NOT APPLICABLE%' collate sql_latin1_general_CP1_CI_AS
			AND LFARComment NOT LIKE '%NO such%' collate sql_latin1_general_CP1_CI_AS
			AND LFARComment NOT LIKE 'yes' collate sql_latin1_general_CP1_CI_AS
			AND LFARComment NOT LIKE 'no' collate sql_latin1_general_CP1_CI_AS)))
	OPTION (RECOMPILE)
END














GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_GetAllBranchesByZoneCodeAndRegionCode]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

 CREATE PROCEDURE [dbo].[USP_LFAR_GetAllBranchesByZoneCodeAndRegionCode]
    @BranchZonalID TINYINT ,
    @BranchRegionalID TINYINT
 AS 
    BEGIN
        SET NOCOUNT ON;
        SELECT  *
        FROM    dbo.BranchMaster
        WHERE   ( ISNULL(@BranchZonalID, 0) = 0 )
                OR ( ISNULL(@BranchZonalID, 0) > 0
                     AND BranchZonalID = @BranchZonalID
                     AND ( ( ISNULL(@BranchRegionalID, 0) > 0
                             AND BranchRegionalID = @BranchRegionalID
                           )
                           OR ( ISNULL(@BranchRegionalID, 0) = 0 )
                         )
                   )
        ORDER BY BranchTypeID ,
                BranchName ,
                BranchZonalID ,
                BranchRegionalID
    END
















GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_GetAllBranchesOfRegion]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

 create PROCEDURE [dbo].[USP_LFAR_GetAllBranchesOfRegion]
    @BranchRegionalID TINYINT
 AS 
    BEGIN
        SET NOCOUNT ON;
        SELECT  bd.BranchYearID,bm.BranchCode,bm.BranchName
        FROM    dbo.BranchMaster bm
		inner join dbo.BranchYearDetails bd on bm.BranchID=bd.BranchID
        WHERE    ( ISNULL(@BranchRegionalID, 0) > 0
                             AND BranchRegionalID = @BranchRegionalID
                           )
                           OR ( ISNULL(@BranchRegionalID, 0) = 0 )
                         
                   
        ORDER BY BranchTypeID ,
                BranchName ,
                BranchRegionalID
    END










GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_GetALLMissingQuestions]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[USP_LFAR_GetALLMissingQuestions]
@BranchYearId INT
AS
BEGIN
--Declare @QuestionCount INT;

--Set @QuestionCount=(SELECT COUNT(BRANCHYEARID) as BRANCHYEARIDCOUNT from LFAR_STATUTORYAUDITDETAILS where  BranchYearID=@BranchYearId)
--IF (@QuestionCount <> 0)
--BEGIN

SELECT DISTINCT ISNULL(vwLFAR_HeaderFamily.H1, 1) HeaderID ,
            vwLFAR_HeaderFamily.R1 RelativeHeaderID ,
            vwLFAR_HeaderFamily.HeaderOrderCaption ,
            vwLFAR_HeaderFamily.Cap1 HeaderCaption ,
            vwLFAR_HeaderFamily.FamilyHeaderCaption ,
            vwLFAR_HeaderFamily.HeaderNote ,
            vwLFAR_HeaderFamily.HeaderType ,
            vwLFAR_HeaderFamily.HeaderLevel ,
            LFAR_QuestionDetails.QuestionID ,
            LFAR_QuestionDetails.RelativeQuestionID ,
            LFAR_QuestionDetails.QuestionTypeID ,
            LFAR_QuestionDetails.DefaultAnswerType ,
            LFAR_QuestionDetails.AnnexureMandate ,
            LFAR_QuestionDetails.AnswerTypeVisibility ,
            LFAR_QuestionDetails.QuestionOrderCaption ,
            LFAR_QuestionDetails.LFARQuestion ,
            LFAR_QuestionDetails.LFARCheckList ,
            ISNULL(vwLFAR_QuestionFamily.RootQuestionID, 0) RootQuestionID ,
            ISNULL(vwLFAR_QuestionFamily.QuestionLevel, 0) QuestionLevel ,
            ISNULL(vwLFAR_QuestionFamily.QuestionLevel, 0)
            + vwLFAR_HeaderFamily.HeaderLevel RelativeHLevel ,
            vwLFAR_QuestionFamily.QuestionFamily
		--	LFAR_STATUTORYAUDITDETAILS.BRANCHYEARID
    FROM    vwLFAR_QuestionFamily
            INNER JOIN LFAR_QuestionDetails ON vwLFAR_QuestionFamily.Q1 = LFAR_QuestionDetails.QuestionID
            RIGHT OUTER JOIN vwLFAR_HeaderFamily ON LFAR_QuestionDetails.HeaderID = vwLFAR_HeaderFamily.H1
                                                    AND vwLFAR_HeaderFamily.HeaderLevel <> 1
		--	INNER JOIN LFAR_STATUTORYAUDITDETAILS ON LFAR_QuestionDetails.QuestionID = LFAR_StatutoryAuditDetails.QuestionID 
			--WHERE LFARCOMMENT IS NOT NULL AND REPLYONE IS NULL AND BRANCHYEARID=@BranchYearId
			WHERE
			-- ISNULL(LFARCOMMENT,'') <> '' AND ISNULL(REPLYONE,'') = '' AND 
			--LFAR_STATUTORYAUDITDETAILS.BRANCHYEARID=4131
			--and
			 LFAR_QuestionDetails.QuestionID  NOT IN (SELECT DISTINCT(QuestionID) from LFAR_STATUTORYAUDITDETAILS where  BranchYearID=@BranchYearId AND AnswerType!=0 ) 
			-- @BranchYearId
			AND LFAR_QuestionDetails.QuestionID  IS NOT NULL
		--	AND LFAR_STATUTORYAUDITDETAILS.BRANCHYEARID=4131

			 ORDER BY LFAR_QuestionDetails.QuestionID ASC

END
--ELSE 
--BEGIN

--SELECT DISTINCT LFAR_QuestionDetails.QuestionTypeID 'HeaderID',
--            LFAR_QuestionDetails.QuestionTypeID 'RelativeHeaderID' ,
--            LFAR_QuestionDetails.QuestionTypeID 'HeaderOrderCaption' ,
--            LFAR_QuestionDetails.QuestionTypeID 'HeaderCaption' ,
--            LFAR_QuestionDetails.QuestionTypeID 'FamilyHeaderCaption' ,
--            LFAR_QuestionDetails.QuestionTypeID 'HeaderNote' ,
--            LFAR_QuestionDetails.QuestionTypeID 'HeaderType' ,
--            LFAR_QuestionDetails.QuestionTypeID 'HeaderLevel' ,
--            LFAR_QuestionDetails.QuestionTypeID 'QuestionID' ,
--            LFAR_QuestionDetails.QuestionTypeID 'RelativeQuestionID' ,
--            LFAR_QuestionDetails.QuestionTypeID 'QuestionTypeID' ,
--            LFAR_QuestionDetails.QuestionTypeID 'DefaultAnswerType',
--            LFAR_QuestionDetails.QuestionTypeID 'AnnexureMandate' ,
--            LFAR_QuestionDetails.QuestionTypeID 'AnswerTypeVisibility' ,
--            LFAR_QuestionDetails.QuestionTypeID 'QuestionOrderCaption' ,
--            LFAR_QuestionDetails.QuestionTypeID 'LFARQuestion' ,
--           LFAR_QuestionDetails.QuestionTypeID 'LFARCheckList' ,
--            LFAR_QuestionDetails.QuestionTypeID  'RootQuestionID' ,
--            LFAR_QuestionDetails.QuestionTypeID 'QuestionLevel' ,
--            LFAR_QuestionDetails.QuestionTypeID 'RelativeHLevel' ,
--            LFAR_QuestionDetails.QuestionTypeID 'QuestionFamily'
--		--	LFAR_STATUTORYAUDITDETAILS.BRANCHYEARID
--    FROM    LFAR_QuestionDetails WHERE LFAR_QuestionDetails.QuestionID=0




--END



--END















GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_GetAllQuestionsForAuditorLoginForTree]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

 CREATE PROCEDURE [dbo].[USP_LFAR_GetAllQuestionsForAuditorLoginForTree]
 AS 
    BEGIN
        SELECT  *
        FROM    vwLFAR_HeaderAndQuestionForTree
        ORDER BY TYPEID ,
                ID ,
                HEADERLEVEL
    END
















GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_GetAnnexureDetailssMissing]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_LFAR_GetAnnexureDetailssMissing]
@BranchYearId int
AS
BEGIN
DECLARE @Tables varchar(2000)
DECLARE @Position INT
DECLARE @Length INT
DECLARE @Query varchar(512)

SET FMTONLY OFF;

CREATE TABLE #TmpTable
        (
          TABLENAME VARCHAR(100),
          RECORDCOUNT INT	  
        )

SET @Tables = 'LFAR_AnnexureA,LFAR_AnnexureB,LFAR_AnnexureC,LFAR_AnnexureH,LFAR_AnnexureE,LFAR_AnnexureF,LFAR_AnnexureI,'
SET @Position = 0
SET @Length = 0

WHILE CHARINDEX(',', @Tables, @Position+1)>0
BEGIN
    SET @Length = CHARINDEX(',', @Tables, @Position+1) - @Position
    SET @Query = SUBSTRING(@Tables, @Position, @Length)

	BEGIN TRY
		SET @Query = 'INSERT INTO #TMPTABLE SELECT ''' + @Query + ''', COUNT(BRANCHYEARID) FROM ' + @Query + ' WHERE BRANCHYEARID='+CAST(@BranchYearId AS VARCHAR(10))
		--SET @Query = 'INSERT INTO #TMPTABLE SELECT ''' + @Query + ''', COUNT(BRANCHYEARID) FROM ' + @Query + '  WHERE IRREGULARITYSBA IS NOT NULL AND REPLYOFBRANCH IS NULL AND BRANCHYEARID='+CAST(@BranchYearId AS VARCHAR(10))
		print (@Query)
		EXEC (@Query)
	END TRY
    BEGIN CATCH
    END CATCH
        
    SET @Position = CHARINDEX(',', @Tables, @Position+@Length) + 1
END
	SELECT AnnexureID,AnnexureName,AnnexureTitle,AnnexureTableName,AnnexureColumnHeaders FROM LFAR_ANNEXUREMASTER INNER JOIN #TMPTABLE ON LFAR_ANNEXUREMASTER.ANNEXURETABLENAME = #TMPTABLE.TABLENAME WHERE RECORDCOUNT = 0
	DROP TABLE #TmpTable
END













GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_GetAnnexureRemarksMissingTables]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[USP_LFAR_GetAnnexureRemarksMissingTables]
@BranchYearId int
AS
BEGIN
DECLARE @Tables varchar(2000)
DECLARE @Position INT
DECLARE @Length INT
DECLARE @Query varchar(512)

SET FMTONLY OFF;

CREATE TABLE #TmpTable
        (
          TABLENAME VARCHAR(100),
          RECORDCOUNT INT	  
        )

SET @Tables = 'LFAR_AnnexureS,LFAR_AnnexureA,LFAR_AnnexureB,LFAR_AnnexureC,LFAR_AnnexureH,LFAR_AnnexureE,LFAR_AnnexureF,LFAR_Main_Annexure007,LFAR_AnnexureI,LFAR_Main_Annexure001,LFAR_Main_Annexure002,LFAR_AnnexureBankGuaranteeAndLOC,LFAR_Main_Annexure003,LFAR_Main_Annexure004,LFAR_Main_Annexure005,LFAR_Main_Annexure008,LFAR_AnnexureR,LFAR_Main_Annexure006,LFAR_AnnexureInterBranchAccounts,LFAR_AnnexureV,LFAR_AnnexureTimeBarredDecrees,LFAR_CHOSB_Clearing,'
SET @Position = 0
SET @Length = 0

WHILE CHARINDEX(',', @Tables, @Position+1)>0
BEGIN
    SET @Length = CHARINDEX(',', @Tables, @Position+1) - @Position
    SET @Query = SUBSTRING(@Tables, @Position, @Length)

	BEGIN TRY
		SET @Query = 'INSERT INTO #TMPTABLE SELECT ''' + @Query + ''', COUNT(BRANCHYEARID) FROM ' + @Query + '  WHERE ISNULL(IRREGULARITYSBA,'''') <> '''' AND ISNULL(REPLYOFBRANCH,'''') = '''' AND BRANCHYEARID='+CAST(@BranchYearId AS VARCHAR(10))
		--SET @Query = 'INSERT INTO #TMPTABLE SELECT ''' + @Query + ''', COUNT(BRANCHYEARID) FROM ' + @Query + '  WHERE IRREGULARITYSBA IS NOT NULL AND REPLYOFBRANCH IS NULL AND BRANCHYEARID='+CAST(@BranchYearId AS VARCHAR(10))
		print (@Query)
		EXEC (@Query)
	END TRY
    BEGIN CATCH
    END CATCH
        
    SET @Position = CHARINDEX(',', @Tables, @Position+@Length) + 1
END
	SELECT AnnexureID,AnnexureName,AnnexureTitle,AnnexureTableName,AnnexureColumnHeaders FROM LFAR_ANNEXUREMASTER INNER JOIN #TMPTABLE ON LFAR_ANNEXUREMASTER.ANNEXURETABLENAME = #TMPTABLE.TABLENAME WHERE RECORDCOUNT > 0
	DROP TABLE #TmpTable
END














GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_GetAttendedQuestionBranchesForNonAuditorLoginByQuestion]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

 CREATE PROCEDURE [dbo].[USP_LFAR_GetAttendedQuestionBranchesForNonAuditorLoginByQuestion]
    @BranchZonalID TINYINT ,
    @BranchRegionalID TINYINT ,
    @QuestionID SMALLINT ,
    @FinYear SMALLINT
 AS 
    BEGIN
        SELECT  *
        FROM    dbo.BranchMaster
        WHERE   ( ISNULL(@BranchZonalID, 0) = 0 )
                OR ( ISNULL(@BranchZonalID, 0) > 0
                     AND BranchZonalID = @BranchZonalID
                     AND ( ( ISNULL(@BranchRegionalID, 0) > 0
                             AND BranchRegionalID = @BranchRegionalID
                           )
                           OR ( ISNULL(@BranchRegionalID, 0) = 0 )
                         )
                   )
                AND BRANCHID IN (
                SELECT     DISTINCT
                        ( BranchYearDetails.BranchID )
                FROM    BranchYearDetails
                        INNER JOIN LFAR_StatutoryAuditDetails ON BranchYearDetails.BranchYearID = LFAR_StatutoryAuditDetails.BranchYearID
                WHERE   LFAR_StatutoryAuditDetails.QuestionID = @QuestionID
                        AND BranchYearDetails.FinYear = @FinYear )
                          /*AND BRANCHTYPEID = 4 */
        ORDER BY BranchTypeID ,
                BranchName ,
                BranchZonalID ,
                BranchRegionalID
    END
















GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_GetAttendedQuestionsForAuditorLoginByBranchForTree]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

 CREATE PROCEDURE [dbo].[USP_LFAR_GetAttendedQuestionsForAuditorLoginByBranchForTree] @BranchYearID INT
 AS 
    BEGIN
        SELECT  *
        FROM    vwLFAR_HeaderAndQuestionForTree
        WHERE   TYPEID IN ( 1, 2 )
        UNION ALL
        SELECT  *
        FROM    vwLFAR_HeaderAndQuestionForTree
        WHERE   TYPEID = 3
                AND ID IN (
                SELECT     DISTINCT
                        ( LFAR_StatutoryAuditDetails.QuestionID )
                FROM    LFAR_StatutoryAuditDetails
                        INNER JOIN LFAR_QuestionDetails ON LFAR_StatutoryAuditDetails.QuestionID = LFAR_QuestionDetails.QuestionID
                WHERE   LFAR_StatutoryAuditDetails.BranchYearID = @BranchYearID )
                          /*AND BRANCHTYPEID = 4 */
        ORDER BY TYPEID ,
                ID ,
                HEADERLEVEL
    END
















GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_GetBranchesReadyForClosure]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

create PROCEDURE [dbo].[USP_LFAR_GetBranchesReadyForClosure]
@BranchRegionalId as TINYINT
AS
BEGIN

DECLARE @TotalQuestionCount TINYINT;
DECLARE @ComplianceCount TINYINT;
SET @TotalQuestionCount = (SELECT COUNT(QuestionID) FROM LFAR_QuestionDetails);
SET @ComplianceCount=0;
SET FMTONLY OFF;

CREATE TABLE #AnnexTmpTable
 (
	BranchYearID SMALLINT
 )
CREATE TABLE #TmpTable
 (
	BranchYearID SMALLINT
 )

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure1 WHERE Isapproved != 1

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure2 WHERE Isapproved != 1 

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure3 WHERE Isapproved != 1 

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure4 WHERE Isapproved != 1

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure4A WHERE Isapproved != 1

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure5 WHERE Isapproved != 1

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure5A WHERE Isapproved != 1

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure6 WHERE Isapproved != 1

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure7 WHERE Isapproved != 1

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure8 WHERE Isapproved != 1

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure9 WHERE Isapproved != 1

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure10 WHERE Isapproved != 1

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure11 WHERE Isapproved != 1

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure12 WHERE Isapproved != 1

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure13 WHERE Isapproved != 1

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure14 WHERE Isapproved != 1

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure15 WHERE Isapproved != 1

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure16 WHERE Isapproved != 1

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure17 WHERE Isapproved != 1

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure18 WHERE Isapproved != 1

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure19 WHERE Isapproved != 1

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure20 WHERE Isapproved != 1

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure21 WHERE Isapproved != 1

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure22 WHERE Isapproved != 1

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure23 WHERE Isapproved != 1

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure24 WHERE Isapproved != 1

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure25 WHERE Isapproved != 1

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure26 WHERE Isapproved != 1

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure27 WHERE Isapproved != 1

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure28 WHERE Isapproved != 1

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure29 WHERE Isapproved != 1

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure30 WHERE Isapproved != 1

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure31 WHERE Isapproved != 1

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure32 WHERE Isapproved != 1

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure33 WHERE Isapproved != 1

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure34 WHERE Isapproved != 1

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure35 WHERE Isapproved != 1

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure36 WHERE Isapproved != 1

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure39 WHERE Isapproved != 1

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure40 WHERE Isapproved != 1

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure41 WHERE Isapproved != 1

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure42 WHERE Isapproved != 1

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure43 WHERE Isapproved != 1

--INSERT INTO #AnnexTmpTable

--SELECT DISTINCT BranchYearID FROM LFAR_Annexure45 WHERE Isapproved != 1

INSERT INTO #AnnexTmpTable

SELECT DISTINCT BranchYearID FROM LFAR_AnnexureA WHERE IsApproved != 1

INSERT INTO #AnnexTmpTable

SELECT DISTINCT BranchYearID FROM LFAR_StatutoryAuditDetails WHERE Isapproved != 1
END

INSERT INTO #TmpTable
SELECT DISTINCT BranchYearID FROM #AnnexTmpTable;

WITH MYCTE AS
(
SELECT bd.BranchYearID
FROM BranchYearDetails AS bd
LEFT JOIN #TmpTable AS t ON t.BranchYearID=bd.BranchYearID
LEFT JOIN ClosureDetails AS c ON c.BranchYearID = bd.BranchYearID
WHERE bd.IsClosed = 1
AND t.BranchYearID IS NULL 
AND c.BranchYearID IS NULL
),

MYCTE1 AS (SELECT   AnswerSheet.BranchYearID ,
                        COUNT(AnswerSheet.BranchYearID) AS ComplianceAnswerCount
               FROM     LFAR_QuestionDetails AS QuestionSheet
                        LEFT OUTER JOIN LFAR_StatutoryAuditDetails AS AnswerSheet ON AnswerSheet.QuestionID = QuestionSheet.QuestionID
						INNER JOIN MYCTE ON AnswerSheet.BranchYearID=MYCTE.BranchYearID
               WHERE    ( AnswerSheet.AnswerType = QuestionSheet.AnswerTypeFromBank )
					    OR ( QuestionSheet.IsQuestionDisabled = 1 OR QuestionSheet.IsInvalidQuestion = 1 )  
               GROUP BY AnswerSheet.BranchYearID)

SELECT MYCTE.BranchYearID, B.BranchCode, B.BranchName, @TotalQuestionCount AS TotalQuestions, ISNULL(MYCTE1.ComplianceAnswerCount, 0) ComplianceAnswerCount, (@TotalQuestionCount-ISNULL(MYCTE1.ComplianceAnswerCount, 0)) NonComplianceAnswerCount
FROM MYCTE
INNER JOIN MYCTE1 ON MYCTE.BranchYearID = MYCTE1.BranchYearID
INNER JOIN vw_BranchDetailsWithRegion AS B on MYCTE.BranchYearID=B.BranchYearID
WHERE B.BranchRegionalId=@BranchRegionalId
----------------------------------------------------------------------------------


GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_GetClosedQuestionsForAuditorLoginByBranchForTree]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

 CREATE PROCEDURE [dbo].[USP_LFAR_GetClosedQuestionsForAuditorLoginByBranchForTree] @BranchYearID INT
 AS 
    BEGIN
        SELECT  *
        FROM    vwLFAR_HeaderAndQuestionForTree
        WHERE   TYPEID IN ( 1, 2 )
        UNION ALL
        SELECT  *
        FROM    vwLFAR_HeaderAndQuestionForTree
        WHERE   TYPEID = 3
                AND ID IN (
                SELECT     DISTINCT
                        ( LFAR_StatutoryAuditDetails.QuestionID )
                FROM    LFAR_StatutoryAuditDetails
                        INNER JOIN LFAR_QuestionDetails ON LFAR_StatutoryAuditDetails.QuestionID = LFAR_QuestionDetails.QuestionID
                WHERE   LFAR_StatutoryAuditDetails.BranchYearID = @BranchYearID
                        AND LFAR_StatutoryAuditDetails.IsClosed = 1 )
                          /*AND BRANCHTYPEID = 4 */
        ORDER BY TYPEID ,
                ID ,
                HEADERLEVEL
    END
















GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_GetCloseQuestionBranchesForNonAuditorLoginByQuestion]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

 CREATE PROCEDURE [dbo].[USP_LFAR_GetCloseQuestionBranchesForNonAuditorLoginByQuestion]
    @BranchZonalID TINYINT ,
    @BranchRegionalID TINYINT ,
    @QuestionID SMALLINT ,
    @FinYear SMALLINT
 AS 
    BEGIN
        SELECT  *
        FROM    dbo.BranchMaster
        WHERE   ( ISNULL(@BranchZonalID, 0) = 0 )
                OR ( ISNULL(@BranchZonalID, 0) > 0
                     AND BranchZonalID = @BranchZonalID
                     AND ( ( ISNULL(@BranchRegionalID, 0) > 0
                             AND BranchRegionalID = @BranchRegionalID
                           )
                           OR ( ISNULL(@BranchRegionalID, 0) = 0 )
                         )
                   )
                AND BRANCHID IN (
                SELECT     DISTINCT
                        ( BranchYearDetails.BranchID )
                FROM    BranchYearDetails
                        INNER JOIN LFAR_StatutoryAuditDetails ON BranchYearDetails.BranchYearID = LFAR_StatutoryAuditDetails.BranchYearID
                WHERE   LFAR_StatutoryAuditDetails.QuestionID = @QuestionID
                        AND BranchYearDetails.FinYear = @FinYear
                        AND LFAR_StatutoryAuditDetails.IsClosed = 1 )
                          /*AND BRANCHTYPEID = 4 */
        ORDER BY BranchTypeID ,
                BranchName ,
                BranchZonalID ,
                BranchRegionalID
    END
















GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_GetComplianceBranchesForNonAuditorLoginByQuestion]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

 CREATE PROCEDURE [dbo].[USP_LFAR_GetComplianceBranchesForNonAuditorLoginByQuestion]
    @BranchZonalID TINYINT ,
    @BranchRegionalID TINYINT ,
    @QuestionID SMALLINT ,
    @FinYear SMALLINT
 AS 
    BEGIN
        SELECT  *
        FROM    dbo.BranchMaster
        WHERE   ( ISNULL(@BranchZonalID, 0) = 0 )
                OR ( ISNULL(@BranchZonalID, 0) > 0
                     AND BranchZonalID = @BranchZonalID
                     AND ( ( ISNULL(@BranchRegionalID, 0) > 0
                             AND BranchRegionalID = @BranchRegionalID
                           )
                           OR ( ISNULL(@BranchRegionalID, 0) = 0 )
                         )
                   )
                AND BRANCHID IN (
                SELECT     DISTINCT
                        ( BranchYearDetails.BranchID )
                FROM    BranchYearDetails
                        INNER JOIN LFAR_StatutoryAuditDetails ON BranchYearDetails.BranchYearID = LFAR_StatutoryAuditDetails.BranchYearID
                        INNER JOIN LFAR_QuestionDetails ON LFAR_StatutoryAuditDetails.QuestionID = LFAR_QuestionDetails.QuestionID
                WHERE   LFAR_StatutoryAuditDetails.QuestionID = @QuestionID
                        AND BranchYearDetails.FinYear = @FinYear
                        AND ( ( LFAR_QuestionDetails.DefaultAnswerType
                                & LFAR_StatutoryAuditDetails.AnswerType = LFAR_QuestionDetails.DefaultAnswerType )
                              OR ( LFAR_QuestionDetails.DefaultAnswerType
                                   & LFAR_StatutoryAuditDetails.AnswerType = LFAR_StatutoryAuditDetails.AnswerType )
                            ) )
                          /*AND BRANCHTYPEID = 4 */
        ORDER BY BranchTypeID ,
                BranchName ,
                BranchZonalID ,
                BranchRegionalID
    END
















GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_GetComplianceCardBranchwiseByRegion]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[USP_LFAR_GetComplianceCardBranchwiseByRegion] @FINYEAR INT, @BranchRegionID INT
 AS 
    BEGIN  
WITH    MyCTE
          AS ( SELECT   BRANCHID ,
                        BRANCHNAME ,
                        BRANCHCODE ,
                        BranchRegionalID ,
                        BranchTypeID, (SELECT BranchName FROM BranchMaster WHERE BranchTypeID = 3 AND BranchRegionalID = A.BranchRegionalID) AS Region,
                        ( SELECT    COUNT(QuestionID)
              FROM      vwLFAR_Questionnaire AS QuestionSheet
            ) AS ActualCount ,
            ( SELECT    COUNT(DISTINCT RelativeQuestionID)
              FROM      vwLFAR_Questionnaire AS QuestionSheet
            ) AS GroupedCount
               FROM     dbo.BranchMaster A WHERE A.BranchRegionalID = @BranchRegionID
             ),
        MYCTE1
          AS ( SELECT   AnswerSheet.BranchYearID ,
                        COUNT(AnswerSheet.BranchYearID) AS ComplianceAnswerCount
               FROM     vwLFAR_Questionnaire AS QuestionSheet
                        LEFT OUTER JOIN LFAR_StatutoryAuditDetails AS AnswerSheet ON AnswerSheet.QuestionID = QuestionSheet.QuestionID
               WHERE    ( QuestionSheet.DefaultAnswerType
                          & AnswerSheet.AnswerType = QuestionSheet.DefaultAnswerType )
                        OR ( QuestionSheet.DefaultAnswerType
                             & AnswerSheet.AnswerType = AnswerSheet.AnswerType )
               GROUP BY AnswerSheet.BranchYearID
             ),
             MYCTE2
                  AS ( SELECT   AnswerSheet.BranchYearID ,
                                COUNT(AnswerSheet.BranchYearID) NonComplianceAnswerCount
                       FROM     dbo.vwLFAR_Questionnaire QuestionSheet
                                INNER JOIN LFAR_StatutoryAuditDetails AnswerSheet ON AnswerSheet.QUESTIONID = QuestionSheet.QUESTIONID
                       WHERE ( ( QuestionSheet.DefaultAnswerType
                                        & AnswerSheet.AnswerType <> QuestionSheet.DefaultAnswerType )
                                      AND ( QuestionSheet.DefaultAnswerType
                                            & AnswerSheet.AnswerType <> AnswerSheet.AnswerType )
                                    )
                       GROUP BY AnswerSheet.BranchYearID
                     ),
                MYCTE3
                  AS ( SELECT   AnswerSheet.BranchYearID ,
                                COUNT(AnswerSheet.BranchYearID) NotApplicableAnswerCount
                       FROM     dbo.vwLFAR_Questionnaire QuestionSheet
                                INNER JOIN LFAR_StatutoryAuditDetails AnswerSheet ON AnswerSheet.QUESTIONID = QuestionSheet.QUESTIONID
                       WHERE AnswerSheet.AnswerType = 16
                       GROUP BY AnswerSheet.BranchYearID
                     ),
                     MYCTE4
                  AS ( SELECT   AnswerSheet.BranchYearID ,
                                COUNT(AnswerSheet.BranchYearID) IsClosedAnswerCount
                       FROM     dbo.vwLFAR_Questionnaire QuestionSheet
                                INNER JOIN LFAR_StatutoryAuditDetails AnswerSheet ON AnswerSheet.QUESTIONID = QuestionSheet.QUESTIONID
                       WHERE AnswerSheet.IsClosed = 1
                       GROUP BY AnswerSheet.BranchYearID
                     ),
                     MYCTE5
                  AS ( SELECT   AnswerSheet.BranchYearID ,
                                COUNT(AnswerSheet.BranchYearID) ActualAnsweredCount
                       FROM     dbo.vwLFAR_Questionnaire QuestionSheet
                                INNER JOIN LFAR_StatutoryAuditDetails AnswerSheet ON AnswerSheet.QUESTIONID = QuestionSheet.QUESTIONID
                       GROUP BY AnswerSheet.BranchYearID
                     )
    SELECT  MyCTE.* , IsEditingLocked,IsClosed, A1.BranchYearID,
            ISNULL(MYCTE1.ComplianceAnswerCount, 0) ComplianceAnswerCount,
            ISNULL(MYCTE2.NonComplianceAnswerCount, 0) NonComplianceAnswerCount,
            ISNULL(MYCTE3.NotApplicableAnswerCount, 0) NotApplicableAnswerCount,
            ISNULL(MYCTE4.IsClosedAnswerCount, 0) IsClosedAnswerCount,
            ISNULL(MYCTE5.ActualAnsweredCount, 0) ActualAnsweredCount,
            ISNULL(MYCTE.ActualCount, 0)-ISNULL(MYCTE5.ActualAnsweredCount, 0) UnAnsweredCount,
            ISNULL(MYCTE.ActualCount, 0)-ISNULL(MYCTE4.IsClosedAnswerCount, 0) OpenQuestionCount,
            ROUND(( CAST(ISNULL(Mycte1.ComplianceAnswerCount, 0) AS DECIMAL)
                            / ( CASE WHEN ISNULL(MYCTE5.ActualAnsweredCount, 0) = 0
                                     THEN 1
                                     ELSE ISNULL(MYCTE5.ActualAnsweredCount, 0)
                                END ) ) * 100, 2) ComplianceRatio ,
                    ROUND(( CAST(ISNULL(Mycte2.NonComplianceAnswerCount, 0) AS DECIMAL)
                            / ( CASE WHEN ISNULL(MYCTE5.ActualAnsweredCount, 0) = 0
                                     THEN 1
                                     ELSE ISNULL(MYCTE5.ActualAnsweredCount, 0)
                                END ) ) * 100, 2) NonComplianceRatio ,
                    ROUND(( CAST(ISNULL(Mycte3.NotApplicableAnswerCount, 0) AS DECIMAL)
                            / ( CASE WHEN ISNULL(MYCTE5.ActualAnsweredCount, 0) = 0
                                     THEN 1
                                     ELSE ISNULL(MYCTE5.ActualAnsweredCount, 0)
                                END ) ) * 100, 2) NotApplicabeRatio,
                                ROUND(( CAST((ISNULL(MyCTE.ActualCount, 0)-ISNULL(MYCTE5.ActualAnsweredCount, 0)) AS DECIMAL)
                            / ( CASE WHEN ISNULL(MyCTE.ActualCount, 0) = 0
                                     THEN 1
                                     ELSE ISNULL(MyCTE.ActualCount, 0)
                                END ) ) * 100, 2) UnAnswerRatio,
                                ROUND(( CAST((ISNULL(MYCTE4.IsClosedAnswerCount, 0)) AS DECIMAL)
                            / ( CASE WHEN ISNULL(MyCTE.ActualCount, 0) = 0
                                     THEN 1
                                     ELSE ISNULL(MyCTE.ActualCount, 0)
                                END ) ) * 100, 2) ClosedRatio,
                                ROUND(( CAST((ISNULL(MyCTE.ActualCount, 0)-ISNULL(MyCTE4.IsClosedAnswerCount, 0)) AS DECIMAL)
                            / ( CASE WHEN ISNULL(MyCTE.ActualCount, 0) = 0
                                     THEN 1
                                     ELSE ISNULL(MyCTE.ActualCount, 0)
                                END ) ) * 100, 2) OpenRatio
    FROM    BranchYearDetails A1
            INNER JOIN MyCTE ON A1.BranchID = MyCTE.BranchID
            LEFT JOIN MYCTE1 ON A1.BranchYearID = MyCTE1.BranchYearID
            LEFT JOIN MYCTE2 ON A1.BranchYearID = MyCTE2.BranchYearID
            LEFT JOIN MYCTE3 ON A1.BranchYearID = MyCTE3.BranchYearID
            LEFT JOIN MYCTE4 ON A1.BranchYearID = MyCTE4.BranchYearID
            LEFT JOIN MYCTE5 ON A1.BranchYearID = MyCTE5.BranchYearID
    WHERE   FinYear = @FINYEAR AND BranchRegionalID = @BranchRegionID
    ORDER BY BRANCHNAME
end













GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_GetComplianceCardBranchwiseByZonal]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[USP_LFAR_GetComplianceCardBranchwiseByZonal] @FINYEAR INT, @BranchZonalID INT
 AS 
    BEGIN  
WITH    MyCTE
          AS ( SELECT   BRANCHID ,
                        BRANCHNAME ,
                        BRANCHCODE ,
                        BranchZonalID ,
						BranchRegionalID,
                        BranchTypeID, (SELECT BranchName FROM BranchMaster WHERE BranchTypeID = 2 AND BranchZonalID = A.BranchZonalID) AS Region,
                        ( SELECT    COUNT(QuestionID)
              FROM      vwLFAR_Questionnaire AS QuestionSheet
            ) AS ActualCount ,
            ( SELECT    COUNT(DISTINCT RelativeQuestionID)
              FROM      vwLFAR_Questionnaire AS QuestionSheet
            ) AS GroupedCount
               FROM     dbo.BranchMaster A WHERE A.BranchZonalID = @BranchZonalID
             ),
        MYCTE1
          AS ( SELECT   AnswerSheet.BranchYearID ,
                        COUNT(AnswerSheet.BranchYearID) AS ComplianceAnswerCount
               FROM     vwLFAR_Questionnaire AS QuestionSheet
                        LEFT OUTER JOIN LFAR_StatutoryAuditDetails AS AnswerSheet ON AnswerSheet.QuestionID = QuestionSheet.QuestionID
               WHERE AnswerSheet.AnswerType = 4
               GROUP BY AnswerSheet.BranchYearID
             ),
             MYCTE2
                  AS ( SELECT   AnswerSheet.BranchYearID ,
                                COUNT(AnswerSheet.BranchYearID) NonComplianceAnswerCount
                       FROM     dbo.vwLFAR_Questionnaire QuestionSheet
                                INNER JOIN LFAR_StatutoryAuditDetails AnswerSheet ON AnswerSheet.QUESTIONID = QuestionSheet.QUESTIONID
                       WHERE AnswerSheet.AnswerType = 8
                       GROUP BY AnswerSheet.BranchYearID
                     ),
                MYCTE3
                  AS ( SELECT   AnswerSheet.BranchYearID ,
                                COUNT(AnswerSheet.BranchYearID) NotApplicableAnswerCount
                       FROM     dbo.vwLFAR_Questionnaire QuestionSheet
                                INNER JOIN LFAR_StatutoryAuditDetails AnswerSheet ON AnswerSheet.QUESTIONID = QuestionSheet.QUESTIONID
                       WHERE AnswerSheet.AnswerType = 16
                       GROUP BY AnswerSheet.BranchYearID
                     ),
                     MYCTE4
                  AS ( SELECT   AnswerSheet.BranchYearID ,
                                COUNT(AnswerSheet.BranchYearID) IsClosedAnswerCount
                       FROM     dbo.vwLFAR_Questionnaire QuestionSheet
                                INNER JOIN LFAR_StatutoryAuditDetails AnswerSheet ON AnswerSheet.QUESTIONID = QuestionSheet.QUESTIONID
                       WHERE AnswerSheet.IsClosed = 1
                       GROUP BY AnswerSheet.BranchYearID
                     ),
                     MYCTE5
                  AS ( SELECT   AnswerSheet.BranchYearID ,
                                COUNT(AnswerSheet.BranchYearID) ActualAnsweredCount
                       FROM     dbo.vwLFAR_Questionnaire QuestionSheet
                                INNER JOIN LFAR_StatutoryAuditDetails AnswerSheet ON AnswerSheet.QUESTIONID = QuestionSheet.QUESTIONID
                       GROUP BY AnswerSheet.BranchYearID
                     )
    SELECT  MyCTE.* , IsEditingLocked,IsClosed, A1.BranchYearID,
            ISNULL(MYCTE1.ComplianceAnswerCount, 0) ComplianceAnswerCount,
            ISNULL(MYCTE2.NonComplianceAnswerCount, 0) NonComplianceAnswerCount,
            ISNULL(MYCTE3.NotApplicableAnswerCount, 0) NotApplicableAnswerCount,
            ISNULL(MYCTE4.IsClosedAnswerCount, 0) IsClosedAnswerCount,
            ISNULL(MYCTE5.ActualAnsweredCount, 0) ActualAnsweredCount,
            ISNULL(MYCTE.ActualCount, 0)-ISNULL(MYCTE5.ActualAnsweredCount, 0) UnAnsweredCount,
            ISNULL(MYCTE.ActualCount, 0)-ISNULL(MYCTE4.IsClosedAnswerCount, 0) OpenQuestionCount,
            ROUND(( CAST(ISNULL(Mycte1.ComplianceAnswerCount, 0) AS DECIMAL)
                            / ( CASE WHEN ISNULL(MYCTE5.ActualAnsweredCount, 0) = 0
                                     THEN 1
                                     ELSE ISNULL(MYCTE5.ActualAnsweredCount, 0)
                                END ) ) * 100, 2) ComplianceRatio ,
                    ROUND(( CAST(ISNULL(Mycte2.NonComplianceAnswerCount, 0) AS DECIMAL)
                            / ( CASE WHEN ISNULL(MYCTE5.ActualAnsweredCount, 0) = 0
                                     THEN 1
                                     ELSE ISNULL(MYCTE5.ActualAnsweredCount, 0)
                                END ) ) * 100, 2) NonComplianceRatio ,
                    ROUND(( CAST(ISNULL(Mycte3.NotApplicableAnswerCount, 0) AS DECIMAL)
                            / ( CASE WHEN ISNULL(MYCTE5.ActualAnsweredCount, 0) = 0
                                     THEN 1
                                     ELSE ISNULL(MYCTE5.ActualAnsweredCount, 0)
                                END ) ) * 100, 2) NotApplicabeRatio,
                                ROUND(( CAST((ISNULL(MyCTE.ActualCount, 0)-ISNULL(MYCTE5.ActualAnsweredCount, 0)) AS DECIMAL)
                            / ( CASE WHEN ISNULL(MyCTE.ActualCount, 0) = 0
                                     THEN 1
                                     ELSE ISNULL(MyCTE.ActualCount, 0)
                                END ) ) * 100, 2) UnAnswerRatio,
                                ROUND(( CAST((ISNULL(MYCTE4.IsClosedAnswerCount, 0)) AS DECIMAL)
                            / ( CASE WHEN ISNULL(MyCTE.ActualCount, 0) = 0
                                     THEN 1
                                     ELSE ISNULL(MyCTE.ActualCount, 0)
                                END ) ) * 100, 2) ClosedRatio,
                                ROUND(( CAST((ISNULL(MyCTE.ActualCount, 0)-ISNULL(MyCTE4.IsClosedAnswerCount, 0)) AS DECIMAL)
                            / ( CASE WHEN ISNULL(MyCTE.ActualCount, 0) = 0
                                     THEN 1
                                     ELSE ISNULL(MyCTE.ActualCount, 0)
                                END ) ) * 100, 2) OpenRatio
    FROM    BranchYearDetails A1
            INNER JOIN MyCTE ON A1.BranchID = MyCTE.BranchID
            LEFT JOIN MYCTE1 ON A1.BranchYearID = MyCTE1.BranchYearID
            LEFT JOIN MYCTE2 ON A1.BranchYearID = MyCTE2.BranchYearID
            LEFT JOIN MYCTE3 ON A1.BranchYearID = MyCTE3.BranchYearID
            LEFT JOIN MYCTE4 ON A1.BranchYearID = MyCTE4.BranchYearID
            LEFT JOIN MYCTE5 ON A1.BranchYearID = MyCTE5.BranchYearID
    WHERE   FinYear = @FINYEAR AND BranchZonalID = @BranchZonalID
    ORDER BY BRANCHNAME
end












GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_GetComplianceCardOfBranch]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

 CREATE PROCEDURE [dbo].[USP_LFAR_GetComplianceCardOfBranch] @BranchYearID INT
 AS 
    BEGIN        
        WITH    MyCTE
                  AS ( SELECT   HeaderID ,
                                COUNT(QuestionSheet.QUESTIONID) ActualCount ,
                                COUNT(DISTINCT ( QuestionSheet.RELATIVEQUESTIONID )) GroupedCount ,
                                COUNT(AnswerSheet.BranchYearID) ActualAnsweredCount
                       FROM     dbo.vwLFAR_Questionnaire QuestionSheet
                                LEFT JOIN LFAR_StatutoryAuditDetails AnswerSheet ON AnswerSheet.QUESTIONID = QuestionSheet.QUESTIONID
                       GROUP BY QuestionSheet.HeaderID
                     ),
                MYCTE1
                  AS ( SELECT   HeaderID ,
                                COUNT(AnswerSheet.BranchYearID) ComplianceAnswerCount
                       FROM     dbo.vwLFAR_Questionnaire QuestionSheet
                                INNER JOIN LFAR_StatutoryAuditDetails AnswerSheet ON AnswerSheet.QUESTIONID = QuestionSheet.QUESTIONID
                       WHERE    AnswerSheet.BranchYearID = @BranchYearID
                                AND ( ( QuestionSheet.DefaultAnswerType
                                        & AnswerSheet.AnswerType = QuestionSheet.DefaultAnswerType )
                                      OR ( QuestionSheet.DefaultAnswerType
                                           & AnswerSheet.AnswerType = AnswerSheet.AnswerType )
                                    )
                       GROUP BY QuestionSheet.HeaderID
                     ),
                MYCTE2
                  AS ( SELECT   HeaderID ,
                                COUNT(AnswerSheet.BranchYearID) NonComplianceAnswerCount
                       FROM     dbo.vwLFAR_Questionnaire QuestionSheet
                                INNER JOIN LFAR_StatutoryAuditDetails AnswerSheet ON AnswerSheet.QUESTIONID = QuestionSheet.QUESTIONID
                       WHERE    AnswerSheet.BranchYearID = @BranchYearID
                                AND ( ( QuestionSheet.DefaultAnswerType
                                        & AnswerSheet.AnswerType <> QuestionSheet.DefaultAnswerType )
                                      AND ( QuestionSheet.DefaultAnswerType
                                            & AnswerSheet.AnswerType <> AnswerSheet.AnswerType )
                                    )
                       GROUP BY QuestionSheet.HeaderID
                     ),
                MYCTE3
                  AS ( SELECT   HeaderID ,
                                COUNT(AnswerSheet.BranchYearID) NotApplicableAnswerCount
                       FROM     dbo.vwLFAR_Questionnaire QuestionSheet
                                INNER JOIN LFAR_StatutoryAuditDetails AnswerSheet ON AnswerSheet.QUESTIONID = QuestionSheet.QUESTIONID
                       WHERE    AnswerSheet.BranchYearID = @BranchYearID
                                AND AnswerSheet.AnswerType = 16
                       GROUP BY QuestionSheet.HeaderID
                     ),
                     MYCTE4
                  AS ( SELECT   HeaderID ,
                                COUNT(AnswerSheet.BranchYearID) IsClosedAnswerCount
                       FROM     dbo.vwLFAR_Questionnaire QuestionSheet
                                INNER JOIN LFAR_StatutoryAuditDetails AnswerSheet ON AnswerSheet.QUESTIONID = QuestionSheet.QUESTIONID
                       WHERE    AnswerSheet.BranchYearID = @BranchYearID
                                AND AnswerSheet.IsClosed = 1
                       GROUP BY QuestionSheet.HeaderID
                     )
            SELECT  ( SELECT TOP 1
                                Cap1
                      FROM      vwLFAR_HeaderFamily
                      WHERE     H1 = A1.RootHeaderID
                                AND A1.HT1 = 1
                      UNION
                      SELECT    'FET'
                      FROM      vwLFAR_HeaderFamily
                      WHERE     A1.HT1 = 2
                      UNION
                      SELECT    'LAB'
                      FROM      vwLFAR_HeaderFamily
                      WHERE     A1.HT1 = 3
                      UNION
                      SELECT    'ARB'
                      FROM      vwLFAR_HeaderFamily
                      WHERE     A1.HT1 = 4
                      UNION
                      SELECT    'CHO'
                      FROM      vwLFAR_HeaderFamily
                      WHERE     A1.HT1 = 5
                    ) MainHeading ,
                    ( CASE WHEN H1 = RootHeaderID THEN ''
                           ELSE REPLACE(SUBSTRING(FamilyHeaderOrderCaption,
                                                  CHARINDEX(';/;',
                                                            FamilyHeaderOrderCaption)
                                                  + ( CASE WHEN CHARINDEX(';/;',
                                                              FamilyHeaderOrderCaption) > 0
                                                           THEN 3
                                                           ELSE 0
                                                      END ),
                                                  LEN(FamilyHeaderOrderCaption)
                                                  + 1), ';/;', '') + ' '
                      END ) + REPLACE(SUBSTRING(FamilyHeaderCaption,
                                                CHARINDEX(';/;',
                                                          FamilyHeaderCaption)
                                                + ( CASE WHEN CHARINDEX(';/;',
                                                              FamilyHeaderCaption) > 0
                                                         THEN 3
                                                         ELSE 0
                                                    END ),
                                                LEN(FamilyHeaderCaption) + 1),
                                      ';/;', '-') SubHeading ,
                    MyCTE.* ,
                    ISNULL(Mycte1.ComplianceAnswerCount, 0) ComplianceAnswerCount ,
                    ISNULL(Mycte2.NonComplianceAnswerCount, 0) NonComplianceAnswerCount ,
                    ISNULL(Mycte3.NotApplicableAnswerCount, 0) NotApplicableAnswerCount ,
                    ISNULL(MyCTE.ActualCount, 0)-ISNULL(MyCTE.ActualAnsweredCount, 0) UnAnswerCount,
                    ISNULL(MYCTE4.IsClosedAnswerCount, 0) IsClosedAnswerCount,
                    ISNULL(MyCTE.ActualCount, 0)-ISNULL(MyCTE4.IsClosedAnswerCount, 0) OpenQuestionCount,
                    ROUND(( CAST(ISNULL(Mycte1.ComplianceAnswerCount, 0) AS DECIMAL)
                            / ( CASE WHEN ISNULL(Mycte.ActualAnsweredCount, 0) = 0
                                     THEN 1
                                     ELSE ISNULL(Mycte.ActualAnsweredCount, 0)
                                END ) ) * 100, 2) ComplianceRatio ,
                    ROUND(( CAST(ISNULL(Mycte2.NonComplianceAnswerCount, 0) AS DECIMAL)
                            / ( CASE WHEN ISNULL(Mycte.ActualAnsweredCount, 0) = 0
                                     THEN 1
                                     ELSE ISNULL(Mycte.ActualAnsweredCount, 0)
                                END ) ) * 100, 2) NonComplianceRatio ,
                    ROUND(( CAST(ISNULL(Mycte3.NotApplicableAnswerCount, 0) AS DECIMAL)
                            / ( CASE WHEN ISNULL(Mycte.ActualAnsweredCount, 0) = 0
                                     THEN 1
                                     ELSE ISNULL(Mycte.ActualAnsweredCount, 0)
                                END ) ) * 100, 2) NotApplicabeRatio,
                                ROUND(( CAST((ISNULL(MyCTE.ActualCount, 0)-ISNULL(MyCTE.ActualAnsweredCount, 0)) AS DECIMAL)
                            / ( CASE WHEN ISNULL(MyCTE.ActualCount, 0) = 0
                                     THEN 1
                                     ELSE ISNULL(MyCTE.ActualCount, 0)
                                END ) ) * 100, 2) UnAnswerRatio,
                                ROUND(( CAST((ISNULL(MYCTE4.IsClosedAnswerCount, 0)) AS DECIMAL)
                            / ( CASE WHEN ISNULL(MyCTE.ActualCount, 0) = 0
                                     THEN 1
                                     ELSE ISNULL(MyCTE.ActualCount, 0)
                                END ) ) * 100, 2) ClosedRatio,
                                ROUND(( CAST((ISNULL(MyCTE.ActualCount, 0)-ISNULL(MyCTE4.IsClosedAnswerCount, 0)) AS DECIMAL)
                            / ( CASE WHEN ISNULL(MyCTE.ActualCount, 0) = 0
                                     THEN 1
                                     ELSE ISNULL(MyCTE.ActualCount, 0)
                                END ) ) * 100, 2) OpenRatio
            FROM    vwLFAR_HeaderFamily A1
                    INNER JOIN MyCTE ON A1.H1 = MyCTE.HeaderID
                    LEFT JOIN MYCTE1 ON MyCTE.HeaderID = MyCTE1.HeaderID
                    LEFT JOIN MYCTE2 ON MyCTE.HeaderID = MyCTE2.HeaderID
                    LEFT JOIN MYCTE3 ON MyCTE.HeaderID = MyCTE3.HeaderID
                    LEFT JOIN MYCTE4 ON MyCTE.HeaderID = MyCTE4.HeaderID
            WHERE   HeaderLevel > 1
                    AND ActualCount > 0
            ORDER BY HeaderID ,
                    HeaderLevel
    END

















GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_GetComplianceCardOfBranchQuestionwise]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
    
    CREATE PROCEDURE [dbo].[USP_LFAR_GetComplianceCardOfBranchQuestionwise] @BranchYearID INT
 AS 
    BEGIN
    WITH    MyCTE
                  AS ( SELECT   HeaderID,QuestionSheet.QUESTIONID, QuestionSheet.QuestionFamily
                       FROM     dbo.vwLFAR_Questionnaire QuestionSheet
                                LEFT JOIN LFAR_StatutoryAuditDetails AnswerSheet ON AnswerSheet.QUESTIONID = QuestionSheet.QUESTIONID
                     ),
                     MyCTE1
                  AS ( SELECT   QuestionSheet.QUESTIONID,
                  AnswerSheet.ReplyOne,
                  (CASE WHEN ( ( QuestionSheet.DefaultAnswerType
                                        & AnswerSheet.AnswerType = QuestionSheet.DefaultAnswerType )
                                      OR ( QuestionSheet.DefaultAnswerType
                                           & AnswerSheet.AnswerType = AnswerSheet.AnswerType )
                                    ) THEN 'Compliant' ELSE
                                (CASE WHEN ( ( QuestionSheet.DefaultAnswerType
                                        & AnswerSheet.AnswerType <> QuestionSheet.DefaultAnswerType )
                                      AND ( QuestionSheet.DefaultAnswerType
                                            & AnswerSheet.AnswerType <> AnswerSheet.AnswerType )
                                    )  THEN 'Non Compliant' ELSE 
                                    (CASE WHEN AnswerSheet.AnswerType = 16 THEN 'Not Applicable' ELSE '' END) END) END) ComplianceCard
                  ,ISNULL(AnswerSheet.IsClosed,0) IsClosed
                       FROM     dbo.vwLFAR_Questionnaire QuestionSheet
                                LEFT JOIN LFAR_StatutoryAuditDetails AnswerSheet ON AnswerSheet.QUESTIONID = QuestionSheet.QUESTIONID
                                where BranchYearID = @BranchYearID
                     )
            SELECT  ( SELECT TOP 1
                                Cap1
                      FROM      vwLFAR_HeaderFamily
                      WHERE     H1 = A1.RootHeaderID
                                AND A1.HT1 = 1
                      UNION
                      SELECT    'FET'
                      FROM      vwLFAR_HeaderFamily
                      WHERE     A1.HT1 = 2
                      UNION
                      SELECT    'LAB'
                      FROM      vwLFAR_HeaderFamily
                      WHERE     A1.HT1 = 3
                      UNION
                      SELECT    'ARB'
                      FROM      vwLFAR_HeaderFamily
                      WHERE     A1.HT1 = 4
                      UNION
                      SELECT    'CHO'
                      FROM      vwLFAR_HeaderFamily
                      WHERE     A1.HT1 = 5
                    ) MainHeading ,
                    ( CASE WHEN H1 = RootHeaderID THEN ''
                           ELSE REPLACE(SUBSTRING(FamilyHeaderOrderCaption,
                                                  CHARINDEX(';/;',
                                                            FamilyHeaderOrderCaption)
                                                  + ( CASE WHEN CHARINDEX(';/;',
                                                              FamilyHeaderOrderCaption) > 0
                                                           THEN 3
                                                           ELSE 0
                                                      END ),
                                                  LEN(FamilyHeaderOrderCaption)
                                                  + 1), ';/;', '') + ' '
                      END ) + REPLACE(SUBSTRING(FamilyHeaderCaption,
                                                CHARINDEX(';/;',
                                                          FamilyHeaderCaption)
                                                + ( CASE WHEN CHARINDEX(';/;',
                                                              FamilyHeaderCaption) > 0
                                                         THEN 3
                                                         ELSE 0
                                                    END ),
                                                LEN(FamilyHeaderCaption) + 1),
                                      ';/;', '-') SubHeading ,
                    MyCTE.*,ISNULL(MyCTE1.ReplyOne,'') ReplyOne,ISNULL(MyCTE1.ComplianceCard,'') ComplianceCard,ISNULL(MyCTE1.IsClosed,0) IsClosed
            FROM    vwLFAR_HeaderFamily A1
                    LEFT JOIN MyCTE ON A1.H1 = MyCTE.HeaderID
                    LEFT JOIN MyCTE1 ON MyCTE1.QUESTIONID = MyCTE.QUESTIONID
            WHERE   HeaderLevel > 1 AND ISNULL(MyCTE.QUESTIONID,0) > 0 
            ORDER BY HeaderID ,
                    HeaderLevel
                    
                    end
















GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_GetComplianceCardRegionwise]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
  
  CREATE PROCEDURE [dbo].[USP_LFAR_GetComplianceCardRegionwise] @FINYEAR INT
 AS 
    BEGIN    
    WITH    MyCTE
          AS ( SELECT   
                        BranchRegionalID , FINYEAR,
                        (SELECT BranchName FROM BranchMaster WHERE BranchTypeID = 3 AND BranchRegionalID = A.BranchRegionalID) AS Region,
                        isnull(COUNT(BranchYearID),0) TotalCount
               FROM     dbo.BranchMaster A inner join BranchYearDetails on a.BranchID = BranchYearDetails.BranchID
               where BranchTypeID = 4
               group by BranchRegionalID,FinYear
             ),
    MyCTE1
          AS ( SELECT   
                        BranchRegionalID ,
                        ISNULL(COUNT(BranchYearID),0) LockedCount
               FROM     dbo.BranchMaster A inner join BranchYearDetails on a.BranchID = BranchYearDetails.BranchID
                where IsEdITINGloCKED = 1 and BranchTypeID = 4
               group by BranchRegionalID
             ),
             MyCTE2
          AS ( SELECT   
                        BranchRegionalID ,
                        ISNULL(COUNT(BranchYearID),0) ClosedCount
               FROM     dbo.BranchMaster A inner join BranchYearDetails on a.BranchID = BranchYearDetails.BranchID
                where IsClosed = 1 and BranchTypeID = 4
               group by BranchRegionalID
             )
             select MyCTE.*,ISNULL(MyCte1.LockedCount,0)LockedCount, ISNULL(MyCte2.ClosedCount,0) ClosedCount from BranchMaster inner join MyCTE on BranchMaster.BranchRegionalID = MyCTE.BranchRegionalID
            LEFT JOIN MYCTE1 ON MyCTE.BranchRegionalID = MyCTE1.BranchRegionalID
            LEFT JOIN MYCTE2 ON MyCTE.BranchRegionalID = MyCTE2.BranchRegionalID
    WHERE   BranchTypeID = 3 and FinYear = @FINYEAR
    ORDER BY Region
    
    end
















GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_GetComplianceQuestionsForAuditorLoginByBranchForTree]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

 CREATE PROCEDURE [dbo].[USP_LFAR_GetComplianceQuestionsForAuditorLoginByBranchForTree] @BranchYearID INT
 AS 
    BEGIN
        SELECT  *
        FROM    vwLFAR_HeaderAndQuestionForTree
        WHERE   TYPEID IN ( 1, 2 )
        UNION ALL
        SELECT  *
        FROM    vwLFAR_HeaderAndQuestionForTree
        WHERE   TYPEID = 3
                AND ID IN (
                SELECT     DISTINCT
                        ( LFAR_StatutoryAuditDetails.QuestionID )
                FROM    LFAR_StatutoryAuditDetails
                        INNER JOIN LFAR_QuestionDetails ON LFAR_StatutoryAuditDetails.QuestionID = LFAR_QuestionDetails.QuestionID
                WHERE   LFAR_StatutoryAuditDetails.BranchYearID = @BranchYearID
                        AND ( ( LFAR_QuestionDetails.DefaultAnswerType
                                & LFAR_StatutoryAuditDetails.AnswerType = LFAR_QuestionDetails.DefaultAnswerType )
                              OR ( LFAR_QuestionDetails.DefaultAnswerType
                                   & LFAR_StatutoryAuditDetails.AnswerType = LFAR_StatutoryAuditDetails.AnswerType )
                            ) )
                          /*AND BRANCHTYPEID = 4 */
        ORDER BY TYPEID ,
                ID ,
                HEADERLEVEL
    END
















GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_GetLFARBranchesByZoneCodeAndRegionCode]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



 CREATE PROCEDURE [dbo].[USP_LFAR_GetLFARBranchesByZoneCodeAndRegionCode]
    @BranchZonalID TINYINT ,
    @BranchRegionalID TINYINT,
	@FinYear SMALLINT
 AS 
    BEGIN
	DECLARE @LocalBranchZonalID TINYINT,
	@LocalBranchRegionalID TINYINT

	SET @LocalBranchZonalID=@BranchZonalID;
	SET @LocalBranchRegionalID= @BranchRegionalID;
        SET NOCOUNT ON;
        SELECT  dbo.BranchMaster.[BranchID]
      ,[BranchName]
      ,[BranchTypeID]
      ,[BranchCode]
      ,[IFSC]
      ,[BranchZonalID]
      ,[BranchRegionalID]
      ,[Email]
      ,[Telephone]
      ,[Fax]
      ,[AddressLine1]
      ,[AddressLine2]
      ,[AddressLine3]
      ,[BankState]
      ,[BankDistrict]
      ,[PinCode]
        FROM    dbo.BranchMaster join
		dbo.BranchYearDetails on dbo.BranchMaster.BranchID = dbo.BranchYearDetails.BranchID
        WHERE  dbo.BranchYearDetails.FinYear = @FinYear  

		AND (BranchRegionalID = @LocalBranchRegionalID OR @LocalBranchRegionalID = 0)
	AND (BranchZonalID = @LocalBranchZonalID OR @LocalBranchZonalID = 0)
		  --AND BranchZonalID = @BranchZonalID
		  --  AND BranchRegionalID = @BranchRegionalID
        
                         
        ORDER BY BranchTypeID ,
                BranchName ,
                BranchZonalID ,
                BranchRegionalID
    END



	











GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_GetNonComplianceBranchesForNonAuditorLoginByQuestion]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[USP_LFAR_GetNonComplianceBranchesForNonAuditorLoginByQuestion]
    @BranchZonalID TINYINT ,
    @BranchRegionalID TINYINT ,
    @QuestionID SMALLINT ,
    @FinYear SMALLINT
 AS 
    BEGIN
        SELECT  *
        FROM    dbo.BranchMaster
        WHERE   ( ISNULL(@BranchZonalID, 0) = 0 )
                OR ( ISNULL(@BranchZonalID, 0) > 0
                     AND BranchZonalID = @BranchZonalID
                     AND ( ( ISNULL(@BranchRegionalID, 0) > 0
                             AND BranchRegionalID = @BranchRegionalID
                           )
                           OR ( ISNULL(@BranchRegionalID, 0) = 0 )
                         )
                   )
                AND BRANCHID IN (
                SELECT     DISTINCT
                        ( BranchYearDetails.BranchID )
                FROM    BranchYearDetails
                        INNER JOIN LFAR_StatutoryAuditDetails ON BranchYearDetails.BranchYearID = LFAR_StatutoryAuditDetails.BranchYearID
                        INNER JOIN LFAR_QuestionDetails ON LFAR_StatutoryAuditDetails.QuestionID = LFAR_QuestionDetails.QuestionID
                WHERE   LFAR_StatutoryAuditDetails.QuestionID = @QuestionID
                        AND BranchYearDetails.FinYear = @FinYear
                        AND ( ( LFAR_QuestionDetails.DefaultAnswerType
                                & LFAR_StatutoryAuditDetails.AnswerType <> LFAR_QuestionDetails.DefaultAnswerType )
                              AND ( LFAR_QuestionDetails.DefaultAnswerType
                                    & LFAR_StatutoryAuditDetails.AnswerType <> LFAR_StatutoryAuditDetails.AnswerType )
                            ) )
                          /*AND BRANCHTYPEID = 4 */
        ORDER BY BranchTypeID ,
                BranchName ,
                BranchZonalID ,
                BranchRegionalID
    END
















GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_GetNonComplianceQuestionsForAuditorLoginByBranchForTree]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
CREATE FUNCTION [dbo].[UFN_GetBranchYearIDByBranchAuditorID]
    (
      @BranchAuditorID INT     
    )
RETURNS INT
AS BEGIN
DECLARE @BranchYearID INT;
SELECT @BranchYearID =   ISNULL(BranchYearDetails.BranchYearID,0)
FROM    LFAR_BranchAuditorDetails
        INNER JOIN LFAR_AuditorFirmDetails ON LFAR_BranchAuditorDetails.AuditorFirmID = LFAR_AuditorFirmDetails.AuditorFirmID
        INNER JOIN BranchYearDetails ON LFAR_AuditorFirmDetails.FinYear = BranchYearDetails.FinYear
        WHERE LFAR_BranchAuditorDetails.BranchAuditorID = @BranchAuditorID;
        RETURN @BranchYearID;
END
GO
*/

 CREATE PROCEDURE [dbo].[USP_LFAR_GetNonComplianceQuestionsForAuditorLoginByBranchForTree] @BranchYearID INT
 AS 
    BEGIN
        SELECT  *
        FROM    vwLFAR_HeaderAndQuestionForTree
        WHERE   TYPEID IN ( 1, 2 )
        UNION ALL
        SELECT  *
        FROM    vwLFAR_HeaderAndQuestionForTree
        WHERE   TYPEID = 3
                AND ID IN (
                SELECT     DISTINCT
                        ( LFAR_StatutoryAuditDetails.QuestionID )
                FROM    LFAR_StatutoryAuditDetails
                        INNER JOIN LFAR_QuestionDetails ON LFAR_StatutoryAuditDetails.QuestionID = LFAR_QuestionDetails.QuestionID
                WHERE   LFAR_StatutoryAuditDetails.BranchYearID = @BranchYearID
                        AND ( ( LFAR_QuestionDetails.DefaultAnswerType
                                & LFAR_StatutoryAuditDetails.AnswerType <> LFAR_QuestionDetails.DefaultAnswerType )
                              AND ( LFAR_QuestionDetails.DefaultAnswerType
                                    & LFAR_StatutoryAuditDetails.AnswerType <> LFAR_StatutoryAuditDetails.AnswerType )
                            ) )
        ORDER BY TYPEID ,
                ID ,
                HEADERLEVEL
    END
















GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_GetOpenQuestionBranchesForNonAuditorLoginByQuestion]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

 CREATE PROCEDURE [dbo].[USP_LFAR_GetOpenQuestionBranchesForNonAuditorLoginByQuestion]
    @BranchZonalID TINYINT ,
    @BranchRegionalID TINYINT ,
    @QuestionID SMALLINT ,
    @FinYear SMALLINT
 AS 
    BEGIN
        SELECT  *
        FROM    dbo.BranchMaster
        WHERE   ( ISNULL(@BranchZonalID, 0) = 0 )
                OR ( ISNULL(@BranchZonalID, 0) > 0
                     AND BranchZonalID = @BranchZonalID
                     AND ( ( ISNULL(@BranchRegionalID, 0) > 0
                             AND BranchRegionalID = @BranchRegionalID
                           )
                           OR ( ISNULL(@BranchRegionalID, 0) = 0 )
                         )
                   )
                AND BRANCHID IN (
                SELECT     DISTINCT
                        ( BranchYearDetails.BranchID )
                FROM    BranchYearDetails
                        INNER JOIN LFAR_StatutoryAuditDetails ON BranchYearDetails.BranchYearID = LFAR_StatutoryAuditDetails.BranchYearID
                WHERE   LFAR_StatutoryAuditDetails.QuestionID = @QuestionID
                        AND BranchYearDetails.FinYear = @FinYear
                        AND LFAR_StatutoryAuditDetails.IsClosed = 0 )
                          /*AND BRANCHTYPEID = 4 */
        ORDER BY BranchTypeID ,
                BranchName ,
                BranchZonalID ,
                BranchRegionalID
    END
















GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_GetOpenQuestionsForAuditorLoginByBranchForTree]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

 CREATE PROCEDURE [dbo].[USP_LFAR_GetOpenQuestionsForAuditorLoginByBranchForTree] @BranchYearID INT
 AS 
    BEGIN
        SELECT  *
        FROM    vwLFAR_HeaderAndQuestionForTree
        WHERE   TYPEID IN ( 1, 2 )
        UNION ALL
        SELECT  *
        FROM    vwLFAR_HeaderAndQuestionForTree
        WHERE   TYPEID = 3
                AND ID IN (
                SELECT     DISTINCT
                        ( LFAR_StatutoryAuditDetails.QuestionID )
                FROM    LFAR_StatutoryAuditDetails
                        INNER JOIN LFAR_QuestionDetails ON LFAR_StatutoryAuditDetails.QuestionID = LFAR_QuestionDetails.QuestionID
                WHERE   LFAR_StatutoryAuditDetails.BranchYearID = @BranchYearID
                        AND LFAR_StatutoryAuditDetails.IsClosed = 0 )
                          /*AND BRANCHTYPEID = 4 */
        ORDER BY TYPEID ,
                ID ,
                HEADERLEVEL
    END
















GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_GetQuestionsForReport]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

 CREATE PROCEDURE [dbo].[USP_LFAR_GetQuestionsForReport]
 @UserRoleType int,
 @BranchYearId int,
 @flag int
 AS 
 BEGIN
 declare @Query varchar(1024)
 set @query='';
 SET NOCOUNT ON;

 if(@UserRoleType=1)
 begin
   set @query='SELECT * FROM dbo.vwLFAR_Questionnaire as a
  left outer join dbo.LFAR_StatutoryAuditDetails as b on a.QuestionID = b.QuestionID
		          WHERE b.BranchYearID='+cast(@BranchYearId as varchar(10))+' and b.IsClosureApplied=1 and b.IsApproved=1 
                  ORDER BY a.HeaderType,
				           a.HeaderID , 
                           a.QuestionID ,
                           a.HeaderLevel'
 exec(@query)
 end
 
 else if(@UserRoleType=7 or @UserRoleType=8)
 begin
 if(@flag=1)
 begin
  set @query='SELECT * FROM dbo.vwLFAR_Questionnaire as a
  left outer join dbo.LFAR_StatutoryAuditDetails as b on a.QuestionID = b.QuestionID
		          WHERE (B.LFARComment is null or B.LFARComment='''') and b.BranchYearID='+cast(@BranchYearId as varchar(10))+'  and b.IsClosureApplied=1 and b.IsApproved!=1 
                  ORDER BY a.HeaderType,
				           a.HeaderID , 
                           a.QuestionID ,
                           a.HeaderLevel'
 exec(@query)
 end
 else if(@flag=2)
 begin
  set @query='SELECT * FROM dbo.vwLFAR_Questionnaire as a
  left outer join dbo.LFAR_StatutoryAuditDetails as b on a.QuestionID = b.QuestionID
		          WHERE (B.LFARComment is not null and B.LFARComment!='''') and b.BranchYearID='+cast(@BranchYearId as varchar(10))+' and b.IsClosureApplied=1 and b.IsApproved!=1
                  ORDER BY a.HeaderType,
				           a.HeaderID , 
                           a.QuestionID ,
                           a.HeaderLevel'
 exec(@query)
 end

 else if(@flag=3)
 begin
  set @query='SELECT * FROM dbo.vwLFAR_Questionnaire as a
  left outer join dbo.LFAR_StatutoryAuditDetails as b on a.QuestionID = b.QuestionID
		          WHERE b.BranchYearID='+cast(@BranchYearId as varchar(10))+' and b.IsClosureApplied=1 and b.IsApproved=1 
                  ORDER BY a.HeaderType,
				           a.HeaderID , 
                           a.QuestionID ,
                           a.HeaderLevel'
 exec(@query)
 end

 else if(@flag=4)
 begin
  set @query='SELECT * FROM dbo.vwLFAR_Questionnaire as a
  left outer join dbo.LFAR_StatutoryAuditDetails as b on a.QuestionID = b.QuestionID
		          WHERE (a.IsQuestionDisabled!=1 and a.IsInvalidQuestion!=1) and b.BranchYearID='+cast(@BranchYearId as varchar(10))+' and b.IsClosureApplied=0 and b.IsApproved!=1 
                  ORDER BY a.HeaderType,
				           a.HeaderID , 
                           a.QuestionID ,
                           a.HeaderLevel'
 exec(@query)
 end

 else 
 begin
  set @query='SELECT * FROM dbo.vwLFAR_Questionnaire as a
  left outer join dbo.LFAR_StatutoryAuditDetails as b on a.QuestionID = b.QuestionID
		          WHERE (B.LFARComment is not null and B.LFARComment!='''') and b.BranchYearID='+cast(@BranchYearId as varchar(10))+' 
                  ORDER BY a.HeaderType,
				           a.HeaderID , 
                           a.QuestionID ,
                           a.HeaderLevel'
 exec(@query)
 end

 end
 else
 begin
 set @query='SELECT * FROM dbo.vwLFAR_Questionnaire ORDER BY HeaderType,HeaderID , QuestionID ,HeaderLevel'
 exec(@query)
 end
 END
















GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_GetQuestionsListForClosure]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_LFAR_GetQuestionsListForClosure]
 @flag int,
 @BranchYearId int
 AS 
 BEGIN
 declare @Tables varchar(2000)
 declare @Query varchar(1024)

 SET FMTONLY OFF;

 CREATE TABLE #TmpTable
        (
		FamilyHeaderOrderCaption varchar(max),
		FamilyHeaderCaption varchar(max),
		LFARQuestion varchar(1500),
		QuestionID smallint,
		QuestionFamily varchar(max),
		AnswerType tinyint,
		LFARComment varchar(max),
		ReplyOne varchar(max),
		ReplyTwo varchar(max),
		IsClosureApplied bit,
		IsApproved tinyint,
		ClosureAppliedDate datetime,
		ClosureIssuedDate datetime
        )

 set @query='';
 SET NOCOUNT ON;

 if(@flag=1)
 begin
 set @query='INSERT INTO #TMPTABLE SELECT a.FamilyHeaderOrderCaption FamilyHeaderOrderCaption,a.FamilyHeaderCaption FamilyHeaderCaption,a.LFARQuestion LFARQuestion,a.QuestionID QuestionID,a.QuestionFamily QuestionFamily,b.AnswerType AnswerType,b.LFARComment LFARComment,b.ReplyOne ReplyOne,b.ReplyTwo ReplyTwo,b.IsClosureApplied IsClosureApplied,b.IsApproved IsApproved,b.ClosureAppliedDate ClosureAppliedDate,b.ClosureIssuedDate ClosureIssuedDate FROM dbo.vwLFAR_Questionnaire as a 
LEFT OUTER JOIN dbo.LFAR_StatutoryAuditDetails AS b ON a.QuestionID = b.QuestionID 
WHERE (a.IsQuestionDisabled!=1 AND a.IsInvalidQuestion!=1) AND  (b.LFARComment IS NULL OR b.LFARComment='''') AND b.BranchYearID='+cast(@BranchYearId as varchar(10))+' AND b.IsApproved!=1 
ORDER BY a.QuestionID'
						   --print(@query)
 exec(@query)
 end
 else if(@flag=2)
 begin
 set @query='INSERT INTO #TMPTABLE SELECT a.FamilyHeaderOrderCaption FamilyHeaderOrderCaption,a.FamilyHeaderCaption FamilyHeaderCaption,a.LFARQuestion LFARQuestion,a.QuestionID QuestionID,a.QuestionFamily QuestionFamily,b.AnswerType AnswerType,b.LFARComment LFARComment,b.ReplyOne ReplyOne,b.ReplyTwo ReplyTwo,b.IsClosureApplied IsClosureApplied,b.IsApproved IsApproved,b.ClosureAppliedDate ClosureAppliedDate,b.ClosureIssuedDate ClosureIssuedDate FROM dbo.vwLFAR_Questionnaire AS a 
LEFT OUTER JOIN dbo.LFAR_StatutoryAuditDetails AS b ON a.QuestionID = b.QuestionID 
WHERE (B.LFARComment IS NOT NULL AND B.LFARComment!='''')  AND b.BranchYearID='+cast(@BranchYearId as varchar(10))+' AND b.IsApproved!=1 
ORDER BY a.QuestionID'
						    --print(@query)
 exec(@query)
 end

 else
 begin
  set @query='INSERT INTO #TMPTABLE SELECT a.FamilyHeaderOrderCaption FamilyHeaderOrderCaption,a.FamilyHeaderCaption FamilyHeaderCaption,a.LFARQuestion LFARQuestion,a.QuestionID QuestionID,a.QuestionFamily QuestionFamily,b.AnswerType AnswerType,b.LFARComment LFARComment,b.ReplyOne ReplyOne,b.ReplyTwo ReplyTwo,b.IsClosureApplied IsClosureApplied,b.IsApproved IsApproved,b.ClosureAppliedDate ClosureAppliedDate,b.ClosureIssuedDate ClosureIssuedDate FROM dbo.vwLFAR_Questionnaire AS a 
LEFT OUTER JOIN dbo.LFAR_StatutoryAuditDetails AS b ON a.QuestionID = b.QuestionID 
WHERE b.BranchYearID='+cast(@BranchYearId as varchar(10))+' AND b.IsClosureApplied=1 AND b.IsApproved=1 
ORDER BY a.QuestionID'
						    --print(@query)
 exec(@query)
 end

 SELECT FamilyHeaderOrderCaption,FamilyHeaderCaption,LFARQuestion,QuestionID,QuestionFamily,AnswerType,LFARComment,ReplyOne,ReplyTwo,IsClosureApplied,IsApproved,ClosureAppliedDate,ClosureIssuedDate FROM #TMPTABLE 
	DROP TABLE #TmpTable

 END







GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_GetQuestionsListForClosure_RO]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

create PROCEDURE [dbo].[USP_LFAR_GetQuestionsListForClosure_RO]
 @flag INT,
 @BranchRegionalID INT,
 @fromDate DATE,
 @toDate DATE

 AS 
 BEGIN
 DECLARE @Tables VARCHAR(2000)
 DECLARE @Query VARCHAR(2048)
 DECLARE @LocalfromDate VARCHAR(10) 
 DECLARE @LocaltoDate VARCHAR(23) 
 
SET @LocalfromDate= CASE WHEN (@fromDate='1900-01-01' or @fromDate=null) THEN '' ELSE  CONVERT(CHAR(10), @fromDate, 120)  END ;
SET @LocaltoDate= CASE WHEN (@toDate='1900-01-01' or @toDate=null) THEN '' ELSE  CONVERT(CHAR(10), @toDate, 120)+ ' 23:59:59.999'  END ;

 SET FMTONLY OFF;

 CREATE TABLE #TmpTable
        (
		BranchCode VARCHAR(MAX),
		BranchYearID VARCHAR(MAX),
		FamilyHeaderOrderCaption VARCHAR(MAX),
		FamilyHeaderCaption VARCHAR(MAX),
		LFARQuestion VARCHAR(1000),
		QuestionID SMALLINT,
		QuestionFamily VARCHAR(MAX),
		AnswerType TINYINT,
		LFARComment VARCHAR(MAX),
		ReplyOne VARCHAR(MAX),
		ReplyTwo VARCHAR(MAX),
		IsClosureApplied BIT,
		IsApproved TINYINT,
		ClosureAppliedDate DATETIME,
		ClosureIssuedDate DATETIME
        )

 SET @query='';
 SET NOCOUNT ON;

 IF(@flag=1)
 BEGIN
 SET @query='INSERT INTO #TMPTABLE SELECT d.BranchCode,c.BranchYearID,a.FamilyHeaderOrderCaption FamilyHeaderOrderCaption,a.FamilyHeaderCaption FamilyHeaderCaption,a.LFARQuestion LFARQuestion,a.QuestionID QuestionID,a.QuestionFamily QuestionFamily,b.AnswerType AnswerType,b.LFARComment LFARComment,b.ReplyOne ReplyOne,b.ReplyTwo ReplyTwo,b.IsClosureApplied IsClosureApplied,b.IsApproved IsApproved,b.ClosureAppliedDate ClosureAppliedDate,b.ClosureIssuedDate ClosureIssuedDate 
 FROM dbo.vwLFAR_Questionnaire AS a 
 LEFT OUTER JOIN dbo.LFAR_StatutoryAuditDetails AS b ON a.QuestionID = b.QuestionID
 LEFT OUTER JOIN dbo.BranchYearDetails AS c ON b.BranchYearID=c.BranchYearID
 INNER JOIN dbo.BranchMaster AS d ON c.BranchID=d.BranchID  
 WHERE d.BranchRegionalID='+CAST(@BranchRegionalID AS VARCHAR(10))+' AND (b.LFARComment IS NULL OR b.LFARComment='''')  AND b.IsClosureApplied=1 AND b.IsApproved!=1  
 AND (b.ClosureAppliedDate >= '''+CAST(@LocalfromDate AS VARCHAR(10))+''' OR '''+ CAST(@LocalfromDate AS VARCHAR(10))+'''='''') AND (b.ClosureAppliedDate <= '''+CAST(@LocaltoDate AS VARCHAR) +''' or '''+ CAST(@LocaltoDate  AS VARCHAR)+'''='''')
 ORDER BY d.BranchCode'
 EXEC(@query)
 END
 ELSE
 BEGIN
 SET @query='INSERT INTO #TMPTABLE SELECT d.BranchCode,c.BranchYearID,a.FamilyHeaderOrderCaption FamilyHeaderOrderCaption,a.FamilyHeaderCaption FamilyHeaderCaption,a.LFARQuestion LFARQuestion,a.QuestionID QuestionID,a.QuestionFamily QuestionFamily,b.AnswerType AnswerType,b.LFARComment LFARComment,b.ReplyOne ReplyOne,b.ReplyTwo ReplyTwo,b.IsClosureApplied IsClosureApplied,b.IsApproved IsApproved,b.ClosureAppliedDate ClosureAppliedDate,b.ClosureIssuedDate ClosureIssuedDate 
 FROM dbo.vwLFAR_Questionnaire AS a
 LEFT OUTER JOIN dbo.LFAR_StatutoryAuditDetails AS b ON a.QuestionID = b.QuestionID
 LEFT OUTER JOIN dbo.BranchYearDetails AS c ON b.BranchYearID=c.BranchYearID
 INNER JOIN dbo.BranchMaster AS d ON c.BranchID=d.BranchID  
 WHERE d.BranchRegionalID='+CAST(@BranchRegionalID AS VARCHAR(10))+' AND (B.LFARComment IS NOT NULL AND B.LFARComment!    ='''') AND b.IsClosureApplied=1 AND b.IsApproved!=1 
 AND (b.ClosureAppliedDate >= '''+CAST(@LocalfromDate AS VARCHAR(10))+''' OR '''+ CAST(@LocalfromDate AS VARCHAR(10))+'''='''') AND (b.ClosureAppliedDate <= '''+CAST(@LocaltoDate AS VARCHAR) +''' OR '''+ CAST(@LocaltoDate  AS VARCHAR)+'''='''')
 ORDER BY d.BranchCode'
 EXEC(@query)
 END

 SELECT BranchCode, BranchYearID, FamilyHeaderOrderCaption, FamilyHeaderCaption, LFARQuestion, QuestionID, QuestionFamily, AnswerType, LFARComment, ReplyOne, ReplyTwo, IsClosureApplied, IsApproved, ClosureAppliedDate, ClosureIssuedDate 
 FROM #TMPTABLE 
 ORDER BY  BranchCode
	
 DROP TABLE #TmpTable

 END







GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_GetRemarksMissingQuestions]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[USP_LFAR_GetRemarksMissingQuestions]
@BranchYearId int
AS
BEGIN
SELECT  ISNULL(vwLFAR_HeaderFamily.H1, 1) HeaderID ,
            vwLFAR_HeaderFamily.R1 RelativeHeaderID ,
            vwLFAR_HeaderFamily.HeaderOrderCaption ,
            vwLFAR_HeaderFamily.Cap1 HeaderCaption ,
            vwLFAR_HeaderFamily.FamilyHeaderCaption ,
            vwLFAR_HeaderFamily.HeaderNote ,
            vwLFAR_HeaderFamily.HeaderType ,
            vwLFAR_HeaderFamily.HeaderLevel ,
            LFAR_QuestionDetails.QuestionID ,
            LFAR_QuestionDetails.RelativeQuestionID ,
            LFAR_QuestionDetails.QuestionTypeID ,
            LFAR_QuestionDetails.DefaultAnswerType ,
            LFAR_QuestionDetails.AnnexureMandate ,
            LFAR_QuestionDetails.AnswerTypeVisibility ,
            LFAR_QuestionDetails.QuestionOrderCaption ,
            LFAR_QuestionDetails.LFARQuestion ,
            LFAR_QuestionDetails.LFARCheckList ,
            ISNULL(vwLFAR_QuestionFamily.RootQuestionID, 0) RootQuestionID ,
            ISNULL(vwLFAR_QuestionFamily.QuestionLevel, 0) QuestionLevel ,
            ISNULL(vwLFAR_QuestionFamily.QuestionLevel, 0)
            + vwLFAR_HeaderFamily.HeaderLevel RelativeHLevel ,
            vwLFAR_QuestionFamily.QuestionFamily
    FROM    vwLFAR_QuestionFamily
            INNER JOIN LFAR_QuestionDetails ON vwLFAR_QuestionFamily.Q1 = LFAR_QuestionDetails.QuestionID
            RIGHT OUTER JOIN vwLFAR_HeaderFamily ON LFAR_QuestionDetails.HeaderID = vwLFAR_HeaderFamily.H1
                                                    AND vwLFAR_HeaderFamily.HeaderLevel <> 1
			INNER JOIN LFAR_STATUTORYAUDITDETAILS ON LFAR_QuestionDetails.QuestionID = LFAR_StatutoryAuditDetails.QuestionID 
			--WHERE LFARCOMMENT IS NOT NULL AND REPLYONE IS NULL AND BRANCHYEARID=@BranchYearId
			WHERE ISNULL(LFARCOMMENT,'') <> '' AND ISNULL(REPLYONE,'') = '' AND BRANCHYEARID=@BranchYearId
END














GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_GetUnApprovedAnnexureLineItems]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

create PROCEDURE [dbo].[USP_LFAR_GetUnApprovedAnnexureLineItems]
@BranchYearId as INT
AS
BEGIN

SET FMTONLY OFF;

CREATE TABLE #TmpTable
 (
	LineItemsCount INT
 )

--INSERT INTO #TmpTable

--SELECT COUNT(SlNo) FROM LFAR_Annexure47 WHERE Isapproved != 1 AND BranchYearID=@BranchYearId

END

SELECT SUM(LineItemsCount) FROM #TmpTable



GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_GetUnAttendedQuestionBranchesForAuditorLoginByBranchForTree]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

 CREATE PROCEDURE [dbo].[USP_LFAR_GetUnAttendedQuestionBranchesForAuditorLoginByBranchForTree] @BranchYearID INT
 AS 
    BEGIN
        SELECT  *
        FROM    vwLFAR_HeaderAndQuestionForTree
        WHERE   TYPEID IN ( 1, 2 )
        UNION ALL
        SELECT  *
        FROM    vwLFAR_HeaderAndQuestionForTree
        WHERE   TYPEID = 3
                AND ID NOT IN (
                SELECT     DISTINCT
                        ( LFAR_StatutoryAuditDetails.QuestionID )
                FROM    LFAR_StatutoryAuditDetails
                        INNER JOIN LFAR_QuestionDetails ON LFAR_StatutoryAuditDetails.QuestionID = LFAR_QuestionDetails.QuestionID
                WHERE   LFAR_StatutoryAuditDetails.BranchYearID = @BranchYearID )
                          /*AND BRANCHTYPEID = 4 */
        ORDER BY TYPEID ,
                ID ,
                HEADERLEVEL
    END
















GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_GetUnAttendedQuestionBranchesForNonAuditorLoginByQuestion]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

 CREATE PROCEDURE [dbo].[USP_LFAR_GetUnAttendedQuestionBranchesForNonAuditorLoginByQuestion]
    @BranchZonalID TINYINT ,
    @BranchRegionalID TINYINT ,
    @QuestionID SMALLINT ,
    @FinYear SMALLINT
 AS 
    BEGIN
        SELECT  *
        FROM    dbo.BranchMaster
        WHERE   ( ISNULL(@BranchZonalID, 0) = 0 )
                OR ( ISNULL(@BranchZonalID, 0) > 0
                     AND BranchZonalID = @BranchZonalID
                     AND ( ( ISNULL(@BranchRegionalID, 0) > 0
                             AND BranchRegionalID = @BranchRegionalID
                           )
                           OR ( ISNULL(@BranchRegionalID, 0) = 0 )
                         )
                   )
                AND BRANCHID IN (
                SELECT     DISTINCT
                        ( BranchYearDetails.BranchID )
                FROM    BranchYearDetails
                        INNER JOIN LFAR_StatutoryAuditDetails ON BranchYearDetails.BranchYearID = LFAR_StatutoryAuditDetails.BranchYearID
                WHERE   LFAR_StatutoryAuditDetails.QuestionID = @QuestionID
                        AND BranchYearDetails.FinYear = @FinYear
                        AND BranchYearDetails.BranchYearID NOT IN (
                        SELECT  BranchYearID
                        FROM    LFAR_StatutoryAuditDetails
                        WHERE   QuestionID = @QuestionID ) )
                          /*AND BRANCHTYPEID = 4 */
        ORDER BY BranchTypeID ,
                BranchName ,
                BranchZonalID ,
                BranchRegionalID
    END
















GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_PendingAnnexureClosureItems_RO]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


create PROCEDURE [dbo].[USP_LFAR_PendingAnnexureClosureItems_RO] 
@BranchRegionalId TINYINT,
@BranchYearID SMALLINT,
@AnnexureId TINYINT

AS
BEGIN

 DECLARE @localBranchYearId AS SMALLINT
 SET @localBranchYearId=@BranchYearID;

  DECLARE @localBranchRegionalId AS SMALLINT
 SET @localBranchRegionalId=@BranchRegionalId;

SET FMTONLY OFF;

CREATE TABLE #TmpTable
        (
		  BRANCHYEARID INT,
		  BRANCHCODE VARCHAR(10),
		  BRANCHNAME VARCHAR(50),
		  ZONALCODE VARCHAR(10),
		  ZONALNAME VARCHAR(50),
		  ANNEXUREID TINYINT,
		  ANNEXURENAME VARCHAR(350),
		  TOTALLINEITEMS INT,
		  TOTALLINEITEMSPENDING INT
        );

IF(@AnnexureId=1 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT  a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure1') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure1') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure1 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL ) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure1 WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING 
FROM  LFAR_Annexure1 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1 
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
END
 
 IF(@AnnexureId=2 or @AnnexureId=0) 
 BEGIN 
 INSERT INTO #TmpTable
 SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure2') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure2') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure2 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure2  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure2 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
End

IF(@AnnexureId=3 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure3') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure3') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure3 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure3  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure3 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
End

IF(@AnnexureId=4 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
 SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure4') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure4') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure4 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure4  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure4 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
End

IF(@AnnexureId=5 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
 SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure4A') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure4A') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure4A WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure4A  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure4A AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
End

IF(@AnnexureId=6 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
 SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure5') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure5') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure5 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure5  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure5 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
End

IF(@AnnexureId=7 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
 SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure5A') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure5A') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure5A WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure5A  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure5A AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
End

IF(@AnnexureId=8 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure6') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure6') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure6 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure6  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure6 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
End

IF(@AnnexureId=9 or @AnnexureId=0)
 BEGIN 
 INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure7') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure7') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure7 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure7  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure7 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
End

IF(@AnnexureId=10 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure8') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure8') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure8 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure8  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure8 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
End

IF(@AnnexureId=11 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure9') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure9') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure9 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure9  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure9 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
End

IF(@AnnexureId=12 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure10') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure10') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure10 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure10  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure10 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
End

IF(@AnnexureId=13 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure11') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure11') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure11 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure11  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure11 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
End

IF(@AnnexureId=14 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure12') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure12') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure12 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure12  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure12 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
End

IF(@AnnexureId=15 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure13') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure13') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure13 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure13  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure13 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
End

IF(@AnnexureId=16 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure14') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure14') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure14 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure14  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure14 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
End

IF(@AnnexureId=17 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure15') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure15') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure15 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure15  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure15 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
End

IF(@AnnexureId=18 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure16') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure16') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure16 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure16  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure16 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
End

IF(@AnnexureId=19 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure17') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure17') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure17 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure17  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure17 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
End

IF(@AnnexureId=20 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure18') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure18') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure18 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure18  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure18 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
End

IF(@AnnexureId=21 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure19') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure19') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure19 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure19  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure19 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
End

IF(@AnnexureId=22 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure20') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure20') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure20 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure20  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure20 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
End

IF(@AnnexureId=23 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure21') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure21') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure21 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure21  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure21 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
End

IF(@AnnexureId=24 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure22') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure22') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure22 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure22  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure22 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
End

IF(@AnnexureId=25 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure23') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure23') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure23 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure23  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure23 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
End

IF(@AnnexureId=26 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure24') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure24') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure24 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure24  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure24 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
End

IF(@AnnexureId=27 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure25') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure25') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure25 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure25  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure25 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
End

IF(@AnnexureId=28 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure26') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure26') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure26 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure26  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure26 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
End

IF(@AnnexureId=29 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure27') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure27') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure27 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure27  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure27 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
End

IF(@AnnexureId=30 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure28') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure28') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure28 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure28  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure28 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
End

IF(@AnnexureId=31 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure29') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure29') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure29 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure29  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure29 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
End

IF(@AnnexureId=32 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure30') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure30') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure30 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure30  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure30 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
End

IF(@AnnexureId=33 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure31') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure31') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure31 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure31  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure31 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
End

IF(@AnnexureId=34 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure32') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure32') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure32 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure32  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure32 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
End

IF(@AnnexureId=35 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure33') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure33') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure33 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure33  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure33 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
End

IF(@AnnexureId=36 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure34') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure34') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure34 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure34  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure34 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
End

IF(@AnnexureId=37 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure35') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure35') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure35 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure35  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure35 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
End

IF(@AnnexureId=38 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure36') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure36') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure36 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure36  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure36 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
End

IF(@AnnexureId=41 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure39') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure39') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure39 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure39  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure39 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
 End
 
IF(@AnnexureId=42 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure40') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure40') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure40 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure40  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure40 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
End

IF(@AnnexureId=43 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure41') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure41') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure41 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure41  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure41 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
End

IF(@AnnexureId=44 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure42') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure42') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure42 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure42  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure42 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
End

IF(@AnnexureId=45 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure43') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure43') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure43 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure43  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure43 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
End

IF(@AnnexureId=47 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable 
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure45') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure45') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure45 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure45  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure45 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1 
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID
End

IF(@AnnexureId=49 or @AnnexureId=0) 
BEGIN 
INSERT INTO #TmpTable
SELECT a.BranchYearID AS BRANCHYEARID, bm.BranchCode AS BRANCHCODE, bm.BranchName AS BRANCHNAME,
		(SELECT BranchCode FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALCODE,
		(SELECT BranchName FROM BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS ZONALNAME,
		(SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure47') AS ANNEXUREID, 
		(SELECT AnnexureName+' '+AnnexureTitle FROM LFAR_AnnexureMaster WHERE AnnexureTableName='LFAR_Annexure47') AS ANNEXURENAME,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure47 WHERE (BranchYearID=a.BranchYearID) AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMS,
		(SELECT COUNT(SlNo) FROM LFAR_Annexure47  WHERE (BranchYearID=a.BranchYearID) AND IsApproved!=1 AND IrregularitySBA IS NOT NULL) AS TOTALLINEITEMSPENDING
FROM  LFAR_Annexure47 AS a 
INNER JOIN BranchYearDetails AS bd 
	ON a.BranchYearID=bd.BranchYearID 
INNER JOIN BranchMaster AS bm 
	ON bd.BranchID=bm.BranchID 
WHERE (a.BranchYearID=@localBranchYearId OR @localBranchYearId=0) AND (bm.BranchRegionalID=@localBranchRegionalId OR @localBranchRegionalId=0) AND bd.IsClosed=1
GROUP BY a.BranchYearID, bm.BranchCode, bm.BranchName, bm.BranchRegionalID

END
End

SELECT * FROM #TmpTable where TOTALLINEITEMS !=0


GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_RectificationOfIrregularities_Annexurewise]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

create PROCEDURE [dbo].[USP_LFAR_RectificationOfIrregularities_Annexurewise]
AS 
BEGIN

 DECLARE @MyCursor CURSOR;
 DECLARE @AnnexureID TINYINT;
 DECLARE @Query VARCHAR(512);
 DECLARE @TableName VARCHAR(50)
 DECLARE @AnnexureName VARCHAR(300)

SET FMTONLY OFF;

 CREATE TABLE #TmpTable
        (
		  ANNEXUREID INT,
          REPORTED_NOOFCOMMENT INT,
		  REPORTED_NOOFBRANCHES INT,
		  RECTIFIED_NOOFCOMMENT INT,
		  RECTIFIED_NOOFBRANCHES INT,
		  BALANCE_NOOFCOMMENT INT,
		  BALANCE_NOOFBRANCHES INT,
        )
BEGIN

 SET @MyCursor = CURSOR FOR
    SELECT AnnexureID FROM LFAR_AnnexureMaster WHERE AnnexureID NOT IN (39,40,46,48)     

 OPEN @MyCursor 
    FETCH NEXT FROM @MyCursor 
    INTO @AnnexureID

 WHILE @@FETCH_STATUS = 0
    BEGIN
	 SET @TableName = (SELECT AnnexureTableName FROM LFAR_AnnexureMaster WHERE AnnexureID=@AnnexureID)

	  SET @Query='INSERT INTO #TmpTable(ANNEXUREID,REPORTED_NOOFCOMMENT,REPORTED_NOOFBRANCHES)
	 SELECT  ' + CAST(@AnnexureID AS VARCHAR(2)) + ', COUNT(a.SlNo) AS NOOFCOMMENTS, COUNT(DISTINCT a.BranchYearID) AS NOOFBRANCHES
	 FROM '+ @TableName +' a INNER JOIN BranchYearDetails b ON a.BranchYearID=b.BranchYearID WHERE b.IsClosed=1 AND a.IrregularitySBA IS NOT NULL'

	 EXEC(@Query)

	SET @Query = 'UPDATE #TmpTable SET #TmpTable.RECTIFIED_NOOFCOMMENT = A.NOOFCOMMENTS, RECTIFIED_NOOFBRANCHES = A.NOOFBRANCHES FROM #TmpTable 
	INNER JOIN (SELECT '+ CAST(@AnnexureID AS VARCHAR(2)) + ' AS AnnexureId, COUNT(a.SlNo) as NOOFCOMMENTS, COUNT(DISTINCT a.BranchYearID) AS NOOFBRANCHES 
	FROM ' + @TableName +' a INNER JOIN BranchYearDetails b ON a.BranchYearID=b.BranchYearID WHERE b.IsClosed=1 AND a.IsApproved=1 AND a.IrregularitySBA IS NOT NULL) AS A ON A.AnnexureId = #TmpTable.ANNEXUREID'

	 EXEC(@Query)

      FETCH NEXT FROM @MyCursor 
      INTO @AnnexureID 
    END; 

    CLOSE @MyCursor ;
    DEALLOCATE @MyCursor;

END

SELECT  B.AnnexureName, B.AnnexureTitle, A.REPORTED_NOOFCOMMENT, A.REPORTED_NOOFBRANCHES, A.RECTIFIED_NOOFCOMMENT, A.RECTIFIED_NOOFBRANCHES, (A.REPORTED_NOOFCOMMENT - A.RECTIFIED_NOOFCOMMENT) AS BALANCE_NOOFCOMMENT, (A.REPORTED_NOOFBRANCHES - A.RECTIFIED_NOOFBRANCHES) AS BALANCE_NOOFBRANCHES 
FROM #TmpTable AS A
INNER JOIN LFAR_AnnexureMaster AS B
ON A.ANNEXUREID=B.AnnexureID

END


GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_RectificationOfIrregularities_Branchwise]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_LFAR_RectificationOfIrregularities_Branchwise]
@BranchYearId as SMALLINT
AS
BEGIN

DECLARE @localBranchYearId AS SMALLINT;
SET @localBranchYearId=@BranchYearId;

SET FMTONLY OFF;

CREATE TABLE #TmpTable
        (
		  BranchYearID INT,
		  LineCOUNT SMALLINT,
		  AnnexureCount SMALLINT,
		  TakenForClosureLineItems SMALLINT,
		  ApprovedByZoneLineItems SMALLINT,
		  TakenForClosureAnnexureCount SMALLINT,
		  ApprovedByZoneAnnexureCount SMALLINT
        );

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure1 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure1 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure1 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure1 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure1 AS a 
--group by a.BranchYearID 

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure2 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, 
--ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure2 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure2 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure2 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure2 AS a 
--group by a.BranchYearID  

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure3 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure3 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure3 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure3 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure3 AS a 
--group by a.BranchYearID  

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure4 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure4 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure4 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure4 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure4 AS a 
--group by a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure4A WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure4A WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure4A WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure4A WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure4A AS a 
--group by a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure5 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure5 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure5 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure5 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure5 AS a 
--group by a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure5A WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure5A WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure5A WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure5A WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure5A AS a 
--group by a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure6 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure6 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure6 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure6 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure6 AS a 
--group by a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure7 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure7 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure7 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure7 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure7 AS a 
--group by a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure8 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure8 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure8 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure8 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure8 AS a 
--group by a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure9 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure9 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure9 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure9 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure9 AS a 
--group by a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure10 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure10 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure10 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure10 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure10 AS a 
--group by a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure11 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure11 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure11 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure11 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure11 AS a 
--group by a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure12 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure12 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure12 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure12 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure12 AS a 
--group by a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure13 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure13 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure13 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure13 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure13 AS a 
--group by a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure14 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure14 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure14 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure14 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure14 AS a 
--group by a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure15 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure15 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure15 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure15 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure15 AS a 
--group by a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure16 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure16 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure16 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure16 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure16 AS a 
--group by a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure17 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure17 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure17 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure17 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure17 AS a 
--group by a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure18 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure18 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure18 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure18 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure18 AS a 
--group by a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure19 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure19 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure19 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure19 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure19 AS a 
--group by a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure20 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure20 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure20 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure20 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure20 AS a 
--group by a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure21 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure21 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure21 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure21 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure21 AS a 
--group by a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure22 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure22 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure22 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure22 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure22 AS a 
--group by a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure23 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure23 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure23 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure23 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure23 AS a 
--group by a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure24 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure24 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure24 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure24 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure24 AS a 
--group by a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure25 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure25 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure25 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure25 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure25 AS a 
--group by a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure26 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure26 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure26 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure26 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure26 AS a 
--group by a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure27 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure27 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure27 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure27 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure27 AS a 
--group by a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure28 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure28 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure28 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure28 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure28 AS a 
--group by a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure29 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure29 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure29 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure29 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure29 AS a 
--group by a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure30 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure30 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure30 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure30 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure30 AS a 
--group by a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure31 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure31 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure31 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure31 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure31 AS a 
--group by a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure32 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure32 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure32 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure32 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure32 AS a 
--group by a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure33 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure33 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure33 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure33 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure33 AS a 
--group by a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure34 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure34 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure34 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure34 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure34 AS a 
--group by a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure35 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure35 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure35 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure35 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure35 AS a 
--group by a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure36 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure36 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure36 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure36 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure36 AS a 
--group by a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure39 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure39 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure39 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure39 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure39 AS a 
--group by a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure40 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure40 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure40 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure40 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure40 AS a 
--group by a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure41 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure41 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure41 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure41 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure41 AS a 
--group by a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure42 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure42 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure42 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure42 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure42 AS a 
--group by a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure43 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure43 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure43 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure43 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure43 AS a 
--group by a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure45 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure45 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure45 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure45 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure45 AS a 
--group by a.BranchYearID

INSERT INTO #TmpTable

SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_AnnexureA WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_AnnexureA WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_AnnexureA WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT DISTINCT 1 FROM LFAR_AnnexureA WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
FROM LFAR_AnnexureA AS a 
group by a.BranchYearID;


WITH TotalQuestions AS(
 Select count(Questionid) as TotalQuestions from LFAR_Questiondetails
),

 TotalQuestions_TakenForClosure AS(
 Select distinct branchyearid, count(Questionid) as Questions_TakenForClosure from LFAR_StatutoryAuditDetails where IsClosureApplied=1 and isapproved!=1 group by branchyearid
),

 TotalQuestions_ApprovedByZone AS(
 Select distinct branchyearid, count(questionid) as Questions_ApprovedByZone from LFAR_StatutoryAuditDetails where IsClosureApplied=1 and isapproved=1 group by branchyearid
)

  Select
  bm.BranchCode, bm.BranchName,
  (SELECT BranchCode FROM dbo.BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS RegionCode,
  (SELECT BranchName FROM dbo.BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS RegionName,
  
  (Select count(Questionid) from LFAR_Questiondetails) as TotalQuestions,
  c.Questions_TakenForClosure AS QuestionsTakenForClosure,
  d.Questions_ApprovedByZone AS QuestionsApprovedByZone,

  SUM(e.AnnexureCount) AS TotalAnnexureCount,
  SUM(e.TakenForClosureAnnexureCount) AS TakenForClosureAnnexureCount,
  SUM(e.ApprovedByZoneAnnexureCount) AS ApprovedByZoneAnnexureCount,

  SUM(e.LineCOUNT) AS TotalAnnexureLineItems,
  SUM(e.TakenForClosureLineItems) AS LineItemsTakenForClosure,
  SUM(e.ApprovedByZoneLineItems) AS LineItemsApprovedByZone,

  ISNULL((SELECT CASE WHEN ClosureIssued=1 THEN 'Yes' ELSE 'No' END FROM ClosureDetails WHERE ClosureIssued=1 and             BranchYearID=a.BranchYearID),'No') AS ClosureCertificateIssued
    
 FROM BranchYearDetails AS a
 INNER JOIN BranchMaster bm on a.BranchID=bm.BranchID
 LEFT JOIN TotalQuestions_TakenForClosure as c on c.branchyearid=a.branchyearid
 LEFT JOIN TotalQuestions_ApprovedByZone as d on d.branchyearid=a.branchyearid
 LEFT JOIN #TmpTable as e on e.BranchYearID=a.BranchYearID
 WHERE bm.BranchID!=1 and (a.BranchYearID=@localBranchYearId or @localBranchYearId=0)
 GROUP BY bm.BranchCode,a.BranchYearID, bm.BranchRegionalID, bm.BranchName, Questions_TakenForClosure, Questions_ApprovedByZone

END




GO
/****** Object:  StoredProcedure [dbo].[USP_LFAR_RectificationOfIrregularities_Branchwise_Filter]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

create PROCEDURE [dbo].[USP_LFAR_RectificationOfIrregularities_Branchwise_Filter]
@BranchYearId as SMALLINT
AS
BEGIN

DECLARE @localBranchYearId AS SMALLINT;
SET @localBranchYearId=@BranchYearId;

SET FMTONLY OFF;

CREATE TABLE #TmpTable
        (
		  BranchYearID INT,
		  LineCOUNT SMALLINT,
		  AnnexureCount SMALLINT,
		  TakenForClosureLineItems SMALLINT,
		  ApprovedByZoneLineItems SMALLINT,
		  TakenForClosureAnnexureCount SMALLINT,
		  ApprovedByZoneAnnexureCount SMALLINT
        );

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure1 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure1 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure1 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure1 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure1 AS a
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID 

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure2 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, 
--ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure2 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure2 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure2 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure2 AS a 
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID  

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure3 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure3 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure3 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure3 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure3 AS a 
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID  

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure4 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure4 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure4 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure4 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure4 AS a 
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure4A WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure4A WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure4A WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure4A WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure4A AS a 
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure5 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure5 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure5 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure5 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure5 AS a 
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure5A WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure5A WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure5A WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure5A WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure5A AS a 
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure6 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure6 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure6 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure6 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure6 AS a 
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure7 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure7 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure7 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure7 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure7 AS a 
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure8 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure8 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure8 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure8 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure8 AS a 
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure9 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure9 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure9 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure9 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure9 AS a 
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure10 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure10 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure10 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure10 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure10 AS a 
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure11 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure11 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure11 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure11 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure11 AS a 
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure12 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure12 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure12 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure12 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure12 AS a 
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure13 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure13 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure13 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure13 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure13 AS a 
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure14 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure14 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure14 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure14 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure14 AS a 
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure15 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure15 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure15 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure15 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure15 AS a 
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure16 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure16 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure16 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure16 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure16 AS a 
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure17 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure17 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure17 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure17 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure17 AS a 
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure18 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure18 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure18 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure18 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure18 AS a 
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure19 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure19 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure19 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure19 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure19 AS a 
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure20 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure20 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure20 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure20 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure20 AS a 
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure21 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure21 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure21 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure21 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure21 AS a 
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure22 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure22 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure22 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure22 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure22 AS a 
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure23 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure23 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure23 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure23 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure23 AS a 
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure24 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure24 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure24 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure24 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure24 AS a 
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure25 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure25 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure25 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure25 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure25 AS a 
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure26 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure26 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure26 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure26 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure26 AS a 
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure27 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure27 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure27 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure27 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure27 AS a 
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure28 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure28 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure28 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure28 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure28 AS a 
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure29 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure29 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure29 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure29 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure29 AS a 
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure30 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure30 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure30 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure30 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure30 AS a 
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure31 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure31 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure31 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure31 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure31 AS a 
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure32 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure32 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure32 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure32 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure32 AS a 
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure33 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure33 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure33 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure33 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure33 AS a 
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure34 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure34 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure34 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure34 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure34 AS a 
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure35 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure35 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure35 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure35 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure35 AS a 
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure36 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure36 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure36 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure36 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure36 AS a 
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure39 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure39 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure39 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure39 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure39 AS a 
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure40 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure40 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure40 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure40 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure40 AS a 
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure41 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure41 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure41 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure41 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure41 AS a 
--WHERE a.BranchYearID=@BranchYearId 
--GROUP BY a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure42 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure42 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure42 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure42 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure42 AS a 
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure43 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure43 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure43 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure43 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure43 AS a 
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID

--INSERT INTO #TmpTable

--SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_Annexure45 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_Annexure45 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_Annexure45 WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT distinct 1 FROM LFAR_Annexure45 WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
--FROM LFAR_Annexure45 AS a 
--WHERE a.BranchYearID=@BranchYearId   
--GROUP BY a.BranchYearID

INSERT INTO #TmpTable

SELECT  a.BranchYearID, COUNT(a.BranchYearID) as LineCOUNT, 1 AS AnnexureCount, (SELECT COUNT(BranchYearID) FROM LFAR_AnnexureA WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureLineItems, ISNULL((SELECT COUNT(BranchYearID) FROM LFAR_AnnexureA WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneLineItems, (SELECT DISTINCT 1 FROM LFAR_AnnexureA WHERE IsClosureApplied=1 and IsApproved!=1 and BranchYearID=a.BranchYearID) as TakenForClosureAnnexureCount, ISNULL((SELECT DISTINCT 1 FROM LFAR_AnnexureA WHERE IsClosureApplied=1 and IsApproved=1 and BranchYearID=a.BranchYearID),0) as ApprovedByZoneAnnexureCount
FROM LFAR_AnnexureA AS a 
WHERE a.BranchYearID=@BranchYearId   
GROUP BY a.BranchYearID;


WITH TotalQuestions AS(
 Select count(Questionid) as TotalQuestions from LFAR_Questiondetails
),

 TotalQuestions_TakenForClosure AS(
 Select distinct branchyearid, count(Questionid) as Questions_TakenForClosure from LFAR_StatutoryAuditDetails where (IsClosureApplied=1 and isapproved!=1) and BranchYearID=@BranchYearId GROUP BY branchyearid
),

 TotalQuestions_ApprovedByZone AS(
 Select distinct branchyearid, count(questionid) as Questions_ApprovedByZone from LFAR_StatutoryAuditDetails where (IsClosureApplied=1 and isapproved=1) and BranchYearID=@BranchYearId GROUP BY branchyearid
)

  Select
  bm.BranchCode, bm.BranchName,
  (SELECT BranchCode FROM dbo.BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS RegionCode,
  (SELECT BranchName FROM dbo.BranchMaster WHERE (BranchTypeID = 3) AND (BranchRegionalID = bm.BranchRegionalID)) AS RegionName,
  
  (Select count(Questionid) from LFAR_Questiondetails) as TotalQuestions,
  c.Questions_TakenForClosure AS QuestionsTakenForClosure,
  d.Questions_ApprovedByZone AS QuestionsApprovedByZone,

  SUM(e.AnnexureCount) AS TotalAnnexureCount,
  SUM(e.TakenForClosureAnnexureCount) AS TakenForClosureAnnexureCount,
  SUM(e.ApprovedByZoneAnnexureCount) AS ApprovedByZoneAnnexureCount,

  SUM(e.LineCOUNT) AS TotalAnnexureLineItems,
  SUM(e.TakenForClosureLineItems) AS LineItemsTakenForClosure,
  SUM(e.ApprovedByZoneLineItems) AS LineItemsApprovedByZone,

  ISNULL((SELECT CASE WHEN ClosureIssued=1 THEN 'Yes' ELSE 'No' END FROM ClosureDetails WHERE ClosureIssued=1 and             BranchYearID=a.BranchYearID),'No') AS ClosureCertificateIssued
    
 FROM BranchYearDetails AS a
 INNER JOIN BranchMaster bm on a.BranchID=bm.BranchID
 LEFT JOIN TotalQuestions_TakenForClosure as c on c.branchyearid=a.branchyearid
 LEFT JOIN TotalQuestions_ApprovedByZone as d on d.branchyearid=a.branchyearid
 LEFT JOIN #TmpTable as e on e.BranchYearID=a.BranchYearID
 WHERE bm.BranchID!=1 and (a.BranchYearID=@BranchYearID)
 GROUP BY a.BranchYearID, Questions_TakenForClosure, Questions_ApprovedByZone, bm.BranchCode, bm.BranchRegionalID, bm.BranchName

END



GO
/****** Object:  StoredProcedure [dbo].[USP_TA_BranchReview]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_TA_BranchReview]
@BranchYearId int
AS
BEGIN
DECLARE @Count INT
DECLARE @LoopIndex INT
DECLARE @AnnexureDisplayID TINYINT
DECLARE @AnnexureID TINYINT
DECLARE @ApplicableOption TINYINT
DECLARE @Query varchar(512)
DECLARE @ApplicableText varchar(15)

SET FMTONLY OFF;

CREATE TABLE #TmpTable
        (
          ANNEXUREID TINYINT,
          RECORDCOUNT INT,
		  APPLICABLEOPTION VARCHAR(50)	 
        )
SET @Count = 0
SELECT @Count = COUNT(*) FROM Annexuremaster
	WHERE ModuleID = 1 AND ParentAnnexureID >0 AND ParentAnnexureID != 10
SET @LoopIndex = 1

WHILE @LoopIndex <= @Count
	BEGIN
		SET @AnnexureDisplayID = 50 + @LoopIndex
		SELECT @Query = AnnexureTableName FROM Annexuremaster 
			WHERE ModuleID = 1 AND ParentAnnexureID >0 AND ParentAnnexureID != 10 AND DisplayOrder = @AnnexureDisplayID     
		SELECT @AnnexureID = AnnexureID FROM Annexuremaster 
			WHERE ModuleID = 1 AND ParentAnnexureID >0 AND ParentAnnexureID != 10 AND DisplayOrder = @AnnexureDisplayID     

		BEGIN TRY
			SET @ApplicableText = ''
			IF (@AnnexureID = 22 or @AnnexureID = 23 or @AnnexureID = 26 or @AnnexureID = 31)
				BEGIN	
					SET @ApplicableOption = 0
					SET @ApplicableText = 'Not Selected'
					SELECT @ApplicableOption = ApplicabilityOption FROM AnnexureDetails 
						WHERE AnnexureID = @AnnexureID AND BRANCHYEARID = @BranchYearId					
					IF (@ApplicableOption = 1)
						BEGIN
							SET @ApplicableText = 'Yes'
						END
					ELSE IF (@ApplicableOption = 2)
						BEGIN
							SET @ApplicableText = 'No'
						END
					ELSE IF (@ApplicableOption = 3)
						BEGIN
							SET @ApplicableText = 'Not Applicable'
						END
					
				END
			IF (@AnnexureID = 26)
				BEGIN
					SET @Query = 'INSERT INTO #TMPTABLE ' +
						'SELECT ' + CAST(@AnnexureID AS VARCHAR(10)) + ', COUNT(BRANCHYEARID), ''' + @ApplicableText + ''' FROM ' + @Query + 
							'  WHERE AnnexureID = ' + CAST((@AnnexureID) AS VARCHAR(10)) + ' AND BRANCHYEARID=' + CAST(@BranchYearId AS VARCHAR(10))								
				END
			ELSE IF (@AnnexureID = 19 or @AnnexureID = 20 or @AnnexureID = 21)
				BEGIN
					SET @Query = 'INSERT INTO #TMPTABLE ' +
						'SELECT ' + CAST(@AnnexureID AS VARCHAR(10)) + ', COUNT(BRANCHYEARID), ''' + @ApplicableText + ''' FROM ' + @Query + 
							'  WHERE SubpointNo = ' + CAST((@AnnexureID-18) AS VARCHAR(10)) + ' AND BRANCHYEARID=' + CAST(@BranchYearId AS VARCHAR(10))			
				END
			ELSE IF (@AnnexureID = 30)
				BEGIN
					SET @Query = 'INSERT INTO #TMPTABLE ' +
						'Values( ' + CAST(@AnnexureID AS VARCHAR(10)) + ', 12, ''' + @ApplicableText + ''')'	
				END
			ELSE 
				BEGIN
					SET @Query = 'INSERT INTO #TMPTABLE ' +
						'SELECT ' + CAST(@AnnexureID AS VARCHAR(10)) + ', COUNT(BRANCHYEARID), ''' + @ApplicableText + ''' FROM ' + @Query + 
							'  WHERE BRANCHYEARID=' + CAST(@BranchYearId AS VARCHAR(10))	
				END
			
			EXEC (@Query)
		END TRY
		BEGIN CATCH
		END CATCH
        
		SET @LoopIndex = @LoopIndex + 1
	END
	
	SELECT annexMast.AnnexureID, (Select AnnexureHeader From ANNEXUREMASTER Where AnnexureID = annexMast.ParentAnnexureID) AS AnnexureHeader,
		AnnexureName, AnnexureTableName, AnnexureColumnHeaders, RECORDCOUNT, APPLICABLEOPTION
	FROM ANNEXUREMASTER annexMast
	INNER JOIN #TMPTABLE ON annexMast.AnnexureID = #TMPTABLE.AnnexureID

	DROP TABLE #TmpTable
END













GO
/****** Object:  StoredProcedure [dbo].[USP_TA_DemoDelete]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[USP_TA_DemoDelete]
AS
BEGIN
SET FMTONLY OFF;
select * from TA_AmountNotCreditedToPL_b
select * from TA_AmountNotCreditedToPL_c
select * from TA_AmountNotCreditedToPL_d
select * from TA_AmountNotCreditedToPL_e
END















GO
/****** Object:  StoredProcedure [dbo].[USP_TA_GetAnnexureMandatoryMissingTables]    Script Date: 06-04-2021 17:56:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[USP_TA_GetAnnexureMandatoryMissingTables]
@BranchYearId int
AS
BEGIN
	DECLARE @Query varchar(512)
	DECLARE @Count194A int
	DECLARE @Count192 int
	DECLARE @YesNoNAFlag tinyint
	DECLARE @CountTDS int
	DECLARE @TAN varchar(10)
	DECLARE @IsManagerAuditing bit

	SET FMTONLY OFF;

	CREATE TABLE #TmpTable
        (
          TABLENAME VARCHAR(100),
		  MISSING_DETAILS VARCHAR(1000),
          RECORDCOUNT INT	  
        )

	BEGIN TRY

		SET @IsManagerAuditing = 0;
		SELECT @IsManagerAuditing = IsNull(IsManagerAuditing,0) FROM BranchYearDetails 
					WHERE BRANCHYEARID = CAST(@BranchYearId AS VARCHAR(10))	

		if (@IsManagerAuditing =0)
			Begin
				--point 16b
				SET @Query = 'TA_AmountNotCreditedToPL_b'
				SET @Query = 'INSERT INTO #TMPTABLE SELECT ''' + @Query + ''',''Particulars for Description (Others)'' , COUNT(BRANCHYEARID) FROM ' + @Query + 
					'  WHERE DescriptionType=8 AND ISNULL(Particulars,'''') = '''' AND BRANCHYEARID='+CAST(@BranchYearId AS VARCHAR(10))
				EXEC (@Query)
			End
		
	    --point 21dA
		SET @YesNoNAFlag = 0
		SET @Query = 'TA_DisallowanceIncomeUs40Aof3_A'
		SELECT @YesNoNAFlag = IsNull(ApplicabilityOption,0) FROM AnnexureDetails 
					WHERE AnnexureID = 22 AND BRANCHYEARID = CAST(@BranchYearId AS VARCHAR(10))	    
		if(@YesNoNAFlag=0)
			begin
				SET @Query = 'INSERT INTO #TMPTABLE VALUES( ''' + @Query + ''',''Select Yes/No'',1)'				
			End
		else
			begin
				SET @Query = 'INSERT INTO #TMPTABLE SELECT ''' + @Query + ''',''Name of Payee/Date of payment'' , COUNT(BRANCHYEARID) FROM ' + @Query + 
					'  WHERE (ISNULL(NameofPayee,'''') = '''' OR ISNULL(DateOfPayment,'''') = '''')  AND BRANCHYEARID='+CAST(@BranchYearId AS VARCHAR(10))

			end		
		EXEC (@Query)

	    --point 21dB
		SET @YesNoNAFlag = 0
		SET @Query = 'TA_DisallowanceIncomeUs40Aof3_B'
		SELECT @YesNoNAFlag = IsNull(ApplicabilityOption,0) FROM AnnexureDetails 
					WHERE AnnexureID = 23 AND BRANCHYEARID = CAST(@BranchYearId AS VARCHAR(10))	    
		if(@YesNoNAFlag=0)
			begin
				SET @Query = 'INSERT INTO #TMPTABLE VALUES( ''' + @Query + ''',''Select Yes/No'',1)'				
			End
		else
			begin
				SET @Query = 'INSERT INTO #TMPTABLE SELECT ''' + @Query + ''',''Name of Payee/Date of payment'' , COUNT(BRANCHYEARID) FROM ' + @Query + 
					'  WHERE (ISNULL(NameofPayee,'''') = '''' OR ISNULL(DateOfPayment,'''') = '''')  AND BRANCHYEARID='+CAST(@BranchYearId AS VARCHAR(10))
			end		
		EXEC (@Query)

		if (@IsManagerAuditing =0)
			Begin
				--point 26ii
				SET @YesNoNAFlag = 0
				SET @Query = 'AnnexureDetails'
				SELECT @YesNoNAFlag = IsNull(ApplicabilityOption,0) FROM AnnexureDetails 
							WHERE AnnexureID = 26 AND BRANCHYEARID = CAST(@BranchYearId AS VARCHAR(10))	    
				if(@YesNoNAFlag=0)
					begin
						SET @Query = 'INSERT INTO #TMPTABLE VALUES( ''' + @Query + ''',''Select Yes/No'',1)'				
					End
				else
					begin
						SET @Query = 'INSERT INTO #TMPTABLE SELECT ''' + @Query + ''',''Description'' , COUNT(BRANCHYEARID) FROM ' + @Query + 
							'  WHERE (ApplicabilityOption = 1 AND ISNULL(Particulars,'''') = '''') AND AnnexureID = 26 AND BRANCHYEARID='+CAST(@BranchYearId AS VARCHAR(10))
					end		
				EXEC (@Query)
			End

		--point 34a
		SELECT @Count194A = COUNT(BRANCHYEARID) FROM AR_AnnexureXXIIIB_a 
					WHERE Section = 4 AND BRANCHYEARID = CAST(@BranchYearId AS VARCHAR(10))
		SELECT @Count192 = COUNT(BRANCHYEARID) FROM AR_AnnexureXXIIIB_a 
					WHERE Section = 1 AND BRANCHYEARID = CAST(@BranchYearId AS VARCHAR(10))
		SET @Query =''
		if (@Count194A = 0 and @Count192 = 0)
			begin
				SET @Query ='Section 194A & 192 entries'',2'
			End
		else if (@Count194A = 0)
			begin
				SET @Query ='Section 194A entry'',1'
			End
		else if (@Count192 = 0)
			begin
				SET @Query ='Section 192 entry'',1'
			End
		
		if (LEN(@Query) > 0)
			begin
				SET @Query = 'INSERT INTO #TMPTABLE VALUES( ''AR_AnnexureXXIIIB_a'',''' + @Query + ')'				
				EXEC (@Query)
			End
		
		--point 34b
		SET @YesNoNAFlag = 0
		SET @Query = 'AR_AnnexureXXIIIB_b'
		--SELECT @YesNoNAFlag = IsNull(ApplicabilityOption,0) FROM AnnexureDetails 
		--			WHERE AnnexureID = 30 AND BRANCHYEARID = CAST(@BranchYearId AS VARCHAR(10))	    
		--if(@YesNoNAFlag=0)
		--	begin
		--		SET @Query = 'INSERT INTO #TMPTABLE VALUES( ''' + @Query + ''',''Select Yes/No/Not Applicable'',1)'				
		--	End
		--else
			begin
				SET @Query = 'INSERT INTO #TMPTABLE SELECT ''' + @Query + ''',''Due Date'' , COUNT(BRANCHYEARID) FROM ' + @Query + 
					'  WHERE ISNULL(DueDate,'''') = '''' AND HeadID < 9 AND BRANCHYEARID='+CAST(@BranchYearId AS VARCHAR(10))
			end		
		EXEC (@Query)

		--point 34c
		--SET @YesNoNAFlag = 0
		--SET @Query = 'AR_AnnexureXXIIIB_c'
		--SELECT @YesNoNAFlag = IsNull(ApplicabilityOption,0) FROM AnnexureDetails 
		--			WHERE AnnexureID = 31 AND BRANCHYEARID = CAST(@BranchYearId AS VARCHAR(10))	    
		--if(@YesNoNAFlag=0)
		--	begin
		--		SET @Query = 'INSERT INTO #TMPTABLE VALUES( ''' + @Query + ''',''Select Yes/No/Not Applicable'',1)'				
		--		EXEC (@Query)
		--	End

		-- point 21bA
		SET @Query = 'AR_AnnexureXXIIIC_a'
		SET @Query = 'INSERT INTO #TMPTABLE SELECT ''' + @Query + ''',''Name/Address of Deductee/Date of Payment'' , COUNT(BRANCHYEARID) FROM ' + @Query + 
			'  WHERE (ISNULL(NameOfDeductee,'''') = '''' OR ISNULL(AddressOfDeductee,'''') = '''' OR ISNULL(DateOfPayment,'''') = '''') AND BRANCHYEARID='+CAST(@BranchYearId AS VARCHAR(10))

		EXEC (@Query)

		-- point 21bb
		SET @Query = 'AR_AnnexureXXIIIC_b'
		SET @Query = 'INSERT INTO #TMPTABLE SELECT ''' + @Query + ''',''Name/Address of Deductee/Date of Payment'' , COUNT(BRANCHYEARID) FROM ' + @Query + 
			'  WHERE (ISNULL(NameOfDeductee,'''') = '''' OR ISNULL(AddressOfDeductee,'''') = '''' OR ISNULL(DateOfPayment,'''') = '''') AND BRANCHYEARID='+CAST(@BranchYearId AS VARCHAR(10))

		EXEC (@Query)

		-- point 41
		SET @Query = 'TA_DemandRefund'
		SET @Query = 'INSERT INTO #TMPTABLE SELECT ''' + @Query + ''',''Remarks'' , COUNT(BRANCHYEARID) FROM ' + @Query + 
			'  WHERE ISNULL(IrregularitySBA,'''') = ''''  AND BRANCHYEARID='+CAST(@BranchYearId AS VARCHAR(10))

		EXEC (@Query)

		--TAN
		SELECT @CountTDS = COUNT(BRANCHYEARID) FROM AR_AnnexureXXIIIB_a 
							WHERE BRANCHYEARID = CAST(@BranchYearId AS VARCHAR(10))
		SELECT @CountTDS = @CountTDS + COUNT(BRANCHYEARID) FROM AR_AnnexureXXIIIB_c 
							WHERE BRANCHYEARID = CAST(@BranchYearId AS VARCHAR(10))
		SELECT @CountTDS = @CountTDS + COUNT(BRANCHYEARID) FROM AR_AnnexureXXIIIB_d 
							WHERE BRANCHYEARID = CAST(@BranchYearId AS VARCHAR(10))
		SELECT @CountTDS = @CountTDS + COUNT(BRANCHYEARID) FROM AR_AnnexureXXIIIC_a 
							WHERE BRANCHYEARID = CAST(@BranchYearId AS VARCHAR(10))
		SELECT @CountTDS = @CountTDS + COUNT(BRANCHYEARID) FROM AR_AnnexureXXIIIC_b 
							WHERE BRANCHYEARID = CAST(@BranchYearId AS VARCHAR(10))
		SELECT @CountTDS = @CountTDS + COUNT(BRANCHYEARID) FROM AR_AnnexureXXIIIC_c 
							WHERE BRANCHYEARID = CAST(@BranchYearId AS VARCHAR(10))
		SELECT @CountTDS = @CountTDS + COUNT(BRANCHYEARID) FROM AR_AnnexureXXIIIC_d 
							WHERE BRANCHYEARID = CAST(@BranchYearId AS VARCHAR(10))
		SET @TAN = ''
		SET @Query  = ''
		SELECT @TAN = IsNull(TANNum,'') FROM BranchMaster 
					WHERE BRANCHID In (Select BranchID FROM BranchYearDetails Where BRANCHYEARID = CAST(@BranchYearId AS VARCHAR(10)))
		
	END TRY
    BEGIN CATCH
    END CATCH
        
	if (@CountTDS > 0 and LEN(@TAN) = 0)
		begin
			SELECT AnnexureID,(Select AnnexureHeader From ANNEXUREMASTER Where AnnexureID = annexMast.ParentAnnexureID) AS AnnexureHeader,
				AnnexureName,AnnexureTableName,AnnexureColumnHeaders,MISSING_DETAILS 
			FROM ANNEXUREMASTER AS annexMast 
			INNER JOIN #TMPTABLE ON annexMast.ANNEXURETABLENAME = #TMPTABLE.TABLENAME WHERE RECORDCOUNT > 0 and AnnexureID <> 49
			UNION 
			SELECT CAST(0 as tinyint),'Branch Master','Details','BRANCHMASTER','','TAN'
		end
	else
		begin
			SELECT AnnexureID,(Select AnnexureHeader From ANNEXUREMASTER Where AnnexureID = annexMast.ParentAnnexureID) AS AnnexureHeader,
				AnnexureName,AnnexureTableName,AnnexureColumnHeaders,MISSING_DETAILS 
			FROM ANNEXUREMASTER AS annexMast 
			INNER JOIN #TMPTABLE ON annexMast.ANNEXURETABLENAME = #TMPTABLE.TABLENAME WHERE RECORDCOUNT > 0 and AnnexureID <> 49
		end
	DROP TABLE #TmpTable
END













GO
